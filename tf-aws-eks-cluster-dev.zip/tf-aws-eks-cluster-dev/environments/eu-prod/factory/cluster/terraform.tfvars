region = "eu-west-1"
availability_zones = ["eu-west-1a", "eu-west-1c"]
vpc_id = "vpc-00e00d06e6a616dc6"
subnet_ids = ["subnet-0149bf202da57dcf7", "subnet-06cc699b8c39b949b"]

kubernetes_version = "1.33"
oidc_provider_enabled = false

cluster_name = "eu-prod-factory"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 7
  
kms_key_arn = "arn:aws:kms:eu-west-1:857620310418:key/ec1b20a3-1d6a-4f5a-8d86-869712c32a99"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Role = "dt-dna-shared"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
}

map_additional_aws_accounts = ["857620310418"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::857620310418:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    },
    {
      rolearn  = "arn:aws:iam::857620310418:role/hc-cloud-L3"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

map_additional_iam_users = [
    {
      userarn  = "arn:aws:iam::857620310418:user/502818692"   # Cloud FSSO
      username = "502818692"
      groups   = ["502818692"]
    }      
]
