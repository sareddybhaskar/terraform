region = "eu-west-1"
availability_zones = ["eu-west-1a", "eu-west-1c"]
vpc_id = "vpc-075e09d9b03792b09"
subnet_ids = ["subnet-017ff3de13e8b27d7", "subnet-0b6f75a3a241e7a57"]

kubernetes_version = "1.33"
oidc_provider_enabled = false

cluster_name = "eu-nprod-factory"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 7
  
kms_key_arn = "arn:aws:kms:eu-west-1:400123706343:key/ca5aa2e0-5a22-40f1-956d-ab15ba7cbf3f"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Role = "dt-dna-shared"
    Program   = "ODP"
    uai  = "UAI3032642"
    Automation = "Jenkins"
    Environment  = "Nprod"
}

map_additional_aws_accounts = ["400123706343"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::400123706343:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    },
    {
      rolearn  = "arn:aws:iam::400123706343:role/hc-cloud-L3"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

map_additional_iam_users = [
    {
      userarn  = "arn:aws:iam::400123706343:user/502818692"     # Cloud FSSO
      username = "502818692"
      groups   = ["502818692"]
    }      
]
