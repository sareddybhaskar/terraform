terraform {
  required_version = ">= 0.12.0"

  required_providers {
    aws = {
      source = "hashicorp/aws"
      version = "> 4.0.0"
    }
    template   = "~> 2.0"
    null       = ">= 2.0"
    local      = ">= 1.3"
    kubernetes = "~> 1.11"
  }
}
