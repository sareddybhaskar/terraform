region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1b"]
vpc_id = "vpc-018c491cd8dfe60eb"
subnet_ids = ["subnet-0d8f022a20e25dab5", "subnet-040e0f38dbcf6aeb2"]

kubernetes_version = "1.33"
oidc_provider_enabled = false

cluster_name = "us-aiml-prod-factory-1"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 7
  
kms_key_arn = "arn:aws:kms:us-east-1:046704565421:key/416dbee1-9f9b-4b54-a7df-eb083c9cb949"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Role = "dt-dna-shared"
    Program   = "ODP"
    uai        = "UAI3053026"
    Automation = "Jenkins"
    Environment  = "us-aiml-prod"
}

map_additional_aws_accounts = ["046704565421"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::046704565421:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

# map_additional_iam_users = [
#     {
#       userarn  = "arn:aws:iam::046704565421:user/502818692"     # Cloud FSSO
#       username = "502818692"
#       groups   = ["502818692"]
#     },
#     {
#       userarn  = "arn:aws:iam::046704565421:user/502827198"     # MDP-MR FSSO
#       username = "502827198"
#       groups   = ["502827198"]
#     },
#     {
#       userarn  = "arn:aws:iam::046704565421:user/502827197"     # IBStudio FSSO
#       username = "502827197"
#       groups   = ["502827197"]
#     }        
# ]
