region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
vpc_id = "vpc-043834bbbfee59994"
subnet_ids = ["subnet-052c531062db29012", "subnet-099916e4b6c520330"]

kubernetes_version = "1.33"
oidc_provider_enabled = false

cluster_name = "fin-nprod-sox-factory"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 365
  
kms_key_arn = "arn:aws:kms:us-east-1:083760424738:key/aada9ea8-e317-4bf9-a32e-5a8bca687e6a"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Role = "dt-dna-aa-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "fin-nprod"
}

map_additional_aws_accounts = ["083760424738"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::083760424738:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

map_additional_iam_users = [
    {
      userarn  = "arn:aws:iam::083760424738:user/502818692"     # Cloud FSSO
      username = "502818692"
      groups   = ["502818692"]
    }
    # {
    #   userarn  = "arn:aws:iam::083760424738:user/502827198"     # MDP-MR FSSO
    #   username = "502827198"
    #   groups   = ["502827198"]
    # },
    # {
    #   userarn  = "arn:aws:iam::083760424738:user/502827197"     # IBStudio FSSO
    #   username = "502827197"
    #   groups   = ["502827197"]
    # }        
]
