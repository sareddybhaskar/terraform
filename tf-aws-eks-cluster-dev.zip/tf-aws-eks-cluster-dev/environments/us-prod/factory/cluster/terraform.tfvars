region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
vpc_id = "vpc-09bade12fd82d9f5d"
subnet_ids = ["subnet-0c6a9716492447f30", "subnet-0327777b590356b0f"]

kubernetes_version = "1.33"
oidc_provider_enabled = false

cluster_name = "us-prod-factory"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 7
  
kms_key_arn = "arn:aws:kms:us-east-1:245792935030:key/fa5b95b8-d2c6-4518-9cfd-f87eaaeaddca"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App     = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-shared"
}

map_additional_aws_accounts = ["245792935030"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::245792935030:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

#map_additional_iam_users = [
#    {
#      userarn  = "arn:aws:iam::541574621075:user/502818692"     # Cloud FSSO
#      username = "502818692"
#      groups   = ["502818692"]
#    },
#    {
#      userarn  = "arn:aws:iam::541574621075:user/502827198"     # MDP-MR FSSO
#      username = "502827198"
#      groups   = ["502827198"]
#    },
#    {
#      userarn  = "arn:aws:iam::541574621075:user/502827197"     # IBStudio FSSO
#      username = "502827197"
#      groups   = ["502827197"]
#    }        
#]
