region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1b"]
vpc_id = "vpc-0c41a011b63bfe291"
subnet_ids = ["subnet-00bdab308e7788dec", "subnet-0b869ba7cb42153cd"]

kubernetes_version = "1.33"
oidc_provider_enabled = false

cluster_name = "us-aiml-exp-stg-factory-1"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 7
  
kms_key_arn = "arn:aws:kms:us-east-1:991497151145:key/ff225fd6-9d0c-4145-979e-0bce742b07f6"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Role = "dt-dna-shared"
    Program   = "ODP"
    uai        = "UAI3053026"
    Automation = "Jenkins"
    Environment  = "Innovation"
}

map_additional_aws_accounts = ["991497151145"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::991497151145:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

# map_additional_iam_users = [
#     {
#       userarn  = "arn:aws:iam::991497151145:user/502818692"     # Cloud FSSO
#       username = "502818692"
#       groups   = ["502818692"]
#     },
#     {
#       userarn  = "arn:aws:iam::991497151145:user/502827198"     # MDP-MR FSSO
#       username = "502827198"
#       groups   = ["502827198"]
#     },
#     {
#       userarn  = "arn:aws:iam::991497151145:user/502827197"     # IBStudio FSSO
#       username = "502827197"
#       groups   = ["502827197"]
#     }        
# ]
