provider "aws" {
  region = var.region
}

terraform {
  required_version = ">= 0.12.9, < 0.14.0"
  backend "s3" {
    bucket = "odp-fin-prod-terraform"
    key    = "terraform-state/fin-prod/eks/sox-factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}


locals {
  tags = merge(var.tags, map("kubernetes.io/cluster/${var.cluster_name}", "shared"))

  eks_worker_ami_name_filter = "amazon-eks-node-${var.kubernetes_version}*"
}

data "aws_vpc" "selected" {
  id = var.vpc_id
}

module "eks_cluster" {
#  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-eks.git//modules/eks/cluster?ref=tags/v1.0"
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-eks.git//modules/eks/cluster?ref=master"

  region                       = var.region
  vpc_id                       = var.vpc_id
  subnet_ids                   = var.subnet_ids
  cluster_name                 = var.cluster_name
  kubernetes_version           = var.kubernetes_version
  local_exec_interpreter       = var.local_exec_interpreter
  oidc_provider_enabled        = var.oidc_provider_enabled
  enabled_cluster_log_types    = var.enabled_cluster_log_types
  cluster_log_retention_period = var.cluster_log_retention_period
  allowed_cidr_blocks          = [data.aws_vpc.selected.cidr_block]
  map_additional_iam_users     = var.map_additional_iam_users
  map_additional_iam_roles     = var.map_additional_iam_roles
  # map_additional_aws_accounts  = var.map_additional_aws_accounts
  endpoint_private_access	     = var.endpoint_private_access
  endpoint_public_access       = var.endpoint_public_access
  tags                         = var.tags
  apply_config_map_aws_auth = false
  cluster_encryption_config_kms_key_id = var.kms_key_arn
  cluster_encryption_config_enabled = true

}

data "null_data_source" "wait_for_cluster_and_kubernetes_configmap" {
  inputs = {
    cluster_name             = module.eks_cluster.eks_cluster_id
    kubernetes_config_map_id = module.eks_cluster.kubernetes_config_map_id
  }
}

