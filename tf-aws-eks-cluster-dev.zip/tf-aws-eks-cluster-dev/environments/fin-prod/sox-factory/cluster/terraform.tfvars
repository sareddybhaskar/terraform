region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
vpc_id = "vpc-0305a7a8599bf52ed"
subnet_ids = ["subnet-0573a6d7e305dc30d", "subnet-0417460c21f3132b9"]

kubernetes_version = "1.33"
oidc_provider_enabled = false

cluster_name = "fin-prod-sox-factory"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 365
  
kms_key_arn = "arn:aws:kms:us-east-1:634123561912:key/2915414e-ad2c-4faa-a477-60e99071acd1"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Role = "dt-dna-aa-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "fin-prod"
}

map_additional_aws_accounts = ["634123561912"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::634123561912:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

map_additional_iam_users = [
    {
      userarn  = "arn:aws:iam::634123561912:user/502818692"     # Cloud FSSO
      username = "502818692"
      groups   = ["502818692"]
    }
    # {
    #   userarn  = "arn:aws:iam::634123561912:user/502827198"     # MDP-MR FSSO
    #   username = "502827198"
    #   groups   = ["502827198"]
    # },
    # {
    #   userarn  = "arn:aws:iam::634123561912:user/502827197"     # IBStudio FSSO
    #   username = "502827197"
    #   groups   = ["502827197"]
    # }        
]
