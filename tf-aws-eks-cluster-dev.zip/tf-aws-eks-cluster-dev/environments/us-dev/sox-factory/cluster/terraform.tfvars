region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
vpc_id = "vpc-07765370682ef3b06"
subnet_ids = ["subnet-0beae3c92d8c88390", "subnet-0a456f00392e571d0"]

kubernetes_version = "1.24"
oidc_provider_enabled = false

cluster_name = "us-dev-sox-factory"
enabled_cluster_log_types =  ["api", "audit", "authenticator", "controllerManager", "scheduler"]
endpoint_private_access	 = true
endpoint_public_access	 = false

cluster_log_retention_period = 365
  
kms_key_arn = "arn:aws:kms:us-east-1:541574621075:key/cc51aaed-6375-456a-b0c7-20ef72721002"

tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Role = "dt-dna-aa-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"
}

map_additional_aws_accounts = ["541574621075"]

map_additional_iam_roles = [
    {
      rolearn  = "arn:aws:iam::541574621075:role/hc-power-user"
      username = "cluster-admin"
      groups   = ["system:masters"]
    }   
]

# Add additional Project FSSO users here

map_additional_iam_users = [
    {
      userarn  = "arn:aws:iam::541574621075:user/502818692"     # Cloud FSSO
      username = "502818692"
      groups   = ["502818692"]
    }
    # {
    #   userarn  = "arn:aws:iam::541574621075:user/502827198"     # MDP-MR FSSO
    #   username = "502827198"
    #   groups   = ["502827198"]
    # },
    # {
    #   userarn  = "arn:aws:iam::541574621075:user/502827197"     # IBStudio FSSO
    #   username = "502827197"
    #   groups   = ["502827197"]
    # }        
]
