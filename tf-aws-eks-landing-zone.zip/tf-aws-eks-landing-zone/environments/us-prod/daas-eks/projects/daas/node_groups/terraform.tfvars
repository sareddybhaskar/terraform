region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0c6a9716492447f30", "subnet-0327777b590356b0f"]
vpc_id = "vpc-09bade12fd82d9f5d"
ge_network = ["10.0.0.0/8", "3.0.0.0/8"]

cluster_name = "us-prod-daas-eks"
kubernetes_version = "1.22"
instance_types = [ "t3a.medium" ]
desired_size = 0
max_size = 1
min_size = 0
disk_size = 400
ec2_ssh_key = "odp-us-prod-eks_kp"

project = "daas"

project_slug = "s-d"
kubernetes_labels = {
    project = "daas"
    team    = "daas"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  amazon-linux-extras install epel -y
  yum update -y
  yum install ansible git nano -y
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  cd /tmp/
  git clone https://502818692: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@github.build.ge.com/gehc-odp/2faldap-ranger-nifi-splunk-crowdstrike-qualys.git
  ansible-playbook 2faldap-ranger-nifi-splunk-crowdstrike-qualys/playbook-eks-usprod.yml
  rm -rf 2faldap-ranger-nifi-splunk-crowdstrike-qualys 
  EOT

tags = {
    ManagedBy = "Terraform"
    Project = "daas"
    App = "daas"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-daas"
    Owner =	"abhijit.j.jadhav@ge.com"
    Contact	= "odp.daas.nrt.pod@ge.com:odpdaas.det@ge.com:odp-daas.support@ge.com"
}
