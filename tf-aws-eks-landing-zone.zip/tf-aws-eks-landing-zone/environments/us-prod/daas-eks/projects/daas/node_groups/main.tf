provider "aws" {
  region = var.region
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/daas-eks/projects/daas/node-groups/terraform.tfstate"
    region = "us-east-1"
  }
}

#data "terraform_remote_state" "eks" {
#  backend = "s3"
#  config = {
#    bucket = "odp-us-prod-terraform"
#    key    = "terraform-state/prod-us/pocs/k8s/eks1/terraform.tfstate"
#    region = "us-east-1"
#  }
#}

locals {
  tags = merge(var.tags, map("kubernetes.io/cluster/us-prod-daas-eks", "shared"))

  eks_worker_ami_name_filter = "amazon-eks-node-${var.kubernetes_version}*"
}

data "aws_vpc" "selected" {
  id = var.vpc_id
}


module "eks_node_group" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-eks.git//modules/eks/node-group?ref=master"

  subnet_ids         = var.subnet_ids
  cluster_name       = "us-prod-daas-eks"
  node_role_arn      = "arn:aws:iam::245792935030:role/us-prod-daas-eks20200603065657218200000007"
  instance_types     = var.instance_types
  desired_size       = var.desired_size
  min_size           = var.min_size
  max_size           = var.max_size
  kubernetes_version = var.kubernetes_version
  kubernetes_labels  = var.kubernetes_labels
  disk_size          = var.disk_size
  tags               = var.tags
  create_before_destroy = var.create_before_destroy

  cidr_blocks        = concat(sort([data.aws_vpc.selected.cidr_block]), sort(var.ge_network))
  project            = var.project
  project_slug       = var.project_slug

  ec2_ssh_key        = var.ec2_ssh_key
  source_security_group_ids = ["sg-03714483b9b138143"]
  
  # resources_to_tag = ""
  after_cluster_joining_userdata = var.after_cluster_joining_userdata

}
