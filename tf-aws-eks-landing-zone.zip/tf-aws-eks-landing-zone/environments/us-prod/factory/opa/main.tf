provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "245792935030",
  ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/opa/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

#data "terraform_remote_state" "irsa" {
#  backend = "s3"
#  config = {
#    bucket = "odp-us-prod-terraform"
#    key    = "terraform-state/prod-us/eks/factory/projects/mdp-mr/irsa/terraform.tfstate"
#    region = "us-east-1"
#  }
#}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  version                = "~> 2.0.2"
}

##################################################################


data "kubectl_path_documents" "opa" {
  pattern = "${path.module}/manifests/*.yaml"
    vars = {
        privileged_namespaces = local.privileged_namespaces
        excluded_namespaces = local.excluded_namespaces
    }  
}

resource "kubectl_manifest" "opa" {
  count     = length(data.kubectl_path_documents.opa.documents)
  yaml_body = element(data.kubectl_path_documents.opa.documents, count.index)
}

##################################################################