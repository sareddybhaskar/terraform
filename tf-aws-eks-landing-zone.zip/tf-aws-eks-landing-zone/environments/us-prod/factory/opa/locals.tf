locals {
    privileged_namespaces = join(",",
                              [ 
                                "default",
                                "ibstudio",
                                "helloworld-nodejs",
                                "helloworld-spring",
                                "python-flask",
                                "start",
                                "bats",
                                "ui",
                                "tubewatch",
                                "daas",
                                "start-mlops",
                                "mdp-daas",
                                "prod-cdx-ca-daas",
                                "hr-data-learning",
                                "hr-data-other",
                                "hr-data-worker",
                                "hr-data-searchapi",
                                "daas2admin"
                              ])



    excluded_namespaces = join(",", 
                            [   "kube-system",
                                "gatekeeper-system",
                                "amazon-cloudwatch",
                                "aws-xray",
                                "ingress-nginx",
                                "kube-node-lease",
                                "kube-public",
                                "kubernetes-dashboard",
                                "ibstudio-tls-ingress-nginx",
                                "monitoring",
                                "helloworld-tls-ingress-nginx",
                                "start-tls-ingress-nginx",
                                "tubewatch-tls-ingress-nginx",
                                "start-tls-cloud-ingress-nginx",
                                "daas-tls-ingress-nginx",
                                "start-mlops-tls-ingress-nginx",
                                "mdp-daas-tls-ingress-nginx",
                                "hr-data-learning-tls-ingress-nginx",
                                "hr-data-other-tls-ingress-nginx",
                                "hr-data-worker-tls-ingress-nginx",
                                "hr-data-searchapi-tls-ingress-nginx",
                                "daas2admin-tls-ingress-nginx"
                            ])
}
