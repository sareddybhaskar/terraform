locals {

    namespace_name = "hr-data-searchapi"
}
