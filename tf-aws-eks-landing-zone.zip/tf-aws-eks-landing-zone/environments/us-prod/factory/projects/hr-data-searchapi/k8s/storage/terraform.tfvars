# Namespace and team 

labels = {
    project = "hr-data-searchapi"
    team    = "hr-data-searchapi"
    program  = "odp"
}
