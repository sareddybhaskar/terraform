locals {
  namespace               = "ingress-nginx"
  project                 = "hr-data-searchapi"
}