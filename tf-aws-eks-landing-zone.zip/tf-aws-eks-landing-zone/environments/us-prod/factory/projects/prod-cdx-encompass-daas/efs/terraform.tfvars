region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0d3a77c56f0b4a809", "subnet-08218951d2463ab92"]
vpc_id = "vpc-09bade12fd82d9f5d"
allowed_cidr_blocks = ["100.64.0.0/16"]

efs_name = "odp-us-prod-eks-factory-prod-cdx-encompass-daas"

tags = {
    ManagedBy = "Terraform"
    Project = "dt-cdx"
    App = "cdx-encompass"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-cdx-encompass-factory"
    Owner = "alok.ojha@ge.com:sujit.singh@ge.com"
    Contact = "cdx.daas.support@ge.com"
}
