locals {
  # namespace               = "ingress-nginx"
  project                 = "prod-cdx-encompass-daas-tls"
}
