region = "us-east-1"

# Use lower case letters
project = "prod-cdx-encompass-daas"

tags = {
    ManagedBy = "Terraform"
    Project = "dt-cdx"
    App = "cdx-encompass"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-cdx-encompass-factory"
    Owner = "alok.ojha@ge.com:sujit.singh@ge.com"
    Contact = "cdx.daas.support@ge.com"
}


