locals {

    namespace_name = "prod-cdx-encompass-daas"
}
