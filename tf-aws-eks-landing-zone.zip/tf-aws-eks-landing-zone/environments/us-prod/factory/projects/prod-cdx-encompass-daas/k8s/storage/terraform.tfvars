# Namespace and team 

labels = {
    project = "prod-cdx-encompass-daas"
    team    = "prod-cdx-encompass-daas"
    program  = "odp"
}
