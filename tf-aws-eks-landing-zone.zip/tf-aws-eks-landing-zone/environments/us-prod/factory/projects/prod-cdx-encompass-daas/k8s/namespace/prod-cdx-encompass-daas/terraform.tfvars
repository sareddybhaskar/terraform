# Namespace and team 

namespace = "prod-cdx-encompass-daas"
project = "prod-cdx-encompass-daas"

# User SSO
k8s_user = "502822749" ## Ex:- FSSO 50312512 502822749

region = "us-east-1"
environment = "prod"

tags = {
    ManagedBy = "Terraform"
    Project = "dt-cdx"
    App = "cdx-encompass"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-cdx-encompass-factory"
    Owner = "alok.ojha@ge.com:sujit.singh@ge.com"
    Contact = "cdx.daas.support@ge.com"
}
