1. node-groups
2. efs
3. k8s/namespace_irsa/**
4. ingress/nginx-tls - follow the below order
	a. (kubectl apply manifests/class.yaml manifests/ns.yaml  manifests/svc.yaml)
	b. (kubectl apply manifests/service-accounts.yaml manifests/sa-secret-tokens.yaml)
	c. run tf commands to deploy ingress 
5. k8s/namespace/**
	a. create namespace using tf
	b. (kubectl apply manifests/service-accounts.yaml manifests/sa-secret-tokens.yaml)
6. k8s/storage/**
	create storage using tf
Add aws-auth cm to authenticate users to namespace