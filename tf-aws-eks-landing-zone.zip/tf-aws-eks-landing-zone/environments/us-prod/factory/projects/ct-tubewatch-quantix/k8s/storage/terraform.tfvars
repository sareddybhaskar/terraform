# Namespace and team 

labels = {
    project = "ct-tubewatch-quantix"
    team    = "ct-tubewatch-quantix"
    program  = "odp"
}
