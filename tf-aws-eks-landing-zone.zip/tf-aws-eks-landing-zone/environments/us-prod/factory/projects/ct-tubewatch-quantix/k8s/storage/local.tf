locals {

    namespace_name = "ct-tubewatch-quantix"
}
