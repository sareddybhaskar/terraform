


resource "kubernetes_role" "user_role" {
  count      = 1

  metadata {
    name        = "${var.namespace}-role"
    namespace   = var.namespace
    labels      = var.labels
    # annotations = var.annotations
  }

  rule {
    api_groups = [
      "",
      "batch",
      "extensions",
      "apps",
      "autoscaling"
    ]

    resources = [
      "configmaps",
      "cronjobs",
      "deployments",
      "events",
      "ingresses",
      "jobs",
      "pods",
      "pods/attach",
      "pods/exec",
      "pods/log",
      "pods/portforward",
      "pods/eviction",
      "secrets",
      "services",
      "endpoints",
      "replicasets",
      "daemonsets",
      "statefulsets",
      "replicationcontrollers",
      "horizontalpodautoscalers"
    ]
    verbs = [
      "create",
      "delete",
      "describe",
      "get",
      "list",
      "patch",
      "update",
      "watch",      
    ]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = [""]
    resources  = ["persistentvolumeclaims"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["storage.k8s.io"]
    resources  = ["csidrivers"]
  }

  rule {
    verbs      = ["get", "list", "watch","create","delete","describe", "patch", "update"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingresses"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["bitnami.com"]
    resources  = ["sealedsecrets"]
  }
}


resource "kubernetes_role_binding" "user_rb" {

  metadata {
    name      = "${var.namespace}-role-binding"
    namespace = var.namespace
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = kubernetes_role.user_role[0].metadata[0].name
  }

  subject {
    kind      = "User"
    name      = var.k8s_user
    namespace = var.namespace
  }
}
