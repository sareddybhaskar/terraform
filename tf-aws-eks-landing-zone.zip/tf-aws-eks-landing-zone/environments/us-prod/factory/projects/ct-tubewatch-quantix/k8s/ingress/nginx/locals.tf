locals {
  namespace               = "ingress-nginx"
  project                 = "dev-mdp-daas"
}