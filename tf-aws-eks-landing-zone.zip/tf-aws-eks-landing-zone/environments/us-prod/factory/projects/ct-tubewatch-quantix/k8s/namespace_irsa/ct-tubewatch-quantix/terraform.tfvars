region = "us-east-1"

# Use lower case letters
project = "ct-tubewatch-quantix"

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-tubewatch"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dst-tubewatch-factory"
    Owner = "gaur.hazra@ge.com:senthil.nedunchezhian@ge.com"
    Contact = "Services_Predictive_Analytics_DnA_Dev_Team@ge.com"
}


