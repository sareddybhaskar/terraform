# Namespace and team 

namespace = "ct-tubewatch-quantix"
project = "ct-tubewatch-quantix"

# User SSO
k8s_user = "502830887" ## Ex:- FSSO 50312512 502822749

region = "us-east-1"
environment = "prod"

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-tubewatch"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dst-tubewatch-factory"
    Owner = "gaur.hazra@ge.com:senthil.nedunchezhian@ge.com"
    Contact = "Services_Predictive_Analytics_DnA_Dev_Team@ge.com"
}