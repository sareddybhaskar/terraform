

variable "labels" {
  type        = map(string)
  default     = {}
}
