output "eks_cluster_id" {
  description = "The name of the cluster"
  value       = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

output "this_iam_role_arn" {
  description = "ARN of the worker nodes IAM role"
  value       = module.iam_assumable_role_admin.this_iam_role_arn
}

