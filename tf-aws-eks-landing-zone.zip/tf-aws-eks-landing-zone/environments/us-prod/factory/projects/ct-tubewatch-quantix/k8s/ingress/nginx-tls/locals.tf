locals {
  # namespace               = "ingress-nginx"
  project                 = "ct-tubewatch-quantix-tls"
}
