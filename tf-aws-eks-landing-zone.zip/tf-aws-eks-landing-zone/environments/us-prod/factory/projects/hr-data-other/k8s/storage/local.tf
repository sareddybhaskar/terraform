locals {

    namespace_name = "hr-data-other"
}
