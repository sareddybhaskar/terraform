region = "us-east-1"

# Use lower case letters
project = "hr-data-other"

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-hr"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-hr-hrdata-factory"
    Owner = "grzegorz.hadro@ge.com"
    Contact = "it.D_A.HR@ge.com"
}
