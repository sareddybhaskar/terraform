locals {
  # namespace               = "ingress-nginx"
  project                 = "hr-data-other-tls"
}
