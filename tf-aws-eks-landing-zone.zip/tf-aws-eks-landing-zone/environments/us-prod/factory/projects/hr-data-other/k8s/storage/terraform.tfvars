# Namespace and team 

labels = {
    project = "hr-data-other"
    team    = "hr-data-other"
    program  = "odp"
}
