provider "aws" {
  region = var.region
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/daas/efs/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "sg" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/daas/node-groups/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_caller_identity" "current" {}


module "efs" {

  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/efs_new?ref=dev"

  name            = "${var.efs_name}-efs"
  region          = var.region
  vpc_id          = var.vpc_id
  subnets         = var.subnet_ids
  security_groups = [data.terraform_remote_state.sg.outputs.eks_node_group_remote_access_security_group_id]
  allowed_cidr_blocks = var.allowed_cidr_blocks
  
  encrypted = true
  tags = var.tags

  access_points = {
     "daas/nrt" = {
        posix_user = {
          uid      = 1001
          gid      = 1001        
          secondary_gids =  [2000, 2001]
        }
        creation_info = {
          uid      = 1001
          gid      = 1001
          permissions    = 755     
        }        
     },
  }
}