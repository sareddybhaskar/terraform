locals {

    daas_namespace = "daas"
}