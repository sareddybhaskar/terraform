locals {
  namespace               = "ingress-nginx"
  project                 = "dev-ibstudio"
}