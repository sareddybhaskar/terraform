# Namespace and team 

namespace = "daas"
project = "daas"

# User SSO
k8s_user = "daas" ## Ex:- FSSO 50312512