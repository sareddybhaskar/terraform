locals {
  # namespace               = "ingress-nginx"
  project                 = "daas-tls"
}