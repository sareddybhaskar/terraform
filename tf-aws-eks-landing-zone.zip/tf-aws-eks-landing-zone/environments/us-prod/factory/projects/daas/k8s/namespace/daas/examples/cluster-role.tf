# resource "kubernetes_cluster_role" "this" {
#   count      = 1

#   metadata {
#     name        = "${var.namespace}-cluster-role"
#     labels      = var.labels
#   }

#   rule {
#     verbs      = ["get", "list", "watch"]
#     api_groups = ["storage.k8s.io"]
#     resources  = ["csidrivers"]
#   }
# }


# resource "kubernetes_cluster_role_binding" "this" {

#   metadata {
#     name      = "${var.namespace}-cluster-role-binding"
#   }
#   role_ref {
#     api_group = "rbac.authorization.k8s.io"
#     kind      = "ClusterRole"
#     name      = kubernetes_cluster_role.this[0].metadata[0].name
#   }

#   subject {
#     kind      = "User"
#     name      = var.fsso_user
#     namespace = var.namespace
#   }
# }