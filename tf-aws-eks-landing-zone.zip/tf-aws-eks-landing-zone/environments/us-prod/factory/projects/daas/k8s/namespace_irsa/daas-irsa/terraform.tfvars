region = "us-east-1"

# Use lower case letters
project = "daas"

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-daas"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"    
    Role = "dt-dna-daas"
}



