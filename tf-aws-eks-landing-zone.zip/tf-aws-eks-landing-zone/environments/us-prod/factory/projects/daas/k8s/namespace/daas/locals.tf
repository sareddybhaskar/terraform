# locals {
#   container_cpu_default    = var.max_cpu == 0 ? {} : { cpu = "50m" }
#   container_memory_default = var.max_memory == 0 ? {} : { memory = "64Mi" }
#   storage_amount_default   = var.max_storage == 0 ? {} : { storage = "2Gi" }
# }

# Apply after IRSA

locals {
  irsa_sa_role_arn  = data.terraform_remote_state.irsa.outputs.this_iam_role_arn
}