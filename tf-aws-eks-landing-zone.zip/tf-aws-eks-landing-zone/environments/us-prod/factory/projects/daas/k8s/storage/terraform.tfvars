# Namespace and team 

labels = {
    project = "daas"
    team    = "daas"
    program  = "odp"
}
