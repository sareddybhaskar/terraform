# resource "kubernetes_namespace" "ingress_nginx" {
#   metadata {
#     name = "${local.project}-ingress-nginx"

#     labels = {
#       "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"
#       "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
#     }
#   }
# }

resource "kubernetes_service_account" "ingress_nginx" {
  metadata {
    name      = "${local.project}-ingress-nginx"
    namespace = "${local.project}-ingress-nginx"
    

    labels = {
      "app.kubernetes.io/component" = "${local.project}-controller"
      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/managed-by" = "Helm"
      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/version" = "0.43.0"
      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }
}

resource "kubernetes_config_map" "ingress_nginx_controller" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name      = "${local.project}-ingress-nginx-controller"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-controller"
      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/managed-by" = "Helm"
      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/version" = "0.43.0"
      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }  
  data = {
    "server-name-hash-bucket-size" = "128"
    "large-client-header-buffers" = "4 16k"

    http-snippet = "server {\n  listen 2443;\n  return 308 https://$host$request_uri;\n}\n"
    proxy-real-ip-cidr = "0.0.0.0/0"
    use-forwarded-headers = "true"
  }
}

resource "kubernetes_cluster_role" "ingress_nginx" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/managed-by" = "Helm"
      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/version" = "0.43.0"
      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }

  rule {
    verbs      = ["list", "watch", "get"]
    api_groups = [""]
    resources  = ["configmaps", "endpoints", "nodes", "pods", "secrets", "namespaces"]
  }

  rule {
    verbs      = ["list", "watch"]
    api_groups = ["coordination.k8s.io"]
    resources  = ["leases"]
  }

  rule {
    verbs      = ["get"]
    api_groups = [""]
    resources  = ["nodes"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = [""]
    resources  = ["services"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingresses"]
  }

  rule {
    verbs      = ["create", "patch"]
    api_groups = [""]
    resources  = ["events"]
  }

  rule {
    verbs      = ["update"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingresses/status"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingressclasses"]
  }

  rule {
    verbs      = ["list", "watch", "get"]
    api_groups = ["discovery.k8s.io"]
    resources  = ["endpointslices"]
  }
}

resource "kubernetes_cluster_role_binding" "ingress_nginx" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }

  subject {
    kind      = "ServiceAccount"
    name      = "${local.project}-ingress-nginx"
    namespace = "${local.project}-ingress-nginx"
  }

  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = "${local.project}-ingress-nginx"
  }
}

resource "kubernetes_role" "ingress_nginx" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name      = "${local.project}-ingress-nginx"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-controller"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }

  rule {
    verbs      = ["get"]
    api_groups = [""]
    resources  = ["namespaces"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = [""]
    resources  = ["configmaps", "pods", "secrets", "endpoints"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = [""]
    resources  = ["services"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingresses"]
  }

  rule {
    verbs      = ["update"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingresses/status"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingressclasses"]
  }

  rule {
    verbs          = ["get", "update"]
    api_groups     = ["coordination.k8s.io"]
    resources      = ["leases"]
    resource_names = ["ingress-nginx-leader"]
  }

  rule {
    verbs      = ["create", "update", "get", "list", "watch"]
    api_groups = ["coordination.k8s.io"]
    resources  = ["leases"]
  }

  rule {
    verbs      = ["create", "patch"]
    api_groups = [""]
    resources  = ["events"]
  }

  rule {
    verbs      = ["list", "watch", "get"]
    api_groups = ["discovery.k8s.io"]
    resources  = ["endpointslices"]
  }

  rule {
    verbs          = ["get", "update"]
    api_groups     = [""]
    resources      = ["configmaps"]
    resource_names = ["ingress-controller-leader-${local.project}-nginx"]
  }

  rule {
    verbs      = ["create"]
    api_groups = [""]
    resources  = ["configmaps"]
  }
}

resource "kubernetes_role_binding" "ingress_nginx" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name      = "${local.project}-ingress-nginx"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-controller"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }

  subject {
    kind      = "ServiceAccount"
    name      = "${local.project}-ingress-nginx"
    namespace = "${local.project}-ingress-nginx"
  }

  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = "${local.project}-ingress-nginx"
  }
}

resource "kubernetes_service" "ingress_nginx_controller_admission" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name      = "${local.project}-ingress-nginx-controller-admission"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-controller"
      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/managed-by" = "Helm"
      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/version" = "0.43.0"
      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }

  spec {
    port {
      name        = "https-webhook"
      port        = 443
      target_port = "webhook"
    }

    selector = {
      "app.kubernetes.io/component" = "${local.project}-controller"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
    }

    type = "ClusterIP"
  }
}

# resource "kubernetes_service" "ingress_nginx_controller" {

#   depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission ]

#   metadata {
#     name      = "${local.project}-ingress-nginx-controller"
#     namespace = "${local.project}-ingress-nginx"

#     labels = {
#       "app.kubernetes.io/component" = "${local.project}-controller"

#       "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

#       "app.kubernetes.io/managed-by" = "Helm"

#       "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

#       "app.kubernetes.io/version" = "0.43.0"

#       "helm.sh/chart" = "ingress-nginx-3.21.0"
#     }

#     annotations = {
#       "service.beta.kubernetes.io/aws-load-balancer-connection-idle-timeout" =  "4000"
#       "service.beta.kubernetes.io/aws-load-balancer-internal" =  "0.0.0.0/0"
#       "service.beta.kubernetes.io/aws-load-balancer-proxy-protocol" = "*"      
#     }
#   }

#   spec {
#     port {
#       name        = "http"
#       protocol    = "TCP"
#       port        = 80
#       target_port = "http"
#     }

#     port {
#       name        = "https"
#       protocol    = "TCP"
#       port        = 443
#       target_port = "https"
#     }

#     selector = {
#       "app.kubernetes.io/component" = "${local.project}-controller"

#       "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

#       "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
#     }

#     type                    = "LoadBalancer"
#     external_traffic_policy = "Cluster"
#   }
# }

resource "kubernetes_deployment" "ingress_nginx_controller" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission ]

  metadata {
    name      = "${local.project}-ingress-nginx-controller"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-controller"
      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/managed-by" = "Helm"
      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/version" = "0.43.0"
       "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }

  spec {
    selector {
      match_labels = {
        "app.kubernetes.io/component" = "${local.project}-controller"

        "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

        "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
      }
    }

    template {
      metadata {
        labels = {
          "app.kubernetes.io/component" = "${local.project}-controller"

          "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

          "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
        }
      }

      spec {
        volume {
          name = "webhook-cert"

          secret {
            secret_name = "${local.project}-ingress-nginx-admission"
          }
        }
        automount_service_account_token = true
        container {
          name  = "controller"
          image = "registry.k8s.io/ingress-nginx/controller:v1.1.3@sha256:15be4666c53052484dd2992efacf2f50ea77a78ae8aa21ccd91af6baaa7ea22f"
          args  = ["/nginx-ingress-controller", "--watch-ingress-without-class=true", "--publish-service=$(POD_NAMESPACE)/${local.project}-ingress-nginx-controller", "--election-id=ingress-controller-leader", "--controller-class=k8s.io/${local.project}-nginx", "--ingress-class=${local.project}-nginx", "--configmap=$(POD_NAMESPACE)/${local.project}-ingress-nginx-controller", "--validating-webhook=:8443", "--validating-webhook-certificate=/usr/local/certificates/cert", "--validating-webhook-key=/usr/local/certificates/key"]

          port {
            name           = "http"
            container_port = 80
            protocol       = "TCP"
          }

          port {
            name           = "https"
            container_port = 80
            protocol       = "TCP"
          }

          port {
            name           = "tohttps"
            container_port = 2443
            protocol       = "TCP"
          }
          
          port {
            name           = "webhook"
            container_port = 8443
            protocol       = "TCP"
          }

          env {
            name = "POD_NAME"

            value_from {
              field_ref {
                field_path = "metadata.name"
              }
            }
          }

          env {
            name = "POD_NAMESPACE"

            value_from {
              field_ref {
                field_path = "metadata.namespace"
              }
            }
          }

          env {
            name  = "LD_PRELOAD"
            value = "/usr/local/lib/libmimalloc.so"
          }

          resources {
            requests {
              memory = "90Mi"
              cpu    = "100m"
            }
          }

          volume_mount {
            name       = "webhook-cert"
            read_only  = true
            mount_path = "/usr/local/certificates/"
          }

          liveness_probe {
            http_get {
              path   = "/healthz"
              port   = "10254"
              scheme = "HTTP"
            }

            initial_delay_seconds = 10
            timeout_seconds       = 1
            period_seconds        = 10
            success_threshold     = 1
            failure_threshold     = 5
          }

          readiness_probe {
            http_get {
              path   = "/healthz"
              port   = "10254"
              scheme = "HTTP"
            }

            initial_delay_seconds = 10
            timeout_seconds       = 1
            period_seconds        = 10
            success_threshold     = 1
            failure_threshold     = 3
          }

          lifecycle {
            pre_stop {
              exec {
                command = ["/wait-shutdown"]
              }
            }
          }

          image_pull_policy = "IfNotPresent"

          security_context {
            capabilities {
              add  = ["NET_BIND_SERVICE"]
              drop = ["ALL"]
            }

            run_as_user                = 101
            allow_privilege_escalation = true
          }
        }

        termination_grace_period_seconds = 300
        dns_policy                       = "ClusterFirst"

        node_selector = {
          "kubernetes.io/os" = "linux"
          "project" = "odp"
        }

        service_account_name = "${local.project}-ingress-nginx"
      }
    }

    revision_history_limit = 10
  }
}

resource "kubernetes_validating_webhook_configuration" "ingress_nginx_admission" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name = "${local.project}-ingress-nginx-admission"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }
  }

  webhook {
    name = "validate.nginx.ingress.kubernetes.io"

    client_config {
      service {
        namespace = "${local.project}-ingress-nginx"
        name      = "${local.project}-ingress-nginx-controller-admission"
        path      = "/networking/v1beta1/ingresses"
      }
    }

    rule {
      api_groups = ["networking.k8s.io"]
      api_versions = ["v1beta1"]
      resources  = ["ingresses"]
      operations = ["CREATE", "UPDATE"]
    }

    failure_policy            = "Ignore"
    match_policy              = "Equivalent"
    side_effects              = "None"
    admission_review_versions = ["v1", "v1beta1"]
  }

  lifecycle {
    ignore_changes = [
      webhook,
    ]
  }

}

resource "kubernetes_service_account" "ingress_nginx_admission" {

  # depends_on = [kubernetes_namespace.ingress_nginx ]
  metadata {
    name      = "${local.project}-ingress-nginx-admission"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }

    annotations = {
      "helm.sh/hook" = "pre-install,pre-upgrade,post-install,post-upgrade"

      "helm.sh/hook-delete-policy" = "before-hook-creation,hook-succeeded"
    }
  }
}

resource "kubernetes_cluster_role" "ingress_nginx_admission" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]
  metadata {
    name = "${local.project}-ingress-nginx-admission"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }

    annotations = {
      "helm.sh/hook" = "pre-install,pre-upgrade,post-install,post-upgrade"

      "helm.sh/hook-delete-policy" = "before-hook-creation,hook-succeeded"
    }
  }

  rule {
    verbs      = ["get", "update"]
    api_groups = ["admissionregistration.k8s.io"]
    resources  = ["validatingwebhookconfigurations"]
  }
}

resource "kubernetes_cluster_role_binding" "ingress_nginx_admission" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name = "${local.project}-ingress-nginx-admission"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }

    annotations = {
      "helm.sh/hook" = "pre-install,pre-upgrade,post-install,post-upgrade"

      "helm.sh/hook-delete-policy" = "before-hook-creation,hook-succeeded"
    }
  }

  subject {
    kind      = "ServiceAccount"
    name      = "${local.project}-ingress-nginx-admission"
    namespace = "${local.project}-ingress-nginx"
  }

  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = "${local.project}-ingress-nginx-admission"
  }
}

resource "kubernetes_role" "ingress_nginx_admission" {
  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]
  metadata {
    name      = "${local.project}-ingress-nginx-admission"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }

    annotations = {
      "helm.sh/hook" = "pre-install,pre-upgrade,post-install,post-upgrade"

      "helm.sh/hook-delete-policy" = "before-hook-creation,hook-succeeded"
    }
  }

  rule {
    verbs      = ["get", "create"]
    api_groups = [""]
    resources  = ["secrets"]
  }
}

resource "kubernetes_role_binding" "ingress_nginx_admission" {
  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]
  metadata {
    name      = "${local.project}-ingress-nginx-admission"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }

    annotations = {
      "helm.sh/hook" = "pre-install,pre-upgrade,post-install,post-upgrade"

      "helm.sh/hook-delete-policy" = "before-hook-creation,hook-succeeded"
    }
  }

  subject {
    kind      = "ServiceAccount"
    name      = "${local.project}-ingress-nginx-admission"
    namespace = "${local.project}-ingress-nginx"
  }

  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = "${local.project}-ingress-nginx-admission"
  }
}

resource "kubernetes_job" "ingress_nginx_admission_create" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]
  metadata {
    name      = "${local.project}-ingress-nginx-admission-create"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"

      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/managed-by" = "Helm"

      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

      "app.kubernetes.io/version" = "0.43.0"

      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }

    annotations = {
      "helm.sh/hook" = "pre-install,pre-upgrade"

      "helm.sh/hook-delete-policy" = "before-hook-creation,hook-succeeded"
    }
  }

  spec {
    template {
      metadata {
        name = "ingress-nginx-admission-create"

        labels = {
          "app.kubernetes.io/component" = "${local.project}-admission-webhook"

          "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

          "app.kubernetes.io/managed-by" = "Helm"

          "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

          "app.kubernetes.io/version" = "0.43.0"

          "helm.sh/chart" = "ingress-nginx-3.21.0"
        }
      }

      spec {
        automount_service_account_token = true
        container {
          name  = "create"
          image = "docker.io/jettech/kube-webhook-certgen:v1.5.1"
          args  = ["create", "--host=${local.project}-ingress-nginx-controller-admission,${local.project}-ingress-nginx-controller-admission.$(POD_NAMESPACE).svc", "--namespace=$(POD_NAMESPACE)", "--secret-name=${local.project}-ingress-nginx-admission"]

          env {
            name = "POD_NAMESPACE"

            value_from {
              field_ref {
                field_path = "metadata.namespace"
              }
            }
          }

          image_pull_policy = "IfNotPresent"
        }

        restart_policy       = "OnFailure"
        service_account_name = "${local.project}-ingress-nginx-admission"

        security_context {
          run_as_user     = 2000
          run_as_non_root = true
        }
        node_selector = {
          "kubernetes.io/os" = "linux"
          "project" = "odp"
        }        
      }
    }
  }
}

resource "kubernetes_job" "ingress_nginx_admission_patch" {

  depends_on = [kubernetes_service_account.ingress_nginx, kubernetes_service_account.ingress_nginx_admission  ]

  metadata {
    name      = "${local.project}-ingress-nginx-admission-patch"
    namespace = "${local.project}-ingress-nginx"

    labels = {
      "app.kubernetes.io/component" = "${local.project}-admission-webhook"
      "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/managed-by" = "Helm"
      "app.kubernetes.io/name" = "${local.project}-ingress-nginx"
      "app.kubernetes.io/version" = "0.43.0"
      "helm.sh/chart" = "ingress-nginx-3.21.0"
    }

    annotations = {
      "helm.sh/hook" = "post-install,post-upgrade"

      "helm.sh/hook-delete-policy" = "before-hook-creation,hook-succeeded"
    }
  }

  spec {
    template {
      metadata {
        name = "ingress-nginx-admission-patch"

        labels = {
          "app.kubernetes.io/component" = "${local.project}-admission-webhook"

          "app.kubernetes.io/instance" = "${local.project}-ingress-nginx"

          "app.kubernetes.io/managed-by" = "Helm"

          "app.kubernetes.io/name" = "${local.project}-ingress-nginx"

          "app.kubernetes.io/version" = "0.43.0"

          "helm.sh/chart" = "ingress-nginx-3.21.0"
        }
      }

      spec {
        automount_service_account_token = true
        container {
          name  = "patch"
          image = "docker.io/jettech/kube-webhook-certgen:v1.5.1"
          args  = ["patch", "--webhook-name=${local.project}-ingress-nginx-admission", "--namespace=$(POD_NAMESPACE)", "--patch-mutating=false", "--secret-name=${local.project}-ingress-nginx-admission", "--patch-failure-policy=Fail"]

          env {
            name = "POD_NAMESPACE"

            value_from {
              field_ref {
                field_path = "metadata.namespace"
              }
            }
          }

          image_pull_policy = "IfNotPresent"
        }

        restart_policy       = "OnFailure"
        service_account_name = "${local.project}-ingress-nginx-admission"

        security_context {
          run_as_user     = 2000
          run_as_non_root = true
        }
        node_selector = {
          "kubernetes.io/os" = "linux"
          "project" = "odp"
        }        
      }
    }
  }
}

