region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0d3a77c56f0b4a809", "subnet-08218951d2463ab92"]
vpc_id = "vpc-09bade12fd82d9f5d"

kubernetes_version = "1.25"
instance_types = ["c7i.8xlarge" ]
desired_size = 1
max_size = 1
min_size = 1
disk_size = 500
ec2_ssh_key = "odp-us-prod-tools_kp"

project = "daas"

project_slug = "daas"
kubernetes_labels = {
    project = "daas"
    team    = "daas"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  amazon-linux-extras install epel -y
  yum update -y
  yum install ansible git nano -y
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  cd /tmp/
  git clone https://502818692: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@github.gehealthcare.com/gehc-odp/2faldap-ranger-nifi-splunk-crowdstrike-qualys.git
  ansible-playbook 2faldap-ranger-nifi-splunk-crowdstrike-qualys/playbook-eks-usprod.yml
  rm -rf 2faldap-ranger-nifi-splunk-crowdstrike-qualys 
  EOT


tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-daas"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-daas"
    Owner = "abhijit.J.jadhav@ge.com"
    Contact = "odpdaas.det@ge.com:odp.daas.NRT.pod@ge.com:odp-daas.support@ge.com"
}
