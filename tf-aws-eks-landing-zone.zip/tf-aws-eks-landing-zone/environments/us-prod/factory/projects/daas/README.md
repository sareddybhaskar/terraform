# Deploy sequence
1. opa/local.tf --> update namespace and tls namespace and apply configuration to cluster.
2. node-groups
3. efs
4. k8s/namespace_irsa/**
5. ingress/nginix-tls/manifest/ingres-ns.yaml
6. ingress/nginix-tls/manifest/ingres-svc-tls.yaml
7. k8s/namespace/**
8. k8s/storage-class/**
9. Add aws-auth cm to authenticate users to namespace

aws-auth upsert --mapusers --userarn arn:aws:iam::245792935030:user/504001219 --username daas --groups daas
