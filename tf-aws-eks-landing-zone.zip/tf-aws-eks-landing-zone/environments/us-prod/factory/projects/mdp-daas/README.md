# Deploy sequence
1. opa/local.tf --> update namespace and tls namespace and apply configuration to cluster.
2. node-groups
3. efs
4. k8s/namespace_irsa/**
5. ingress/nginix-tls/manifest/ingres-ns.yaml
6. ingress/nginix-tls/manifest/ingres-svc-tls.yaml
7. ingress/nginx-tls/ -- terraform apply
8. k8s/namespace/**
9. k8s/storage-class/**
10. Add aws-auth cm to authenticate users to namespace

aws-auth upsert --mapusers --userarn arn:aws:iam::245792935030:user/504002857 --username mdp-daas --groups mdp-daas
