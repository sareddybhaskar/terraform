# Namespace and team 

labels = {
    project = "mdp-daas"
    team    = "mdp-daas"
    program  = "odp"
}
