locals {

    mdp_daas_namespace = "mdp-daas"
}