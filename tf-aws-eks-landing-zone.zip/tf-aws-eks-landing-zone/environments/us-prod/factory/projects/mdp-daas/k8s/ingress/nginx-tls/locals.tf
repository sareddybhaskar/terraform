locals {
  # namespace               = "ingress-nginx"
  project                 = "mdp-daas-tls"
}