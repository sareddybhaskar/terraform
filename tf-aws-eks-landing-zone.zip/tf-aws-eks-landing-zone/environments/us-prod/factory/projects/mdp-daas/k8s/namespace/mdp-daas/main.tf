provider "aws" {
  region = "us-east-1"
  # allowed_account_ids = [
  #   "541574621075",
  # ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/mdp-daas/k8s/namespace/mdp-daas/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "irsa" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/mdp-daas/k8s/namespace/irsa/mdp-daas/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

##################################################################

resource "kubernetes_namespace" "k8s_ns" {
  metadata {
    annotations = {
      project = var.project
      "scheduler.alpha.kubernetes.io/node-selector" = "project=${var.project}"
    }

    labels = {
      project = var.project
    }

    name = var.project
  }
}


resource "kubernetes_resource_quota" "k8s_rq" {
  metadata {
    name = "${var.project}-rq"
    namespace = var.project
  }

  spec {
    hard = {
      "requests.cpu": "4"
      "requests.memory": "16Gi"
      "limits.cpu": "4"
      "limits.memory": "16Gi"
    }
    scopes = ["NotTerminating"]
  }
}

resource "kubernetes_service_account" "odp" {
  metadata {
    name      = "${var.namespace}-sa"
    namespace = var.namespace
    annotations = {
      "eks.amazonaws.com/role-arn" = local.irsa_sa_role_arn
    }    
  }
}




# resource "kubernetes_resource_quota" "core-object-count" {
#   metadata {
#     name = "core-object-count"
#     namespace = var.namespace
#   }
#   spec {
#     hard = {
#       persistentvolumeclaims = "0"
#       replicationcontrollers = "5"
#       secrets = "10"
#       services = "5"
#       configmaps = "10"
#     }
#   }
# }


/* module "login-role" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-factory-mdp-daas"
  role_description      = "hc-factory-mdp-daas"
  environment           = var.environment
  region                = var.region
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::245792935030:saml-provider/ge-saml-for-aws-mfa"
      },
      "Action": "sts:AssumeRoleWithSAML",
      "Condition": {
        "StringEquals": {
          "SAML:aud": "https://signin.aws.amazon.com/saml"
        }
      }
    }
  ]
}
EOF
  tags = var.tags
} */

/* module "service-role" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "odp-us-prod-factory-mdp-daas-service-role"
  role_description      = "odp-us-prod-factory-mdp-daas-service-role"
  environment           = var.environment
  region                = var.region
  role_assume_policy    = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::245792935030:user/504003435",
                "Service": [
                    "codepipeline.amazonaws.com",
                    "codecommit.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "ec2.amazonaws.com",
                    "logs.amazonaws.com",
                    "ecs.amazonaws.com",
                    "events.amazonaws.com",
                    "codebuild.amazonaws.com"
                ]
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags = var.tags
} */
