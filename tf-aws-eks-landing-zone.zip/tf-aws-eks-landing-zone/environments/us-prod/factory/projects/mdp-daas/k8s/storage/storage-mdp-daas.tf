

resource "kubernetes_persistent_volume" "efs-mdp-daas-pv" {
  metadata {
    name = "${local.mdp_daas_namespace}-efs-pv"
  }

  spec {
    capacity = {
      storage = "5Gi"
    }
    access_modes = ["ReadWriteMany"]
    persistent_volume_reclaim_policy = "Retain"
    storage_class_name = "mdp-daas-efs-sc"
    persistent_volume_source {
      csi {
        volume_handle = "${data.terraform_remote_state.efs.outputs.efs_id}::${element(values(data.terraform_remote_state.efs.outputs.access_point_ids), 0)}"
        driver         = "efs.csi.aws.com"
        volume_attributes = {
          "encryptInTransit" = "true"
        }
      }
    }
  }
}

resource "kubernetes_persistent_volume_claim" "efs-mdp-daas-pvc" {
  metadata {
    name = "${local.mdp_daas_namespace}-efs-pvc" // mdp-mr-efs-pvc
    namespace = local.mdp_daas_namespace
    labels = var.labels
  }
  spec {
    access_modes = ["ReadWriteMany"]
    resources {
      requests = {
        storage = "5Gi"
      }
    }
    volume_name        = kubernetes_persistent_volume.efs-mdp-daas-pv.metadata[0].name
    storage_class_name = "mdp-daas-efs-sc"
  }
}
