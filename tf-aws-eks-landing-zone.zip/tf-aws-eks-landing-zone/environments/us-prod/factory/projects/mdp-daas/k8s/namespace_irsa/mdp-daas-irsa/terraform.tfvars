region = "us-east-1"

# Use lower case letters
project = "mdp-daas"

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-mdp-daas"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"  
    Role = "dt-dst-mdp-shared"
}



