# Namespace and team 

namespace = "mdp-daas"
project = "mdp-daas"

# User SSO
k8s_user = "mdp-daas" ## Ex:- FSSO 50312512

/* tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-mdp-daas"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"  
    Role = "dt-dst-mdp-shared"
}

region = "us-east-1"
environment = "prod" */