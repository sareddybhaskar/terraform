# Namespace and team 

namespace = "helloworld-spring"
project = "helloworld-spring"

# User SSO
k8s_user = "helloworld" ## Ex:- FSSO 50312512
