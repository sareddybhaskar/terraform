locals {

    prod_spring_namespace = "helloworld-spring"
    prod_nodejs_namespace = "helloworld-nodejs"
}