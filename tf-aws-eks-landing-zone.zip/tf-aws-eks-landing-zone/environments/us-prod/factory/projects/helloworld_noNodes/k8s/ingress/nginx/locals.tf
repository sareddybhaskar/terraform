locals {
  namespace               = "ingress-nginx"
  project                 = "stg-helloworld"
}