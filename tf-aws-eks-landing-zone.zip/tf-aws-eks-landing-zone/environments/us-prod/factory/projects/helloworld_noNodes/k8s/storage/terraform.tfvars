# Namespace and team 

labels = {
    project = "helloworld"
    team    = "Admin"
    program  = "odp"
}
