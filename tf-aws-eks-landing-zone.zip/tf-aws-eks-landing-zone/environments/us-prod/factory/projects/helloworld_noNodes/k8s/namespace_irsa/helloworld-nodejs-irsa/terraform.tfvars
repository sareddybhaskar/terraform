region = "us-east-1"

# Use lower case letters
project = "helloworld-nodejs"

tags = {
    ManagedBy = "Terraform"
    Project = "Admin"
    App = "ODP-Factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "prod"    
}
