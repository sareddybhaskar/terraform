# Namespace and team 

namespace = "helloworld-nodejs"
project = "helloworld-nodejs"

# User SSO
k8s_user = "helloworld" ## Ex:- FSSO 50312512
