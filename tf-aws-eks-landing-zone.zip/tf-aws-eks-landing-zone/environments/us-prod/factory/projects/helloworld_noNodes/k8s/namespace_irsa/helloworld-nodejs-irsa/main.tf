provider "aws" {
  region = var.region
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/helloworld/k8s/namespace/irsa/helloworld-nodejs/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_caller_identity" "current" {}

################################################################################################

locals {
  cluster_name  = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

module "iam_assumable_role_admin" {
  source                        = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-eks.git//modules/eks/iam-role?ref=tags/v1.0"
  create_role                   = true
  role_name                     = "${local.cluster_name}-eks-${var.project}-irsa"
  provider_url                  = replace(data.terraform_remote_state.eks.outputs.eks_cluster_identity_oidc_issuer, "https://", "")
  role_policy_arns              = [aws_iam_policy.odp.arn]
  oidc_fully_qualified_subjects = ["system:serviceaccount:${var.project}:${var.project}-sa"]
  tags                          = var.tags
}

 resource "aws_iam_policy" "odp" {
   name_prefix = "${local.cluster_name}-eks-${var.project}-irsa-"
   description = "EKS cluster-autoscaler policy for cluster ${local.cluster_name}"
   tags        = var.tags
   policy = <<POLICY
{
  "Version": "2012-10-17",  
	"Statement": [
    {
      "Sid": "nodejs",
      "Action": [
        "s3:List*",
        "s3:Get*"
      ],
      "Effect": "Allow",
      "Resource": [
        "arn:aws:s3:::odp-us-prod-cicd",
        "arn:aws:s3:::odp-us-prod-cicd/*"
      ]
    }
  ]  
}
POLICY
}

# resource "aws_iam_policy" "odp" {
#   name_prefix = "${local.cluster_name}-eks-${var.project}-irsa-"
#   description = "EKS policy cluster ${local.cluster_name}"
#   policy      = data.aws_iam_policy_document.odp.json
#   tags        = var.tags
# }


#  data "aws_iam_policy_document" "odp" {
#   statement {
#     sid = "nodejs"
#     effect = "Allow"

#     actions = [
# 			"s3:List*",
# 			"s3:Get*"
#     ]

#     resources = [
# 			"arn:aws:s3:::odp-us-prod-cicd",
# 			"arn:aws:s3:::odp-us-prod-cicd/*"
#     ]
#   }
# }

# resource "aws_iam_policy" "odp_policy" {
#   name_prefix = "us-dev-${local.cluster_name}-odp-cs-policy-"
#   description = "EKS cluster-autoscaler policy for cluster ${local.cluster_name}"
#   policy      = data.aws_iam_policy_document.odp_cs.json
# }


# data "aws_iam_policy_document" "odp_cs" {
#   statement {
#     sid    = "clusterAutoscalerAll"
#     effect = "Allow"

#     actions = [
#       "autoscaling:DescribeAutoScalingGroups",
#       "autoscaling:DescribeAutoScalingInstances",
#       "autoscaling:DescribeLaunchConfigurations",
#       "autoscaling:DescribeTags",
#       "ec2:DescribeLaunchTemplateVersions",
#     ]

#     resources = ["*"]
#   }

#   statement {
#     sid    = "clusterAutoscalerOwn"
#     effect = "Allow"

#     actions = [
#       "autoscaling:SetDesiredCapacity",
#       "autoscaling:TerminateInstanceInAutoScalingGroup",
#       "autoscaling:UpdateAutoScalingGroup",
#     ]

#     resources = ["*"]

#     condition {
#       test     = "StringEquals"
#       variable = "autoscaling:ResourceTag/kubernetes.io/cluster/${module.eks.cluster_id}"
#       values   = ["owned"]
#     }

#     condition {
#       test     = "StringEquals"
#       variable = "autoscaling:ResourceTag/k8s.io/cluster-autoscaler/enabled"
#       values   = ["true"]
#     }
#   }
# }






################################################################################################