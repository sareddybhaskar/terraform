locals {
  # namespace               = "ingress-nginx"
  project                 = "helloworld-tls"
}