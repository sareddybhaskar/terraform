region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0d3a77c56f0b4a809", "subnet-08218951d2463ab92"]
vpc_id = "vpc-09bade12fd82d9f5d"

kubernetes_version = "1.25"
instance_types = ["t3a.large" ]
desired_size = 2
max_size = 3
min_size = 2
disk_size = 100
ec2_ssh_key = "odp-us-prod-tools_kp"

project = "helloworld"

project_slug = "hwd"
kubernetes_labels = {
    project = "helloworld"
    team    = "Admin"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  amazon-linux-extras install epel -y
  yum update -y
  yum install ansible git nano -y
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  cd /tmp/
  git clone https://502818692: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@github.gehealthcare.com/gehc-odp/2faldap-ranger-nifi-splunk-crowdstrike-qualys.git
  ansible-playbook 2faldap-ranger-nifi-splunk-crowdstrike-qualys/playbook-eks-prod.yml
  rm -rf 2faldap-ranger-nifi-splunk-crowdstrike-qualys 
  EOT


tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-sample"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-shared-cde"
    namespace = "helloworld"
    Owner = "srinivas.karegowdra@ge.com"
    Contact = "health_odp_cicd_dev_team@ge.com"
}
