# Namespace and team 

namespace = "ibstudio"
project = "ibstudio"

# User SSO
k8s_user = "ibstudio" ## Ex:- FSSO 50312512
