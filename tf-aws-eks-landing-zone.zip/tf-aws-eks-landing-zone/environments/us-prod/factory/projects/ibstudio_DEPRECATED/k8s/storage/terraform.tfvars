# Namespace and team 

labels = {
    project = "ibstudio"
    team    = "ibstudio"
    program  = "odp"
}
