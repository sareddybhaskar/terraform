locals {
  # namespace               = "ingress-nginx"
  project                 = "ibstudio-tls"
}