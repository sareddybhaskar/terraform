region = "us-east-1"

# Use lower case letters
project = "ibstudio"

tags = {
    ManagedBy = "Terraform"
    Project = "ibstudio"
    App = "ODP-Factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "prod"    
}
