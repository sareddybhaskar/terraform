locals {

    prod_ibstudio_namespace = "ibstudio"
}