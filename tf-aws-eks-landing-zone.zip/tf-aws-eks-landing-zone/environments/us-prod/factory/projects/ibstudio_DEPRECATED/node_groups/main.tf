provider "aws" {
  region = var.region
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/ibstudio/node-groups/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

locals {
  tags = merge(var.tags, map("kubernetes.io/cluster/${data.terraform_remote_state.eks.outputs.eks_cluster_id}", "shared"))

  eks_worker_ami_name_filter = "amazon-eks-node-${var.kubernetes_version}*"
}

data "aws_vpc" "selected" {
  id = var.vpc_id
}


module "eks_node_group" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-eks.git//modules/eks/node-group?ref=tags/v1.0"

  subnet_ids         = var.subnet_ids
  cluster_name       = data.terraform_remote_state.eks.outputs.eks_cluster_id
  instance_types     = var.instance_types
  desired_size       = var.desired_size
  min_size           = var.min_size
  max_size           = var.max_size
  kubernetes_version = var.kubernetes_version
  kubernetes_labels  = var.kubernetes_labels
  disk_size          = var.disk_size
  tags               = var.tags
  create_before_destroy = var.create_before_destroy

  cidr_blocks        = [data.aws_vpc.selected.cidr_block]
  project            = var.project
  project_slug       = var.project_slug

  ec2_ssh_key        = var.ec2_ssh_key
  source_security_group_ids = [data.terraform_remote_state.eks.outputs.eks_cluster_security_group_id]
  
  # resources_to_tag = ""
  after_cluster_joining_userdata = var.after_cluster_joining_userdata

}
