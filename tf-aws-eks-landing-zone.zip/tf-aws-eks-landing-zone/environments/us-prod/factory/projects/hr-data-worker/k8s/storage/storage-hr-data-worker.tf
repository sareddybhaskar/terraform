

resource "kubernetes_persistent_volume" "k8s_pv" {
  metadata {
    name = "${local.namespace_name}-efs-pv"
  }

  spec {
    capacity = {
      storage = "5Gi"
    }
    access_modes = ["ReadWriteMany"]
    persistent_volume_reclaim_policy = "Retain"
    storage_class_name = "hr-data-worker-efs-sc"
    persistent_volume_source {
      csi {
        # volume_handle = "${data.terraform_remote_state.efs.outputs.efs_id}:/dev-ibstudio/212744470"
        volume_handle = "${data.terraform_remote_state.efs.outputs.efs_id}::${element(values(data.terraform_remote_state.efs.outputs.access_point_ids), 0)}"
        driver         = "efs.csi.aws.com"
        volume_attributes = {
          "encryptInTransit" = "true"
        }
      }
    }
  }
}

resource "kubernetes_persistent_volume_claim" "k8s_pvc" {
  metadata {
    name = "${local.namespace_name}-efs-pvc" // mdp-mr-efs-pvc
    namespace = local.namespace_name
    labels = var.labels
  }
  spec {
    access_modes = ["ReadWriteMany"]
    resources {
      requests = {
        storage = "5Gi"
      }
    }
    volume_name        = kubernetes_persistent_volume.k8s_pv.metadata[0].name
    storage_class_name = "hr-data-worker-efs-sc"
  }
}
