locals {

    namespace_name = "hr-data-worker"
}
