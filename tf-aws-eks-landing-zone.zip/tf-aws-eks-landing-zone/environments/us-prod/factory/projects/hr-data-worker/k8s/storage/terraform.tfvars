# Namespace and team 

labels = {
    project = "hr-data-worker"
    team    = "hr-data-worker"
    program  = "odp"
}
