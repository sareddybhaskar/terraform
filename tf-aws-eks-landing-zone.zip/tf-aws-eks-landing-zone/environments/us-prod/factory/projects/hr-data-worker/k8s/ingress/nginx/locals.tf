locals {
  namespace               = "ingress-nginx"
  project                 = "hr-data-worker"
}