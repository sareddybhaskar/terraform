# Deploy sequence

1. node-groups
2. efs
3. k8s/namespace_irsa/**
4. ingress (apply manifests/ns -> manifests/svc yamls)
5. create namespace using kubectl
5. k8s/namespace/**
6. k8s/storage-class/**
7. Add aws-auth cm to authenticate users to namespace
