provider "aws" {
  region = "us-east-1"
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/hr-data-learning/k8s/namespace/hr-data-learning/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "irsa" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/hr-data-learning/k8s/namespace/irsa/hr-data-learning/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

##################################################################

resource "kubernetes_namespace" "k8s_ns" {
  metadata {
    annotations = {
      project = var.project
      "scheduler.alpha.kubernetes.io/node-selector" = "project=${var.project}"
    }

    labels = {
      project = var.project
    }

    name = var.project
  }
}


resource "kubernetes_resource_quota" "k8s_rq" {
  metadata {
    name = "${var.project}-rq"
    namespace = var.project
  }

  spec {
    hard = {
      "requests.cpu": "12"
      "requests.memory": "24Gi"
      "limits.cpu": "12"
      "limits.memory": "24Gi"
    }
    scopes = ["NotTerminating"]
  }
}

resource "kubernetes_service_account" "odp" {
  metadata {
    name      = "${var.namespace}-sa"
    namespace = var.namespace
    annotations = {
      "eks.amazonaws.com/role-arn" = local.irsa_sa_role_arn
    }    
  }
}


# resource "kubernetes_resource_quota" "core-object-count" {
#   metadata {
#     name = "core-object-count"
#     namespace = var.namespace
#   }
#   spec {
#     hard = {
#       persistentvolumeclaims = "0"
#       replicationcontrollers = "5"
#       secrets = "10"
#       services = "5"
#       configmaps = "10"
#     }
#   }
# }

