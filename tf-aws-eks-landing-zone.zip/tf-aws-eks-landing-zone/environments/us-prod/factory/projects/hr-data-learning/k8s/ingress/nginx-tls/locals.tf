locals {
  # namespace               = "ingress-nginx"
  project                 = "hr-data-learning-tls"
}
