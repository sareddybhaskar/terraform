# Namespace and team 

labels = {
    project = "hr-data-learning"
    team    = "hr-data-learning"
    program  = "odp"
}
