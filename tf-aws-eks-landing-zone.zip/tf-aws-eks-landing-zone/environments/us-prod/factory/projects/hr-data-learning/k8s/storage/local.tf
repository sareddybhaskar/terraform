locals {

    namespace_name = "hr-data-learning"
}
