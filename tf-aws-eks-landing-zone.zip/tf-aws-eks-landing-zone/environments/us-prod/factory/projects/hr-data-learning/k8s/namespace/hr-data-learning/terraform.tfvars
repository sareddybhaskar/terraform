# Namespace and team 

namespace = "hr-data-learning"
project = "hr-data-learning"

# User SSO
k8s_user = "504010061" ## Ex:- FSSO 50312512 502822749

region = "us-east-1"
environment = "prod"

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-hr"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-hr-hrdata-factory"
    Owner = "grzegorz.hadro@ge.com"
    Contact = "it.D_A.HR@ge.com"
}
