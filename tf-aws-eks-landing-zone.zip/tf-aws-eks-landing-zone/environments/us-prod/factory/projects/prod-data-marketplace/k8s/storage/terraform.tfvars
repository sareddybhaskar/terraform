# Namespace and team 

labels = {
    project = "prod-data-marketplace"
    team    = "prod-data-marketplace"
    program  = "odp"
}
