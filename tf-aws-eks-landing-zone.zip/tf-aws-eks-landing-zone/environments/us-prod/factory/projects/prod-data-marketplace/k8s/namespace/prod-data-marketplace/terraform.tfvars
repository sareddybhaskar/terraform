# Namespace and team 

namespace = "prod-data-marketplace"
project = "prod-data-marketplace"

# User SSO
k8s_user = "NP700007856" ## Ex:- FSSO 50312512

region = "us-east-1"
environment = "prod"

tags = {
    ManagedBy = "Terraform"
    Project = "data-marketplace"
    App = "data-marketplace"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-datamarketplace"
    Owner = "gurudas.pradhan@gehealthcare.com"
    Contact = "gurudas.pradhan@gehealthcare.com"
}
