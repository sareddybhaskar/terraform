locals {
  namespace               = "ingress-nginx"
  project                 = "prod-data-marketplace"
}