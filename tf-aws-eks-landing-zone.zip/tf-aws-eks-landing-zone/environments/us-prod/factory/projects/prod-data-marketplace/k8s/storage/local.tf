locals {

    namespace_name = "prod-data-marketplace"
}
