region = "us-east-1"

# Use lower case letters
project = "prod-data-marketplace"

tags = {
    ManagedBy = "Terraform"
    Project = "data-marketplace"
    App = "data-marketplace"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-datamarketplace"
    Owner = "gurudas.pradhan@gehealthcare.com"
    Contact = "gurudas.pradhan@gehealthcare.com"
}



