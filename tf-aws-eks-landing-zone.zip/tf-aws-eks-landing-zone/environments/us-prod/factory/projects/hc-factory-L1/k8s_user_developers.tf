resource "kubernetes_role" "user_role" {
  count      = 1

  metadata {
    name        = "${var.team}-role"
    namespace   = var.team
    # labels      = var.labels
    # annotations = var.annotations
  }

  rule {
    api_groups = [
      "",
      "batch",
      "extensions",
      "apps",
      "autoscaling"
    ]

    resources = [
      "configmaps",
      "cronjobs",
      "deployments",
      "events",
      "ingresses",
      "jobs",
      "pods",
      "pods/attach",
      "pods/exec",
      "pods/log",
      "pods/portforward",
      "pods/eviction",
      "secrets",
      "services",
      "endpoints",
      "replicasets",
      "daemonsets",
      "statefulsets",
      "replicationcontrollers",
      "horizontalpodautoscalers"
    ]
    verbs = [
      "describe",
      "get",
      "list",
      "watch",      
    ]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = [""]
    resources  = ["persistentvolumeclaims"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["storage.k8s.io"]
    resources  = ["csidrivers"]
  }

  rule {
    verbs      = ["get", "list", "watch","describe"]
    api_groups = ["networking.k8s.io"]
    resources  = ["ingresses"]
  }
}


resource "kubernetes_role_binding" "user_rb" {

  metadata {
    name      = "${var.team}-role-binding"
    namespace = var.team
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = "${var.team}-role"
  }

  subject {
    kind      = "Group"
    name      = var.team
  }
}