provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "245792935030",
  ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/hc-factory-l1/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

# data "terraform_remote_state" "irsa" {
#   backend = "s3"
#   config = {
#     bucket = "odp-us-innovation-terraform"
#     key    = "terraform-state/innovation-us/eks/factory/projects/daas-test/k8s/namespace/irsa/daas-test/terraform.tfstate"
#     region = "us-east-1"
#   }
# }

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}


resource "kubernetes_namespace" "k8s_ns" {
  metadata {
    annotations = {
      project = var.team
      "scheduler.alpha.kubernetes.io/node-selector" = "project=${var.team}"
    }

    labels = {
      project = var.team
    }

    name = var.team
  }
}

resource "kubernetes_resource_quota" "k8s_rq" {
  metadata {
    name = "${var.team}-rq"
    namespace = var.team
  }

  spec {
    hard = {
      "requests.cpu": "0"
      "requests.memory": "0Gi"
      "limits.cpu": "0"
      "limits.memory": "0Gi"
    }
    scopes = ["NotTerminating"]
  }
}

module "login-role" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-factory-l1"
  role_description      = "hc-factory-l1"
  environment           = var.environment
  region                = var.region
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::245792935030:saml-provider/ge-saml-for-aws-mfa"
      },
      "Action": "sts:AssumeRoleWithSAML",
      "Condition": {
        "StringEquals": {
          "SAML:aud": "https://signin.aws.amazon.com/saml"
        }
      }
    }
  ]
}
EOF
  tags = var.tags
}