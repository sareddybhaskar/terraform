# Namespace and team 

team = "hc-factory-l1"
# project = "odpfactory-L1"

# User SSO
# k8s_user = "daas-test" ## Ex:- FSSO 50312512

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-admin"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"  
    Role = "dt-dna-aa-factory"
}