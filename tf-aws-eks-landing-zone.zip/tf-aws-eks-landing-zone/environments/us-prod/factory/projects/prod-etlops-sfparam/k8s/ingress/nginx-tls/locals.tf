locals {
  # namespace               = "ingress-nginx"
  project                 = "prod-etlops-sfparam-tls"
}
