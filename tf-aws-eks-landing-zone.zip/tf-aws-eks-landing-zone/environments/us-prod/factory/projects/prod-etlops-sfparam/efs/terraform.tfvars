region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0d3a77c56f0b4a809", "subnet-08218951d2463ab92"]
vpc_id = "vpc-09bade12fd82d9f5d"
allowed_cidr_blocks = ["100.64.0.0/16"]

efs_name = "odp-us-prod-eks-factory-prod-etlops-sfparam"

tags = {
    ManagedBy = "Terraform"
    Project = "etlops-sfparam"
    App = "sfparam"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-dm-etlops"
    Owner = "harika.kbulusu@ge.com:sunita.panigrahi@ge.com"
    Contact = "dtDnADaaS2team@ge.com"
}
