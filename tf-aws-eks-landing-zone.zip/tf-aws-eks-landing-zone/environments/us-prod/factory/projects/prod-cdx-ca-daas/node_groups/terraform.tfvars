region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0d3a77c56f0b4a809", "subnet-08218951d2463ab92"]
vpc_id = "vpc-09bade12fd82d9f5d"

kubernetes_version = "1.25"
instance_types = ["t3a.small" ]
desired_size = 2
max_size = 2
min_size = 2
disk_size = 100
ec2_ssh_key = "odp-us-prod-tools_kp"

project = "prod-cdx-ca-daas"

project_slug = "p-c-d"
kubernetes_labels = {
    project = "prod-cdx-ca-daas"
    team    = "prod-cdx-ca-daas"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  amazon-linux-extras install epel -y
  yum update -y
  yum install ansible git nano -y
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  cd /tmp/
  git clone https://502818692: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@github.gehealthcare.com/gehc-odp/2faldap-ranger-nifi-splunk-crowdstrike-qualys.git
  ansible-playbook 2faldap-ranger-nifi-splunk-crowdstrike-qualys/playbook-eks-usin.yml
  rm -rf 2faldap-ranger-nifi-splunk-crowdstrike-qualys 
  EOT


tags = {
    ManagedBy = "Terraform"
    Project = "cdx-ca-daas"
    App = "cdx-ca"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-cdx-ca-factory"
    Owner = "alok.ojha@ge.com:sujit.singh@ge.com"
    Contact = "cdx.daas.support@ge.com"
}
