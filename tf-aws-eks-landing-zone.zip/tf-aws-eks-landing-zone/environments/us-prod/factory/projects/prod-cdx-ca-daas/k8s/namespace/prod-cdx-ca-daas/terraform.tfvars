# Namespace and team 

namespace = "prod-cdx-ca-daas"
project = "prod-cdx-ca-daas"

# User SSO
k8s_user = "502822749" ## Ex:- FSSO 50312512

region = "us-east-1"
environment = "prod"

tags = {
    ManagedBy = "Terraform"
    Project = "cdx-ca-daas"
    App = "cdx-ca"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-cdx-ca-factory"
    Owner = "alok.ojha@ge.com:sujit.singh@ge.com"
    Contact = "cdx.daas.support@ge.com"
}
