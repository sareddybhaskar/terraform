# Namespace and team 

labels = {
    project = "prod-cdx-ca-daas"
    team    = "prod-cdx-ca-daas"
    program  = "odp"
}
