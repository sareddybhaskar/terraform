
provider "aws" {
  region = "us-east-1"
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/prod-cdx-ca-daas/k8s/storage-class/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "efs" {
  backend = "s3"
  config = {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/eks/factory/projects/prod-cdx-ca-daas/efs/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

###################################################################################################
resource "kubernetes_storage_class" "efs_sc" {
  metadata {
    name = "prod-cdx-ca-daas-efs-sc"
  }
  storage_provisioner    = "efs.csi.aws.com"
  mount_options          = ["tls"]
}

