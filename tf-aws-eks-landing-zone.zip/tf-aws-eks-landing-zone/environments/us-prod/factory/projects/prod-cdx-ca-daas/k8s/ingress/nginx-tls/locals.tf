locals {
  # namespace               = "ingress-nginx"
  project                 = "prod-cdx-ca-daas-tls"
}
