locals {

    namespace_name = "prod-cdx-ca-daas"
}
