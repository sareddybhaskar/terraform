region = "us-east-1"

# Use lower case letters
project = "prod-cdx-ca-daas"

tags = {
    ManagedBy = "Terraform"
    Project = "cdx-ca-daas"
    App = "cdx-ca"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-cdx-ca-factory"
    Owner = "alok.ojha@ge.com:sujit.singh@ge.com"
    Contact = "cdx.daas.support@ge.com"
}



