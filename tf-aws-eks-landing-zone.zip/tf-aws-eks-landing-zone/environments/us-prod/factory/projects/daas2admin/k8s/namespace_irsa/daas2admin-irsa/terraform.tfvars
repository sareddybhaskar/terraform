region = "us-east-1"

# Use lower case letters
project = "daas2admin"

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-daasadmin"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-daas-factory"  
}



