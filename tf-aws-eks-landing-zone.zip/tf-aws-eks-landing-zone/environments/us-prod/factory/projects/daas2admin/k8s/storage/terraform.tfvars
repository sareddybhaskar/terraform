# Namespace and team 

labels = {
    project = "daas2admin"
    team    = "daas2admin"
    program  = "odp"
}
