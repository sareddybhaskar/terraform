# Namespace and team 

namespace = "daas2admin"
project = "daas2admin"

# User SSO
k8s_user = "502817295" ## Ex:- FSSO 50312512

tags = {
    ManagedBy = "Terraform"
    Project = "odpfactory-daasadmin"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-daas-factory"  
}

region = "us-east-1"
environment = "prod" 