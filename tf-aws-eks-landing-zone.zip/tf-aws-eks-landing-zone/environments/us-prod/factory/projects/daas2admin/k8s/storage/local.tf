locals {

    daas2admin_namespace = "daas2admin"
}