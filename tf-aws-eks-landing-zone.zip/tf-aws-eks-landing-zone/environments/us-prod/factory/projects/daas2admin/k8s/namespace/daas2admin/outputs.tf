/* output "role_name" {
  value = [
      module.login-role.role_name,
  ]
}

output "role_id" {
  value = [
      module.login-role.role_unique_id,
  ]
} */