variable "namespace" {
  description = "The name of the namespace where the roles should be created."
  type        = string
}


variable "labels" {
  description = "Map of string key value pairs that can be used to organize and categorize the roles. See the Kubernetes Reference for more info (https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/)."
  type        = map(string)
  default     = {}
}

variable "annotations" {
  description = "Map of string key default pairs that can be used to store arbitrary metadata on the roles. See the Kubernetes Reference for more info (https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/)."
  type        = map(string)
  default     = {}
}

variable "k8s_user" {
    type = string
}

variable "project" {
    type = string
}

/* variable "tags" {
  type        = map
}

variable "region" {
  default = ""
}

variable "environment" {
  default = ""
} */