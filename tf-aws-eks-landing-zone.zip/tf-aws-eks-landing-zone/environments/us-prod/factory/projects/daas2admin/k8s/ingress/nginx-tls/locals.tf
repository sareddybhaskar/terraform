locals {
  # namespace               = "ingress-nginx"
  project                 = "daas2admin-tls"
}