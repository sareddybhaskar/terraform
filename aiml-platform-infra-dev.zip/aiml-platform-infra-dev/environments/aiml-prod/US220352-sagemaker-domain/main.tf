provider "aws" {
  version = "6.2.0"
  region = "us-east-1"
  allowed_account_ids = [
    "046704565421",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-prod-terraform"
    key    = "terraform-state/US220352-sagemaker-domain/terraform.tfstate"
    region = "us-east-1"
  }
}


module "domain" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sagemaker/sagemaker_domain?ref=dev"

  enable_sagemaker_domain = true

  sagemaker_domain_name = var.domain_name
  sagemaker_domain_auth_mode   = var.domain_auth_mode
  sagemaker_domain_vpc_id      = var.domain_vpc_id
  sagemaker_domain_subnet_ids  = var.domain_subnet_ids

  sagemaker_domain_default_user_settings = {
    execution_role = var.execution_role
    security_groups = var.security_groups
  }
  sagemaker_domain_kms_key_id = var.kms_key_id
  sagemaker_domain_app_network_access_type = var.app_network_access_type
  enable_sagemaker_user_profile = true
  sagemaker_user_profile_name = var.admin_user_profile_name
  sagemaker_user_profile_user_settings = {
    execution_role = var.admin_execution_role
  }

  tags            = var.tags
  

}
