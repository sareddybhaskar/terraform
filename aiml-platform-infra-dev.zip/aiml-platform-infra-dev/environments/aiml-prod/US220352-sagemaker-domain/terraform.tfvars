  name = "odp-us-aiml-prod"
  region = "us-east-1"
  environment = "aiml-prod"

  tags = {
    Project       = "aiml-ofp"
    App           = "aiml-ofp"
    Program       = "ODP"
    Environment = "prod"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3032643"
    ApplicationTag = "aiml-mlops"
    Role          = "dt-aiml-ofp-ds"
    UserStory = "US220352"
    purpose = "inv_2025"
    project_number = "ID5990:PR17717"
    Owner = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact = "cdao_mlops_support@gehealthcare.com"
  }

execution_role = "arn:aws:iam::046704565421:role/odp-us-aiml-prod-mlops-service-role"
domain_name = "us-aiml-prod-mlops"
kms_key_id = "arn:aws:kms:us-east-1:046704565421:key/6c88399a-855d-431f-8855-2e4e507c77eb"

domain_auth_mode = "IAM"
domain_vpc_id = "vpc-018c491cd8dfe60eb"
domain_subnet_ids = ["subnet-0d8f022a20e25dab5"]
security_groups = ["sg-0e090f84c7a49ae5a"]
app_network_access_type = "VpcOnly"



#### User Profiles ####
admin_user_profile_name = "hc-aiml-mlops-user"
admin_execution_role = "arn:aws:iam::046704565421:role/odp-us-aiml-prod-mlops-service-role"