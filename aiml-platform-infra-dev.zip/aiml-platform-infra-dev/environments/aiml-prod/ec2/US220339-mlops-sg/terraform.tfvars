region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-018c491cd8dfe60eb"


tags = {
  Project     = "aiml-mlops"
  App         = "aiml-mlops"
  Environment = "prod"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "SNSVC0011597"
  Program     = "aiml"
  UserStory  = "US220339"
  Role        = "dt-aiml-mlops"
  purpose     = "inv_2025"
  project_number = "ID5990:PR17717"
  Owner     = "Philippe.Peloquin@gehealthcare.com"
  Contact   = "cdao_mlops_support@gehealthcare.com"
}

tags1 = {
  Project     = "aiml-pqm-quality"
  App         = "aiml-pqm-quality"
  Environment = "prod"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "UAI3053026"
  Program     = "aiml"
  UserStory  = "US221767"
  Role        = "it-iscst-eng-quality"
  purpose     = "inv_2025"
  project_number = "ID6115:PR17371"
  Owner     = "Philippe.Peloquin@gehealthcare.com"
  Contact   = "Philippe.Peloquin@gehealthcare.com"
  UAI       = "APM0010159"
}

# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-018c491cd8dfe60eb"


#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-018c491cd8dfe60eb"
private_subnets = ["subnet-0d8f022a20e25dab5"]
allowed_cidr_blocks = ["10.55.244.0/24"]