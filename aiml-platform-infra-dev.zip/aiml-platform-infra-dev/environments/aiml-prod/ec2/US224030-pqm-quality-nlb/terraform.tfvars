# name = "odp-us-prod"
region = "us-east-1"
environment = "aiml-prod"


  tags = {
    Project       = "aiml-pqm-quality"
    App           = "aiml-pqm-quality"
    Platform	    = "Linux"
    Environment = "aiml-prod"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "APM0010159"
    Patch	    = "Disable"
    Role      = "it-iscst-eng-quality"
    Owner     = "kelly.boyer@gehealthcare.com"
    Contact   = "kelly.boyer@gehealthcare.com"
    UserStory = "US224030"
    project_number    = "ID6115:PR17371"
    purpose = "inv_2026"
  }

  #vpc_id = "vpc-018c491cd8dfe60eb"
  #instance1 = "i-0f456f43ec4098f55"
  #acm_cert_arn = "arn:aws:acm:us-east-1:046704565421:certificate/211683fc-bbab-4d56-807f-6a5dca27923c"
  