provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "046704565421",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-prod-terraform"
    key    = "terraform-state/ec2/US224030-pqm-quality-nlb/terraform.tfstate"
    region = "us-east-1"
  }
}

module "nlb" {
    source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/nlb?ref=dev"
    enable_nlb = true
    nlb_name = "odp-us-aiml-prod-pqm-qlty-nlb"
    nlb_security_groups    = ["sg-05d97a9cb2573c05b"]
    nlb_subnets                    = ["subnet-0d8f022a20e25dab5", "subnet-040e0f38dbcf6aeb2"]
    nlb_enable_deletion_protection = true
    nlb_internal                   = true

  # NLB target group
    enable_nlb_target_group   = true
    nlb_target_group_target_type = "alb"
    nlb_target_group_name     = "odp-us-aiml-prod-pqm--qlty-nlb-alb-tg"
    nlb_target_group_name_prefix = "aiml-prod"
    nlb_target_group_vpc_id   = "vpc-018c491cd8dfe60eb"
    nlb_target_group_protocol = "TCP"
    nlb_target_group_port     = 443
    
    # NLB target group attachment
    enable_nlb_target_group_attachment     = true
    nlb_target_group_attachment_target_ids = ["arn:aws:elasticloadbalancing:us-east-1:046704565421:loadbalancer/app/odp-us-aiml-prod-pqm-qlty-alb/6176181e252610d6"]

    # NLB listener
    enable_nlb_listener   = true
    nlb_listener_port = 443
    nlb_listener_protocol = "TCP"
    #nlb_listener_certificate_arn = var.acm_cert_arn

    tags = var.tags
}
