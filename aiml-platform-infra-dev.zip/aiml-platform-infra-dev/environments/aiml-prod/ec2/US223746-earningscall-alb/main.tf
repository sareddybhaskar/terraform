provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "046704565421",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-prod-terraform"
    key    = "terraform-state/ec2/US223746-earningscall-alb/terraform.tfstate"
    region = "us-east-1"
  }
}

resource "aws_lb" "earningscall" {
  name               = "odp-us-aiml-prod-erngscall-alb"
  internal           = true
  load_balancer_type = "application"
    security_groups    = ["sg-0aa3e08f0b2c561bd"]
    subnets            = ["subnet-0d8f022a20e25dab5", "subnet-040e0f38dbcf6aeb2"]

  enable_deletion_protection = true

  tags = var.tags
}

resource "aws_lb_target_group" "alb_tg" {
    name     = "odp-us-aiml-prod-erngscall-tg"
    port     = 80
    protocol = "HTTP"
    vpc_id   = var.vpc_id
    tags = var.tags
}

resource "aws_lb_target_group_attachment" "earningscall1" {
  target_group_arn = aws_lb_target_group.alb_tg.arn
  target_id        = var.instance1
  port             = 80

}

# resource "aws_lb_listener" "earningscall" {
#   load_balancer_arn = aws_lb.earningscall.arn
#   port              = "443"
#   protocol          = "HTTPS"
#   ssl_policy        = "ELBSecurityPolicy-2016-08"
#   certificate_arn   = "arn:aws:acm:us-east-1:245792935030:certificate/b8fb42a1-c279-4e19-b9ab-8a06918a43cf"

#   default_action {
#     type             = "forward"
#     target_group_arn = aws_lb_target_group.alb_tg.arn
#   }
# }
