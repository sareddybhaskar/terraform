
provider "aws" {

  region  = "us-east-1"
  version = " ~> 4.2.0"
}

terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-prod-terraform"
    key    = "terraform-state/ec2/US220339-mlops-ec2-elb/terraform.tfstate"
    region = "us-east-1"
  }
  }




# data "template_file" "ec2node-userdata" {
#   template = file("${path.module}/ec2node_userdata.tpl")
# }

locals {
  ec2node_userdata = templatefile("${path.module}/ec2node_userdata.tpl", {})
}

module "mlops-instance" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-prod-mlops-instance"
  subnet_id              = "subnet-0d8f022a20e25dab5" # us-east-1a
  vpc_security_group_ids = ["sg-0ce105bd5576c8977"]
  availability_zone      = var.availability_zone
  ami                    = "ami-09c11c41b099ddab5" #GEHCSOS-AMAZON2023_X862025-02-14T10-43-18.023Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(local.ec2node_userdata)
  root_block_device = [{
    volume_size = "50"
    volume_type = "gp3"
  }]
}


######
# ELB
######
module "elb-1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/elb_new_old/modules/elb?ref=dev"

  name = "odp-us-aiml-prod-mlops-elb1"

  subnets         = ["subnet-0d8f022a20e25dab5"]
  security_groups = ["sg-0ce105bd5576c8977"]
  internal        = true

  listener = [
    {
      instance_port     = "9802"
      instance_protocol = "TCP"
      lb_port           = "9802"
      lb_protocol       = "TCP"
    },
    {
      instance_port     = "443"
      instance_protocol = "tcp"
      lb_port           = "80"
      lb_protocol       = "tcp"
    },
  ]

  health_check = {
      target              = "TCP:9802"
      interval            = 10
      healthy_threshold   = 2
      unhealthy_threshold = 10
      timeout             = 5
    }

  tags = var.tags

}
