region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-018c491cd8dfe60eb"


tags = {
  Project     = "odp"
  App         = "cloud-ops"
  Environment = "stg"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "UAI3053026"
  Patch       = "Enable"
  Program     = "ODP"
  Role        = "dt-dna"
  DLM         = "Enable"
  purpose     = "inv_2025"
}



instance_type = "t3a.xlarge"
keypair_name  = "odp-us-aiml-prod-tools-kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-018c491cd8dfe60eb"

#### EFS ####
encrypted = "true"

#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-0c41a011b63bfe291"
private_subnets     = ["subnet-0d8f022a20e25dab5"]
allowed_cidr_blocks = ["10.55.244.0/23"]