
provider "aws" {

  region  = "us-east-1"
  version = " ~> 4.2.0"
}

terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-prod-terraform"
    key    = "terraform-state/ec2/odp-us-aiml-cloud-jenkins/terraform.tfstate"
    region = "us-east-1"
  }
}




data "template_file" "ec2node-userdata" {
  template = file("${path.module}/ec2node_userdata.tpl")
}

module "security_group_instance" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sg?ref=dev"

  name        = "odp-us-aiml-prod-cloud-jenkins-sg"
  description = "odp-us-aiml-prod-cloud-jenkins-sg"
  vpc_id      = var.existing_vpc_id

  ingress_cidr_blocks = ["3.0.0.0/8", "10.0.0.0/8"]
  ingress_rules       = ["https-443-tcp", "http-80-tcp", "http-8080-tcp", "ssh-tcp"]
  egress_rules        = ["all-all"]
  tags                = var.tags
}


module "jenkins" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-prod-cloud-jenkins-server"
  subnet_id              = var.private_subnets[0] # us-east-1a
  vpc_security_group_ids = [module.security_group_instance.this_security_group_id]
  availability_zone      = var.availability_zone
  ami                    = "ami-09c11c41b099ddab5" #GEHCSOS-AMAZON2023_X862025-02-14T10-43-18.023Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(data.template_file.ec2node-userdata.rendered)
  root_block_device = [{
    volume_size = "100"
    volume_type = "gp3"
  }]
}

######
# ELB
######
module "cloud-jenkins-elb" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/elb_new_old/modules/elb?ref=dev"

  name = "odp-us-aimlprd-clud-jenkins-elb"

  subnets         = var.private_subnets
  security_groups = [module.security_group_instance.this_security_group_id]
  internal        = true

  listener = [
    {
      instance_port     = "22"
      instance_protocol = "TCP"
      lb_port           = "22"
      lb_protocol       = "TCP"
    },
    {
      instance_port     = "8080"
      instance_protocol = "tcp"
      lb_port           = "8080"
      lb_protocol       = "tcp"
    },
  ]

  health_check = {
    target              = "TCP:8080"
    interval            = 10
    healthy_threshold   = 2
    unhealthy_threshold = 10
    timeout             = 5
  }

  tags = var.tags

}


### EFS ###

module "efs" {

  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/efs?ref=dev"
  name   = "odp-us-aiml-prod-cloud-jenkins-efs"

  region = var.region
  vpc_id = var.vpc_id

  subnets             = var.private_subnets
  security_groups     = [module.security_group_instance.this_security_group_id]
  allowed_cidr_blocks = var.allowed_cidr_blocks

  encrypted = true

  tags = var.tags

} 