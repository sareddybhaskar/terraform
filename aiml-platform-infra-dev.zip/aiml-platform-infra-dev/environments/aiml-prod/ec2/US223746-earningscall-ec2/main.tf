
provider "aws" {

  region  = "us-east-1"
  version = " ~> 4.2.0"
}

terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-prod-terraform"
    key    = "terraform-state/ec2/US223746-earningscall-ec2/terraform.tfstate"
    region = "us-east-1"
  }
  }




# data "template_file" "ec2node-userdata" {
#   template = file("${path.module}/ec2node_userdata.tpl")
# }

locals {
  ec2node_userdata = templatefile("${path.module}/ec2node_userdata.tpl", {})
}

module "earningscall-instance" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-prod-earningscall-instance"
  subnet_id              = "subnet-0d8f022a20e25dab5" # us-east-1a
  vpc_security_group_ids = [module.security_group.this_security_group_id]
  availability_zone      = var.availability_zone
  ami                    = "ami-09c11c41b099ddab5" #GEHCSOS-AMAZON2023_X862025-02-14T10-43-18.023Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(local.ec2node_userdata)
  root_block_device = [{
    volume_size = "50"
    volume_type = "gp3"
  }]
}


module "security_group" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sg?ref=dev"

  name        = "odp-us-aiml-prod-earningscall-sg"
  description = "Security group for earningscall sg"
  vpc_id      = var.existing_vpc_id

  ingress_cidr_blocks = ["3.0.0.0/8","10.0.0.0/8"]
  ingress_rules       = ["https-443-tcp","http-80-tcp"]
  egress_rules        = ["all-all"]
  ingress_with_self = [
    {
      rule = "all-all"
      description = "Allow same sg"
    },
  ]
  
  tags = var.tags
}

