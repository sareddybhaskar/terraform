region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-018c491cd8dfe60eb"


tags = {
  Project     = "aiml-fin-earningscall"
  App         = "aiml-fin-earningscall"
  Environment = "prod"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "SNSVC0011597"
  Patch       = "Enable"
  Program     = "aiml"
  UserStory  = "US220339"
  Role        = "dt-aiml-fin-earningscal"
  DLM         = "Enable"
  purpose     = "inv_2026"
  project_number = "ID7061:PR17653"
  Owner     = "Philippe.Peloquin@gehealthcare.com"
  Contact   = " cdao_mlops_support@gehealthcare.com"
}



instance_type = "t3.large"
keypair_name  = "odp-us-aiml-prod_kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.244.0/24"]
use_existing_vpc = true
existing_vpc_id  = "vpc-018c491cd8dfe60eb"


#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-018c491cd8dfe60eb"
private_subnets = ["subnet-0d8f022a20e25dab5"]
allowed_cidr_blocks = ["10.55.244.0/24"]