output "jenkins" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.earningscall-instance.private_ip
  ]
}

output "odp-us-aiml-prod-earnings-sg" {
  description = "Security Group"
  value       = [
      module.security_group.this_security_group_id
        ]
 }

