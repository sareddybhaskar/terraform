region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-018c491cd8dfe60eb"


tags = {
  Project     = "aiml-pqm-quality"
  App         = "aiml-pqm-quality"
  Environment = "prod"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "APM0010159"
  Patch       = "Enable"
  Program     = "aiml"
  UserStory  = "US221767"
  Role        = "it-iscst-eng-quality"
  DLM         = "Enable"
  purpose     = "inv_2025"
  project_number = "ID6115:PR17371"
  Owner     = "Philippe.Peloquin@gehealthcare.com"
  Contact   = "cdao_mlops_support@gehealthcare.com"
}



instance_type = "t3.xlarge"
keypair_name  = "odp-us-aiml-prod_kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.244.0/24"]
use_existing_vpc = true
existing_vpc_id  = "vpc-018c491cd8dfe60eb"


#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-018c491cd8dfe60eb"
private_subnets = ["subnet-0d8f022a20e25dab5"]
allowed_cidr_blocks = ["10.55.244.0/24"]