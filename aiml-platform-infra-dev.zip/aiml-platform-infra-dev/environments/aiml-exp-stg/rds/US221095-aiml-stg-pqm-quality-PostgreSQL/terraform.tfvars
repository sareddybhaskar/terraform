  
   tags = {
    Project       = "aiml-pqm-quality"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-pqm-quality"
    Role           = "it-iscst-eng-quality"
    Name           = "odp-us-aiml-exp-stg-pqm-quality-RDS"
    ApplicationTag = "pqm-quality"
    project_number = "ID6115:PR17371"
    purpose        = "inv_2025"
    UserStory      = "US221095"
    Owner          = "Philippe.Peloquin@gehealthcare.com"
  }

  name            = "odp-us-aiml-stg"
  vpc_cidr        = "10.55.246.0/23"
  existing_vpc_id = "vpc-0c41a011b63bfe291"

  # RDS
  identifier            = "odp-us-aiml-dev-pqm-quality-db"
  monitoring_role_arn   = "arn:aws:iam::991497151145:role/rds-monitoring-role"
  engine                = "postgres"
  engine_version        = "16"
  instance_class        = "db.m5.2xlarge"
  allocated_storage     = 200
  max_allocated_storage = 500
  storage_encrypted     = true

 rds_db_name  = "pqm_quality_db"
  username    = "odp_us_aimldev_pq_adm"
  password    = "odp_db_password"
  port        = "5432"

  maintenance_window = "Sun:03:00-Sun:12:00"
  backup_window      = "23:00-00:00"

  multi_az                = false
  backup_retention_period = 7

  family                          = "postgres16"
  major_engine_version            = "16"
  final_snapshot_identifier       = "devpqmqualitydb"
  deletion_protection             = true
  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]
