name = "odp-us-aiml-exp-stg"
  environment = "aiml-exp-stg"
  region = "us-east-1"
  use_existing_vpc = true
  vpc_cidr = "10.55.246.0/23"
  tags = {
    Project       = "aiml-hr-compass"
    App           = "aiml-hr-compass"
    Environment = "aiml-exp-stg"
    Program     = "ODP"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    Role = "dt-aiml-hr-compass-ds"
    UserStory = "US220401"
    Owner = "Marcin.Slowiak@gehealthcare.com"
    Contact = "Konrad.Starowicz@gehealthcare.com"
    Name = "odp-us-aiml-stg-hr-compass-aurora-postgresql"
    project_number = "ID8013:PR17945"
    Purpose = "inv_2025"
  }

  existing_vpc_id = "vpc-0c41a011b63bfe291"
  #subnets = [["subnet-0b869ba7cb42153cd"]]

  # RDS
  identifier = "odp-us-aiml-stg-hr-compass-aurora-postgresql"

  engine            = "aurora-postgresql"
  engine_version    = "16.8"
  instance_type    = "db.r5.xlarge"
  
  db_name     = "aiml_hr_compass_db"
  username = "aimlstg_hr_cmps_adm"
  password = "odp_db_password"
  port     = "5432"
  storage_encrypted = true
  maintenance_window = "Sun:03:00-Sun:12:00"
  backup_window      = "23:00-00:00"

  # multi_az = false
  backup_retention_period = 7

  family = "aurora-postgresql16"
  final_snapshot_identifier = "usaimlstghrcomps"
  deletion_protection = true


db_param_group_name = "odp-us-aimlstg-hr-compass-aurora-db-param-grp"
# db_cluster_param_group_name = "odp-us-innovation-spm-aurora-cluster-param-grp"
hr-compass-aurora-postgres-db-sg = "hr-compass-aurora-postgres-db-sg"
