provider "aws" {
  version = ">= 3.0, < 4.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/rds/US220627-aiml-contract-digit-rds1/terraform.tfstate"
    region = "us-east-1"
  }
}
##########
# DB
##########

resource "aws_rds_cluster" "postgresql" {
  cluster_identifier      = var.identifier
  engine                  = var.engine
  engine_version          = var.engine_version
  availability_zones      = ["us-east-1a"]
  database_name           = var.db_name
  master_username         = var.username
  master_password         = var.password
  port                    = var.port
  deletion_protection     = var.deletion_protection
  backup_retention_period = var.backup_retention_period
  preferred_backup_window = var.backup_window
  preferred_maintenance_window = var.maintenance_window
  vpc_security_group_ids  = ["sg-0768034a10e888657"]
  db_subnet_group_name    = "odp-us-aiml-exp-stg-db-subnet-group"
  final_snapshot_identifier = var.final_snapshot_identifier
  storage_encrypted = var.storage_encrypted
  tags = var.tags
}


resource "aws_rds_cluster_instance" "cluster_instances" {
  count              = 1
  identifier         = var.identifier
  cluster_identifier = aws_rds_cluster.postgresql.id
  instance_class     = var.instance_type
  engine             = aws_rds_cluster.postgresql.engine
  engine_version     = aws_rds_cluster.postgresql.engine_version
  db_subnet_group_name = "odp-us-aiml-exp-stg-db-subnet-group"
  db_parameter_group_name = aws_db_parameter_group.aurora_db_parameter_group.id
  apply_immediately               = true
  copy_tags_to_snapshot = true
  tags = var.tags
}


resource "aws_db_parameter_group" "aurora_db_parameter_group" {
  name        = var.db_param_group_name
  family      = var.family
  description = "contract-digit-aurora-postgresql-param-group"
}

# resource "aws_rds_cluster_parameter_group" "aurora_cluster_parameter_group" {
#   name        = var.db_cluster_param_group_name
#   family      = var.family
#   description = "contract-digitization-aurora-postgresql-param-group"
# }

resource "aws_security_group" "app_servers" {
  name        = var.contract-digit-aurora-postgres-db-sg
  description = "SG for Aurora DB servers"
  vpc_id      = var.existing_vpc_id
}

resource "aws_security_group_rule" "allow_access" {
  type                     = "ingress"
  from_port                = aws_rds_cluster.postgresql.port
  to_port                  = aws_rds_cluster.postgresql.port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.app_servers.id
  security_group_id        = aws_security_group.app_servers.id
}
