variable "name" {
  description = "Name to be used on all the resources as identifier"
}

variable "acl" {
  type        = string
  default     = "private"
  description = "Type of bucket"
}

variable "tags" {
  type        = map
}

variable "identifier" {
  type        = string
}

variable "engine" {
  type        = string
}

variable "engine_version" {
  type        = string
}

variable "instance_class" {
  type        = string
}

variable "allocated_storage" {
  type        = string
}

variable "storage_encrypted" {
  type        = string
}

variable "rds_db_name" {
  description = "The DB name to create. If omitted, no database is created initially"
  default     = ""
}

variable "username" {
  type        = string
}

variable "password" {
  type        = string
}

variable "port" {
  type        = string
}

variable "maintenance_window" {
  type        = string
}

variable "backup_window" {
  type        = string
}

variable "multi_az" {
  type        = string
}

variable "backup_retention_period" {
  type        = string
}

variable "family" {
  type        = string
}

variable "major_engine_version" {
  type        = string
}

variable "final_snapshot_identifier" {
  type        = string
}

variable "deletion_protection" {
  type        = string
}

variable "enabled_cloudwatch_logs_exports" {
  type        = list
}

variable "vpc_cidr" {
  type        = string
}

variable "max_allocated_storage" {}

variable "create_db_subnet_group" {
  default = false  
}

variable "monitoring_role_arn" {  
}

variable "existing_vpc_id" {}