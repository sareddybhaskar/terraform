  
   tags = {
    Project       = "aiml-mlops"
    Program       = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "SNSVC0011597"
    App            = "aiml-mlops"
    Role           = "dt-aiml-mlops"
    Name           = "odp-us-aiml-stg-mlops-PostgreSQL"
    ApplicationTag = "aiml-mlops"
    project_number = "ID5990:PR17717"
    purpose        = "inv_2025"
    UserStory      = "US220338"
    Owner          = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact        = "cdao_mlops_support@gehealthcare.com"
  }

  name            = "odp-us-aiml-stg"
  vpc_cidr        = "10.55.246.0/23"
  existing_vpc_id = "vpc-0c41a011b63bfe291"

  # RDS
  identifier            = "odp-us-aiml-stg-mlops-postgresql-db"
  monitoring_role_arn   = "arn:aws:iam::991497151145:role/rds-monitoring-role"
  engine                = "postgres"
  engine_version        = "17.4"
  instance_class        = "db.m5.large"
  allocated_storage     = 200
  max_allocated_storage = 500
  storage_encrypted     = true

 rds_db_name  = "aiml_mlops_db"
  username    = "odp_us_aimlstg_mlops_adm"
  password    = "odp_db_password"
  port        = "5432"

  maintenance_window = "Sun:03:00-Sun:12:00"
  backup_window      = "23:00-00:00"

  multi_az                = false
  backup_retention_period = 7

  family                          = "postgres17"
  major_engine_version            = "17.4"
  final_snapshot_identifier       = "stgaimlmlopsdb"
  deletion_protection             = true
  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]
