name = "odp-us-aiml-exp-stg"
  environment = "aiml-exp-stg"
  region = "us-east-1"
  use_existing_vpc = true
  vpc_cidr = "10.55.246.0/23"
  tags = {
    Project       = "aiml-fin-earningscall"
    App           = "aiml-fin-earningscall"
    Environment = "aiml-exp-stg"
    Program     = "ODP"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    Role = "dt-aiml-fin-earningscall"
    UserStory = "US223295"
    Owner = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact = "cdao_earningscall_support@gehealthcare.com"
    Name = "odp-us-aiml-stg-earningscall-aurora-postgresql"
    project_number = "ID7061:PR17653"
    Purpose = "inv_2025"
  }

  existing_vpc_id = "vpc-0c41a011b63bfe291"
  #subnets = [["subnet-0b869ba7cb42153cd"]]

  # RDS
  identifier = "odp-us-aiml-stg-earningscall-aurora-postgresql"

  engine            = "aurora-postgresql"
  engine_version    = "16.8"
  instance_type    = "db.r5.large"
  
  db_name     = "earningscall_db"
  username = "odp_us_aimlstg_erngscl_adm"
  password = "odp_db_password"
  port     = "5432"
  storage_encrypted = true
  maintenance_window = "Sun:03:00-Sun:12:00"
  backup_window      = "23:00-00:00"

  # multi_az = false
  backup_retention_period = 7

  family = "aurora-postgresql16"
  final_snapshot_identifier = "odpusaimlstgerngsclaurorapgdb"
  deletion_protection = true


db_param_group_name = "odp-us-aimlstg-earningscall-aurora-db-param-grp"
# db_cluster_param_group_name = "odp-us-innovation-spm-aurora-cluster-param-grp"
earningscall-aurora-postgres-db-sg = "earningscall-aurora-postgres-db-sg"
