provider "aws" {
 # version = ">= 3.0, < 4.0"
 version = ">= 4.0, < 5.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/rds/US221769-pqm-quality-stg-PostgreSQL/terraform.tfstate"
    region = "us-east-1"
  }
}

###################
# DB Security Group
###################
module "security_group" {
  source      = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sg?ref=dev"
  name        = "${var.name}-pqm-quality-sg"
  tags        = var.tags
  description = "${var.name}-pqm-quality-sg"
  vpc_id      = var.existing_vpc_id

  ingress_cidr_blocks = ["3.0.0.0/8","10.0.0.0/8"]
  ingress_rules       = ["postgresql-tcp"]
  egress_rules        = ["all-all"]


  ingress_with_self = [
    {
      rule = "all-all"
      description = "Allow Same Sg"
    },
  ]
}

##########
# DB
##########
module "db" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/rds_new?ref=dev"

  identifier            = var.identifier
  rds_engine            = var.engine
  rds_engine_version    = var.engine_version
  instance_class        = var.instance_class
  allocated_storage     = var.allocated_storage
  storage_encrypted     = var.storage_encrypted
  max_allocated_storage = var.max_allocated_storage


  # kms_key_id        = "arm:aws:kms:<region>:<accound id>:key/<kms key id>"
 rds_db_name   = var.rds_db_name
  rds_username = var.username
  rds_password = var.password
  port         = var.port
  # db_subnet_group_name   = ["odp-us-innovation-redshift-1-us-east-1a","odp-us-innovation-redshift-2-us-east-1a"]
  vpc_security_group_ids = [module.security_group.this_security_group_id]

  monitoring_role_arn = var.monitoring_role_arn
  maintenance_window = var.maintenance_window
  backup_window      = var.backup_window

  multi_az = var.multi_az

  # disable backups to create DB faster
  backup_retention_period = var.backup_retention_period

  tags = var.tags

  enabled_cloudwatch_logs_exports = var.enabled_cloudwatch_logs_exports

  # DB subnet group
  db_subnet_group_name = "odp-us-aiml-exp-stg-db-subnet-group"

  # DB parameter group
  family = var.family

  # DB option group
  major_engine_version = var.major_engine_version

  # Snapshot name upon DB deletion
  final_snapshot_identifier = var.final_snapshot_identifier

  # Database Deletion Protection
  deletion_protection = var.deletion_protection

}
