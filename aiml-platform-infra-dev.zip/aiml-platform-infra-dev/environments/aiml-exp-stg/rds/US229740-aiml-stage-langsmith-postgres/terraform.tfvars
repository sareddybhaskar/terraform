  
   tags = {
    Project       = "aiml-langsmith"
    Program       = "ODP"
    Environment    = "Stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-langsmith"
    Role           = "dt-aiml-langsmith"
    Name           = "odp-us-aiml-exp-stg-langsmith-stg-RDS"
    ApplicationTag = "aiml-langsmith"
    project_number = "AOP7433:PR18048"
    purpose        = "inv_2026"
    UserStory      = "US229740"
    Owner          = "Mukul.Musale@gehealthcare.com:Ishita.Singhal@gehealthcare.com"
    Contact        = "cdao_mlops@gehealthcare.com"
  }

  name            = "odp-us-aiml-langsmith-stg"
  vpc_cidr        = "10.55.246.0/23"
  existing_vpc_id = "vpc-0c41a011b63bfe291"

  # RDS
  identifier            = "odp-us-aiml-langsmith-stg-db"
  monitoring_role_arn   = "arn:aws:iam::991497151145:role/rds-monitoring-role"
  engine                = "postgres"
  engine_version        = "17.4"
  instance_class        = "db.t3.medium"
  allocated_storage     = 20
  max_allocated_storage = 50
  storage_encrypted     = true

  rds_db_name  = "langsmith_db"
  username    = "odp_us_aiml_langsmith_adm"
  password    = "odp_db_password"
  port        = "5432"

  maintenance_window = "Sun:03:00-Sun:12:00"
  backup_window      = "23:00-00:00"

  multi_az                = false
  backup_retention_period = 7

  family                          = "postgres17"
  major_engine_version            = "17.4"
  final_snapshot_identifier       = "langsmithstgdb"
  deletion_protection             = true
  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]
