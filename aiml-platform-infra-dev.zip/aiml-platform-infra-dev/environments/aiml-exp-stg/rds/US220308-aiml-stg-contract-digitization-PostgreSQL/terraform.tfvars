name = "odp-us-aiml-exp-stg"
  environment = "aiml-exp-stg"
  region = "us-east-1"
  use_existing_vpc = true
  vpc_cidr = "10.55.246.0/23"
  tags = {
    Project       = "aiml-contract-digit"
    App           = "aiml-contract-digit"
    Environment = "aiml-exp-stg"
    Program     = "ODP"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    UAI       = "SNSVC0011998"
    Role = "dt-aiml-contract-digit"
    UserStory = "US220308"
    Owner = "Marcin.Slowiak@gehealthcare.com"
    Contact = "Marcin.Stezowski@gehealthcare.com:Sylwia.Krakowska@gehealthcare.com"
    Name = "odp-us-aiml-dev-contract-digitization-aurora-postgresql"
    project_number = "ID7828:PR17826"
    Purpose = "inv_2025"
  }

  existing_vpc_id = "vpc-0c41a011b63bfe291"
  #subnets = [["subnet-0b869ba7cb42153cd"]]

  # RDS
  identifier = "odp-us-aiml-dev-contract-digitization-aurora-postgresql"

  engine            = "aurora-postgresql"
  engine_version    = "16.2"
  instance_type    = "db.t3.medium"
  
  db_name     = "contract_digitization_db"
  username = "odp_us_aimldev_cd_adm"
  password = "odp_db_password"
  port     = "5432"
  storage_encrypted = true
  maintenance_window = "Sun:03:00-Sun:12:00"
  backup_window      = "23:00-00:00"

  # multi_az = false
  backup_retention_period = 7

  family = "aurora-postgresql16"
  final_snapshot_identifier = "odpusaimldevcdaurorapgdb"
  deletion_protection = true


db_param_group_name = "odp-us-aimlstg-contract-digitization-aurora-db-param-grp"
# db_cluster_param_group_name = "odp-us-innovation-spm-aurora-cluster-param-grp"
contract-digitization-aurora-postgres-db-sg = "contract-digitization-aurora-postgres-db-sg"
