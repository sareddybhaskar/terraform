variable "name" {
  description = "Name to be used on all the resources as identifier"
}

variable "acl" {
  type        = "string"
  default     = "private"
  description = "Type of bucket"
}

variable "tags" {
  type        = "map"
}

variable "existing_vpc_id" {
  type        = "string"
}

variable "identifier" {
  type        = "string"
}

variable "engine" {
  type        = "string"
}

variable "engine_version" {
  type        = "string"
}

variable "instance_type" {
  type        = "string"
}

variable "username" {
  type        = "string"
}

variable "password" {
  type        = "string"
}

variable "family" {
  type        = "string"
}

variable "deletion_protection" {
  
}

# variable "database_name" {
  
# }

variable "storage_encrypted" {
  type        = string
}

variable "port" {
  description = "The port on which to accept connections"
  default     = ""
}

# variable "subnets" {
#   type = "list"
# }

variable "db_name" {
  type        = string
}


variable "db_param_group_name" {
  
}

# variable "db_cluster_param_group_name" {
  
# }

variable "contract-digitization-aurora-postgres-db-sg" {
  
}

variable "backup_window" {
  
}

variable "maintenance_window" {
  
}

variable "backup_retention_period" {
  
}


variable "final_snapshot_identifier" {
  
}