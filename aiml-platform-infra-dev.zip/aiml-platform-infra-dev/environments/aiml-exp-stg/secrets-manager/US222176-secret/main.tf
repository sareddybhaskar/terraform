provider "aws" {
  version = ">= 2.67.0"
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg/secrets-manager/US222176-secret/terraform.tfstate"
    region = "us-east-1"
  }
}

module "sm" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/secretsmanager?ref=dev"
  
  name = var.name
  secret_description = var.secret_description
  db_user_name = "${var.db_user_name}"
  db_password = "${var.db_password}"
  engine = "${var.engine}"
  db_dbname = "${var.db_dbname}"
  db_host_name = "${var.db_host_name}"
  db_port = "${var.db_port}"
  tags = "${var.tags}"
  }