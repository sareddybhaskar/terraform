variable "tags" {
  type = map
  default     = {}
}

variable "secret_description" {}
variable "name" {}
variable "db_user_name" {}
variable "db_password" {}
variable "engine" {}
variable "db_dbname" {}
variable "db_host_name" {}
variable "db_port" {}