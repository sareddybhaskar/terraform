  name               = "pqm-quality-dev-postgresql-rds-db-password-NP700009173"
  secret_description = "pqm-quality-dev-postgresql-rds-db-password-NP700009173"

  tags = {
    Program        = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-pqm-quality"
    Project        = "aiml-pqm-quality"
    Role           = "it-iscst-eng-quality"
    ApplicationTag = "avatar-mlops"
    FSSO           = "NP700009173"
    UserStory      = "US222176"
    purpose        = "inv_2025"
    project_number = "ID6115:PR17371"
    Name           = "pqm-quality-dev-postgresql-rds-db-password-NP700009173"
    Owner          = "Mouin.Abrar@gehealthcare.com"
    Contact        = "Mouin.Abrar@gehealthcare.com"
}


db_user_name         = "NP700009173"
db_password          = "db_password"
engine               = "postgresql"
db_dbname            = "pqm_quality_db"
db_host_name         = "odp-us-aiml-dev-pqm-quality-db.c4v2qoaoit7t.us-east-1.rds.amazonaws.com"
db_port              = "5432"