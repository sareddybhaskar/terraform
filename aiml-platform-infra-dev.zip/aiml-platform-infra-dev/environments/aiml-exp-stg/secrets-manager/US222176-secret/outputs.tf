output "secret_id" {
  description = "Secret id list"
  value       = module.sm.secret_ids
}

output "secret_arn" {
  description = "Secret arn list"
  value       = module.sm.secret_arns
}