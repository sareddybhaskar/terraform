output "jenkins" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.pqm-quality-instance.private_ip
  ]
}
