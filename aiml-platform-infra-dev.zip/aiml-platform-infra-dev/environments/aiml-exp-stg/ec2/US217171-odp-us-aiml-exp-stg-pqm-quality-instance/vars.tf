variable "encrypted" {
  type        = string
  description = "If true, the disk will be encrypted"
  default     = "false"
}

variable "azs" {
  description = "A list of availability zones in the region"
  default     = []
}

variable "tags" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
  default     = {}
}

variable "volume_tags" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
  default     = {}
}


variable "region" {
  description = "Name of the aws region to use"
  default     = ""
}

variable "instance_type" {
  description = "Existing VPC Id"
  default     = ""
}

variable "keypair_name" {
  description = "Existing VPC Id"
  default     = ""
}


variable "availability_zone" {
  description = "AZ to start the instance in"
  type        = string
  default     = null
}

#variable "name" {}


variable "environment" {
  default = ""
}


variable "efs_name" {
  default = ""
  
}

variable "vpc_id" {
  default = ""
}


variable "private_subnets" {
  type = list(string)
}

variable "allowed_cidr_blocks" {
  type = list(string)
  
}