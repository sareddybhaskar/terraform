output "Server1" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.market-forecasting-instance.private_ip
  ]
}

output "Server2" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.market-forecasting-instance1.private_ip
  ]
}


output "odp-us-aiml-exp-stg-market-forecasting-sg" {
  description = "Security Group"
  value       = [
      module.security_group.this_security_group_id
        ]
 }

