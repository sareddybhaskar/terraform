#!/bin/bash

#install Softwares
yum update -y
yum install ansible git nano -y
echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
rm -rf /tmp/ansible-run-command ; mkdir -p /tmp/ansible-run-command  ; git clone https://NP700001567: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@github.gehealthcare.com/gehc-odp/security-agents.git /tmp/ansible-run-command && cd /tmp/ansible-run-command && ansible-playbook --connection=local --inventory 127.0.0.1, main.yaml ; cd ~/ ; rm -rf /tmp/ansible-run-command
wget -O /tmp/awscliv2.zip https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip
unzip /tmp/awscliv2.zip
cd /tmp/
./aws/install
pip install boto boto3
pip3 install boto boto3
pip install --upgrade boto boto3
pip3 install --upgrade boto boto3



## playbook to execute
echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
git clone https://NP700001567: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@github.gehealthcare.com/gehc-odp/2fa-ldap.git
cd 2fa-ldap
ansible-playbook playbooks/aiml-exp-stg/market-forecasting/playbook.yml
rm -rf 2fa-ldap

# ###Mount EBS####
# mkdir -p /logs /data
# mkfs -t ext4 /dev/nvme1n1
# mkfs -t ext4 /dev/nvme2n1
# mount /dev/nvme1n1 /data
# mount /dev/nvme2n1 /logs
# echo '/dev/nvme1n1 /data ext4 defaults,noatime,nofail  1  0' >> /etc/fstab
# echo '/dev/nvme2n1 /logs ext4 defaults,noatime,nofail  1  0' >> /etc/fstab