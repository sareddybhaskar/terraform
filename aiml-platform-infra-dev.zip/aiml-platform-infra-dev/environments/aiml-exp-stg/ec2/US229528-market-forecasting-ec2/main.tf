
provider "aws" {

  region  = "us-east-1"
  version = " ~> 4.2.0"
}

terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/ec2/US229528-market-forecasting-ec2/terraform.tfstate"
    region = "us-east-1"
  }
  }




data "template_file" "ec2node-userdata" {
  template = file("${path.module}/ec2node_userdata.tpl")
}

module "security_group" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sg?ref=dev"

  name        = "odp-us-aiml-exp-stg-market-forecasting-sg"
  description = "Security group for market forecasting sg"
  vpc_id      = var.existing_vpc_id

  ingress_cidr_blocks = ["3.0.0.0/8","10.0.0.0/8"]
  ingress_rules       = ["https-443-tcp","http-80-tcp"]
  egress_rules        = ["all-all"]
  ingress_with_self = [
    {
      rule = "all-all"
      description = "Allow same sg"
    },
  ]
  
  tags = var.tags
}


module "market-forecasting-instance" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-exp-stg-market-forcast-instance"
  subnet_id              = "subnet-0b869ba7cb42153cd" # us-east-1a
  vpc_security_group_ids = [module.security_group.this_security_group_id]
  availability_zone      = var.availability_zone
  ami                    = "ami-09c11c41b099ddab5" #GEHCSOS-AMAZON2023_X862025-02-14T10-43-18.023Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(data.template_file.ec2node-userdata.rendered)
  root_block_device = [{
    volume_size = "50"
    volume_type = "gp3"
  }]
}

module "market-forecasting-instance1" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-exp-stg-market-forcast-backend-instance"
  subnet_id              = "subnet-0b869ba7cb42153cd" # us-east-1a
  vpc_security_group_ids = [module.security_group.this_security_group_id]
  availability_zone      = var.availability_zone
  ami                    = "ami-09c11c41b099ddab5" #GEHCSOS-AMAZON2023_X862025-02-14T10-43-18.023Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(data.template_file.ec2node-userdata.rendered)
  root_block_device = [{
    volume_size = "50"
    volume_type = "gp3"
  }]
}
