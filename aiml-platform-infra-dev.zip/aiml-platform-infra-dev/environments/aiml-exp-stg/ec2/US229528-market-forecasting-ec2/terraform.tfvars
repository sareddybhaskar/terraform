region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-0c41a011b63bfe291"


tags = {
  Project     = "aiml-market-forecasting"
  App         = "aiml-market-forecasting"
  Environment = "stg"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "SNSVC0011998"
  Patch       = "Enable"
  Program     = "aiml"
  UserStory  = "US229528"
  Role        = "dt-isc-aiml-market-forecasting"
  DLM         = "Enable"
  purpose     = "inv_2026"
  project_number = "AOP7245:PR17913"
  Owner     = "Sujan.Sivaji@gehealthcare.com:nan.wu@gehealthcare.com"
  Contact   = "Sujan.Sivaji@gehealthcare.com:nan.wu@gehealthcare.com"
}



instance_type = "t3a.large"
keypair_name  = "odp-us-aiml-exp-stg_kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-0c41a011b63bfe291"


#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-0c41a011b63bfe291"
private_subnets = ["subnet-0b869ba7cb42153cd"]
allowed_cidr_blocks = ["10.55.246.0/23"]