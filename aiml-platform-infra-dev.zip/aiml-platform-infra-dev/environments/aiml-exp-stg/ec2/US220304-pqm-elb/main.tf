provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/us-aiml-exp-stg/US220304-pqm-elb/terraform.tfstate"
    region = "us-east-1"
  }
}

######
# ELB
######
module "elb-1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/elb_new_old/modules/elb?ref=dev"

  name = "odp-us-aiml-exp-stg-pqm-elb1"

  subnets         = ["subnet-0b869ba7cb42153cd"]
  security_groups = ["sg-0707a72c8470d5c8d"]
  internal        = true

  listener = [
    {
      instance_port     = "9802"
      instance_protocol = "TCP"
      lb_port           = "9802"
      lb_protocol       = "TCP"
    },
    {
      instance_port     = "443"
      instance_protocol = "tcp"
      lb_port           = "80"
      lb_protocol       = "tcp"
    },
  ]

  health_check = {
      target              = "TCP:9802"
      interval            = 10
      healthy_threshold   = 2
      unhealthy_threshold = 10
      timeout             = 5
    }

  tags = var.tags

}

