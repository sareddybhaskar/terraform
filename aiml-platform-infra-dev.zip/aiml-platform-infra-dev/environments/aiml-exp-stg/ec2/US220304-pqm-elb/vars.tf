variable "encrypted" {
  type        = string
  description = "If true, the disk will be encrypted"
  default     = "false"
}

variable "azs" {
  description = "A list of availability zones in the region"
  default     = []
}

variable "tags" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
  default     = {}
}

variable "volume_tags" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
  default     = {}
}


variable "region" {
  description = "Name of the aws region to use"
  default     = ""
}

# variable "name" {
#   description = "Name to be used on all the resources as identifier"
#   default     = ""
# }

variable "existing_vpc_id" {
  description = "Existing VPC Id"
  default     = ""
}

# variable "image_id" {
#   description = "Existing VPC Id"
#   default     = ""
# }

variable "instance_type" {
  description = "Existing VPC Id"
  default     = ""
}

variable "keypair_name" {
  description = "Existing VPC Id"
  default     = ""
}

# variable "edge_root_volume_size" {
#   description = "Existing VPC Id"
#   default     = ""
# }

# variable "edge_root_volume_type" {
#   description = "Existing VPC Id"
#   default     = ""
# }

# variable "edge_elb_idle_timeout" {
#   description = "The time in seconds that the connection is allowed to be idle"
#   default     = 60
# }

# variable "iam_instance_profile" {
#   default = ""
# }

variable "availability_zone" {
  description = "AZ to start the instance in"
  type        = string
  default     = null
}
