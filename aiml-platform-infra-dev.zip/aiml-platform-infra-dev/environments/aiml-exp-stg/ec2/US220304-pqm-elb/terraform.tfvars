  region = "us-east-1"
  azs             = ["us-east-1a","us-east-1b"]
  availability_zone = "us-east-1a"
  vpc_id = "vpc-0c41a011b63bfe291"
  

  tags = {
    Project       = "aiml-pqm-quality"
    App           = "aiml-pqm-quality"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "APM0010159"
    Patch	    = "Enable"
    Program   = "ODP"
    Role      = "it-iscst-eng-quality"
    DLM = "Enable"
    Reboot = "Enable"
    UserStory = "US220304"
    project_number = "ID6115:PR17371"
    Owner = "kelly.boyer@gehealthcare.com"
    Contact = "kelly.boyer@gehealthcare.com"
    purpose = "inv_2025"
    }

  # vpc_security_group_ids = ["sg-0f14773cb57bb3cef"]
  
  #allowed_cidr_blocks = ["10.242.113.0/26"]
  use_existing_vpc = true
  existing_vpc_id = "vpc-0c41a011b63bfe291"