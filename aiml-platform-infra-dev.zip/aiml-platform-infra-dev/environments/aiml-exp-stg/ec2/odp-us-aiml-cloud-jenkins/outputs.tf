output "jenkins" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.jenkins.private_ip
  ]
}

output "EFS" {
  value = module.efs.id
}