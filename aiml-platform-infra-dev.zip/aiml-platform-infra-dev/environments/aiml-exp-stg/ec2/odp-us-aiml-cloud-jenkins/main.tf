
provider "aws" {

  region  = "us-east-1"
  version = " ~> 4.2.0"
}

terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/ec2/odp-us-aiml-cloud-jenkins/terraform.tfstate"
    region = "us-east-1"
  }
  }




data "template_file" "ec2node-userdata" {
  template = file("${path.module}/ec2node_userdata.tpl")
}


module "jenkins" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-cloud-jenkins"
  subnet_id              = "subnet-0b869ba7cb42153cd" # us-east-1a
  vpc_security_group_ids = ["sg-0707a72c8470d5c8d"]
  availability_zone      = var.availability_zone
  ami                    = "ami-09c11c41b099ddab5" #GEHCSOS-AMAZON2023_X862025-02-14T10-43-18.023Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(data.template_file.ec2node-userdata.rendered)
  root_block_device = [{
    volume_size = "100"
    volume_type = "gp3"
  }]
}

######
# ELB
######
module "cloud-jenkins-elb" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/elb_new_old/modules/elb?ref=dev"

  name = "odp-us-aiml-cloud-jenkins-elb"

  subnets         = ["subnet-0b869ba7cb42153cd"]
  security_groups = ["sg-0707a72c8470d5c8d"]
  internal        = true

  listener = [
    {
      instance_port     = "22"
      instance_protocol = "TCP"
      lb_port           = "22"
      lb_protocol       = "TCP"
    },
    {
      instance_port     = "8080"
      instance_protocol = "tcp"
      lb_port           = "8080"
      lb_protocol       = "tcp"
    },
  ]

  health_check = {
    target              = "TCP:22"
    interval            = 10
    healthy_threshold   = 2
    unhealthy_threshold = 10
    timeout             = 5
  }

  tags = var.tags

}


### EFS ###

module "efs" {

source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/efs?ref=dev"
  name = "odp-us-aiml-cloud-jenkins-efs"

  region = var.region
  vpc_id = var.vpc_id

  subnets  = var.private_subnets
  security_groups = ["sg-0707a72c8470d5c8d"]
  allowed_cidr_blocks = var.allowed_cidr_blocks

  encrypted = true

  tags = var.tags

} 