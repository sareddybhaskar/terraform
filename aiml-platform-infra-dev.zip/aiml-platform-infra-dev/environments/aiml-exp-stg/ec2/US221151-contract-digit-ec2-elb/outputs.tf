output "jenkins" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.contract-digit-instance.private_ip
  ]
}


output "elb-1_id" {
  description = "The name of the ELB"
  value       = module.elb-1.elb_instances
}

output "elb-1_arn" {
  description = "The ARN of the ELB"
  value       = module.elb-1.elb_arn
}

output "elb-1_name" {
  description = "The name of the ELB"
  value       = module.elb-1.elb_name
}

output "elb-1_dns_name" {
  description = "The DNS name of the ELB"
  value       = module.elb-1.elb_dns_name
}

output "elb-1_instances" {
  description = "The list of instances in the ELB"
  value       = module.elb-1.elb_instances
}
