region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-0c41a011b63bfe291"


  tags = {
    Project        = "aiml-contract-digit"
    Program        = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "SNSVC0011998"
    App            = "aiml-contract-digit"
    Role           = "dt-aiml-contract-digit"
    Name           = "odp-us-aiml-exp-dev-contract-digit"
    ApplicationTag = "contract-digit"
    project_number = "ID7828:PR17826"
    purpose        = "inv_2025"
    UserStory      = "US221151"
    Contact        = "Marcin.Stezowski@gehealthcare.com:Sylwia.Krakowska@gehealthcare.com"
  }



instance_type = "t3.large"
keypair_name  = "odp-us-aiml-exp-stg_kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-0c41a011b63bfe291"


#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-0c41a011b63bfe291"
private_subnets = ["subnet-0b869ba7cb42153cd"]
allowed_cidr_blocks = ["10.55.246.0/23"]