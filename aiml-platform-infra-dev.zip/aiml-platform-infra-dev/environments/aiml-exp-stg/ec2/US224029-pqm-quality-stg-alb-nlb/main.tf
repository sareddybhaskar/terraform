provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/us-aiml-exp-stg/US224029-pqm-quality-stg-alb-nlb/terraform.tfstate"
    region = "us-east-1"
  }
}


###############SG FOR ALB ###############
########################################
module "nlb_sg" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sg?ref=dev"

  name        = "odp-us-aiml-exp-pqm-qlty-stg-nlb-sg"
  description = "Security group for pqm quality alb and nlb sg"
  vpc_id      = var.existing_vpc_id

  ingress_cidr_blocks = ["3.0.0.0/8","10.0.0.0/8"]
  ingress_rules       = ["https-443-tcp"  ]
  egress_rules        = ["all-all"]
  
  tags = var.tags
}


################ALB ###############
################################### 

resource "aws_lb" "pqm-quality" {
  name               = "odp-us-aiml-exp-pqm-qlty-stg-alb"
  internal           = true
  load_balancer_type = "application"
    security_groups    = [module.nlb_sg.this_security_group_id]
    subnets            = ["subnet-0b869ba7cb42153cd", "subnet-00bdab308e7788dec"]

  enable_deletion_protection = true

  tags = var.tags
}

resource "aws_lb_target_group" "alb_tg" {
    name     = "odp-us-aiml-exp-pqm-qlty-stg-tg"
    port     = 80
    protocol = "HTTP"
    vpc_id   = var.vpc_id
    tags = var.tags
}

resource "aws_lb_target_group_attachment" "pqm-quality1" {
  target_group_arn = aws_lb_target_group.alb_tg.arn
  target_id        = var.instance1
  port             = 80

}


################ NLB ###############
###################################
module "nlb" {
    source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/nlb?ref=dev"
    enable_nlb = true
    nlb_name = "odp-us-aiml-exp-pqm-qlty-stg-nlb"
    nlb_subnets                    = ["subnet-0b869ba7cb42153cd", "subnet-00bdab308e7788dec"]
    nlb_enable_deletion_protection = true
    nlb_internal                   = true
    nlb_security_groups = [module.nlb_sg.this_security_group_id]
  # NLB target group
    enable_nlb_target_group   = true
    nlb_target_group_target_type = "alb"
    nlb_target_group_name     = "odp-us-aiml-exp-pqm-qlty-stg-nlb-alb-tg"
    nlb_target_group_name_prefix = "aiml-exp"
    nlb_target_group_vpc_id   = "vpc-0c41a011b63bfe291"
    nlb_target_group_protocol = "TCP"
    nlb_target_group_port     = 443
    
    # NLB target group attachment
    enable_nlb_target_group_attachment     = true
    nlb_target_group_attachment_target_ids = [aws_lb.pqm-quality.arn]

    # NLB listener
    enable_nlb_listener   = true
    nlb_listener_port = 443
    nlb_listener_protocol = "TCP"
    #nlb_listener_certificate_arn = var.acm_cert_arn

    tags = var.tags
}
