region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-0c41a011b63bfe291"


tags = {
  Project       = "aiml-pqm-quality"
    App           = "aiml-pqm-quality"
    Platform	    = "Linux"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3032643"
    Role      = "it-iscst-eng-quality"
    Owner     = "kelly.boyer@gehealthcare.com"
    Contact   = "kelly.boyer@gehealthcare.com"
    UserStory = "US224029"
    project_number    = "ID6115:PR17371"
    purpose = "inv_2026"
}

# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-0c41a011b63bfe291"
instance1 = "i-0484ea80e488afe10"

#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-0c41a011b63bfe291"
private_subnets = ["subnet-0b869ba7cb42153cd"]
allowed_cidr_blocks = ["10.55.246.0/23"]