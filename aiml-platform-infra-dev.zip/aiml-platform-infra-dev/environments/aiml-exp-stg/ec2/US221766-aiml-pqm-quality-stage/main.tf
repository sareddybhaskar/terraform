
provider "aws" {

  region  = "us-east-1"
  version = " ~> 4.2.0"
}

terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/ec2/US221766-aiml-pqm-quality-stage/terraform.tfstate"
    region = "us-east-1"
  }
  }




data "template_file" "ec2node-userdata" {
  template = file("${path.module}/ec2node_userdata.tpl")
}


module "pqm-quality-stage-instance" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-exp-stg-pqm-quality-stage-instance"
  subnet_id              = "subnet-0b869ba7cb42153cd" # us-east-1a
  vpc_security_group_ids = ["sg-0d16d0449dc39bdee"]
  availability_zone      = var.availability_zone
  ami                    = "ami-09c11c41b099ddab5" #GEHCSOS-AMAZON2023_X862025-08-19T12-13-22.128Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(data.template_file.ec2node-userdata.rendered)
  root_block_device = [{
    volume_size = "50"
    volume_type = "gp3"
  }]
}

######
# ELB
######
module "elb-1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/elb_new_old/modules/elb?ref=dev"

  name = "odp-us-aiml-exp-stg-pqm-qlty-stg"

  subnets         = ["subnet-0b869ba7cb42153cd"]
  security_groups = ["sg-0d16d0449dc39bdee"]
  internal        = true

  listener = [
    {
      instance_port     = "9802"
      instance_protocol = "TCP"
      lb_port           = "9802"
      lb_protocol       = "TCP"
    },
    {
      instance_port     = "443"
      instance_protocol = "HTTPS"
      lb_port           = "80"
      lb_protocol       = "HTTP"
    },
  ]

  health_check = {
      target              = "TCP:80"
      interval            = 10
      healthy_threshold   = 2
      unhealthy_threshold = 10
      timeout             = 5
    }

  tags = var.tags

}