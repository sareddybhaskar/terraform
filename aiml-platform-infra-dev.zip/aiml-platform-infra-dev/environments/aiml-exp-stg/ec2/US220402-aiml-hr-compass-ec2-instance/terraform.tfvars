region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-0c41a011b63bfe291"


tags = {
  Project     = "aiml-hr-compass"
  App         = "aiml-hr-compass"
  Environment = "stg"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "APM0010290"
  Patch       = "Enable"
  Program     = "aiml"
  UserStory  = "US220402"
  Role        = "dt-aiml-hr-compass-ds"
  DLM         = "Enable"
  Reboot      = "Enable"
  purpose     = "inv_2025"
  project_number = "ID8013:PR17945"
  Owner     = "Konrad.Starowicz@gehealthcare.com"
  Contact   = "Konrad.Starowicz@gehealthcare.com"
}



instance_type = "m5.xlarge"
keypair_name  = "odp-us-aiml-exp-stg_kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-0c41a011b63bfe291"


#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-0c41a011b63bfe291"
private_subnets = ["subnet-0b869ba7cb42153cd"]
allowed_cidr_blocks = ["10.55.246.0/23"]