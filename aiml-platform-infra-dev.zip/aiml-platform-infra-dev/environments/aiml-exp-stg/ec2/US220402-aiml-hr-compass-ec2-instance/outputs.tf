output "hr-compass-instance-1" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.hr-compass-instance-1.private_ip
  ]
}
output "hr-compass-instance-2" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.hr-compass-instance-2.private_ip
  ]
}