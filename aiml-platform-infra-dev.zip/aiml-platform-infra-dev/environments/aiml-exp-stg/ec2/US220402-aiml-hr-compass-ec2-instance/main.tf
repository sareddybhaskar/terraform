
provider "aws" {

  region  = "us-east-1"
  version = " ~> 4.2.0"
}

terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/ec2/US220402-aiml-hr-compass-ec2-instance/terraform.tfstate"
    region = "us-east-1"
  }
  }




data "template_file" "ec2node-userdata" {
  template = file("${path.module}/ec2node_userdata.tpl")
}


module "hr-compass-instance-1" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-exp-stg-compass-dev-instance-1"
  subnet_id              = "subnet-0b869ba7cb42153cd" # us-east-1a
  vpc_security_group_ids = ["sg-0707a72c8470d5c8d"]
  availability_zone      = var.availability_zone
  ami                    = "ami-06bed3b48efe3d487" #GEHCSOS-AMAZON2023_X862025-10-28T10-26-30.570Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(data.template_file.ec2node-userdata.rendered)
  root_block_device = [{
    volume_size = "100"
    volume_type = "gp3"
  }]
}


module "hr-compass-instance-2" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/ec2_new?ref=dev"
  name                   = "odp-us-aiml-exp-stg-compass-dev-instance-2"
  subnet_id              = "subnet-0b869ba7cb42153cd" # us-east-1a
  vpc_security_group_ids = ["sg-0707a72c8470d5c8d"]
  availability_zone      = var.availability_zone
  ami                    = "ami-06bed3b48efe3d487" #GEHCSOS-AMAZON2023_X862025-10-28T10-26-30.570Z
  instance_type          = var.instance_type
  key_name               = var.keypair_name
  tags                   = var.tags
  user_data              = base64encode(data.template_file.ec2node-userdata.rendered)
  root_block_device = [{
    volume_size = "100"
    volume_type = "gp3"
  }]
}