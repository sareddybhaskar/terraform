# name = "odp-us-prod"
region = "us-east-1"
environment = "aiml-exp-stg"


  tags = {
    Project     = "aiml-market-forecasting"
    App         = "aiml-market-forecasting"
    Environment = "stg"
    ManagedBy   = "Terraform"
    Automation  = "Jenkins"
    uai         = "SNSVC0011998"
    Program     = "aiml"
    UserStory  = "US229528"
    purpose     = "inv_2026"
    project_number = "AOP7245:PR17913"
    Owner     = "Sujan.Sivaji@gehealthcare.com:nan.wu@gehealthcare.com"
    Contact   = "Sujan.Sivaji@gehealthcare.com:nan.wu@gehealthcare.com"
  }

  vpc_id = "vpc-0c41a011b63bfe291"
  instance1 = "i-0016d92e401a0df8d"
  instance2 = "i-0da29250894aab005"
  
