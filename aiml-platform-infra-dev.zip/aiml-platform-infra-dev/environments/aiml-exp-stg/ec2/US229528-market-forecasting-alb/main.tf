provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/us-aiml-exp-stg/US229528-market-forecasting-alb/terraform.tfstate"
    region = "us-east-1"
  }
}

resource "aws_lb" "market" {
  name               = "odp-us-aiml-exp-market-alb"
  internal           = true
  load_balancer_type = "application"
    security_groups    = ["sg-0e8495c9bca73a66d"]
    subnets            = ["subnet-0b869ba7cb42153cd", "subnet-00bdab308e7788dec"]

  enable_deletion_protection = true

  tags = var.tags
}


resource "aws_lb_target_group" "alb_tg" {
    name     = "odp-us-aiml-exp-market-tg"
    port     = 80
    protocol = "HTTP"
    vpc_id   = var.vpc_id
    tags = var.tags
}

resource "aws_lb_target_group_attachment" "market1" {
  target_group_arn = aws_lb_target_group.alb_tg.arn
  target_id        = var.instance1
  port             = 80

}

////////////////////////////////////////////////////////////////////
#           ALB -2
///////////////////////////////////////////////////////////////////

resource "aws_lb" "market-bk" {
  name               = "odp-us-aiml-exp-market-bk-alb"
  internal           = true
  load_balancer_type = "application"
    security_groups    = ["sg-0e8495c9bca73a66d"]
    subnets            = ["subnet-0b869ba7cb42153cd", "subnet-00bdab308e7788dec"]

  enable_deletion_protection = true

  tags = var.tags
}


resource "aws_lb_target_group" "alb_tg1" {
    name     = "odp-us-aiml-exp-market-bk-tg"
    port     = 3000
    protocol = "HTTP"
    vpc_id   = var.vpc_id
    tags = var.tags
}

resource "aws_lb_target_group_attachment" "market-bk1" {
  target_group_arn = aws_lb_target_group.alb_tg.arn
  target_id        = var.instance2
  port             = 3000

}
