region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-0c41a011b63bfe291"


tags = {
  Project     = "aiml-fin-earningscall"
  App         = "aiml-fin-earningscall"
  Environment = "stg"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "SNSVC0011597"
  Patch       = "Enable"
  Program     = "aiml"
  UserStory  = "US219767"
  Role        = "dt-aiml-fin-earningscall"
  DLM         = "Enable"
  purpose     = "inv_2025"
  project_number = "ID7061:PR17653"
  Owner     = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
  Contact   = "cdao_mlops_support@gehealthcare.com"
}



instance_type = "m5.xlarge"
keypair_name  = "odp-us-aiml-exp-stg_kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-0c41a011b63bfe291"


#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-0c41a011b63bfe291"
private_subnets = ["subnet-0b869ba7cb42153cd"]
allowed_cidr_blocks = ["10.55.246.0/23"]