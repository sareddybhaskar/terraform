output "jenkins" {
  description = "List of Private IP's assigned to the instances"
  value = [
    module.earningscall-instance.private_ip
  ]
}
