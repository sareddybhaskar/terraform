# name = "odp-us-prod"
region = "us-east-1"
environment = "aiml-exp-stg"


  tags = {
    Project       = "aiml-fin-earningscall"
    App           = "aiml-fin-earningscall"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3032643"
    Role      = "dt-aiml-fin-earningscall"
    Owner     = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact   = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    UserStory = "US223303"
    project_number    = "ID7061:PR17653"
    purpose = "inv_2026"
  }

  vpc_id = "vpc-0c41a011b63bfe291"
  instance1 = "i-0bda9e2ea92797ccf"
  
