#---------------------------------------------------
# NLB
#---------------------------------------------------
output "nlb_name" {
  value       = module.nlb.nlb_name
}


output "nlb_dns_name" {
  description = "The DNS name of the lb presumably to be used with a friendlier CNAME."
  value       = module.nlb.nlb_dns_name
}

output "nlb_id" {
  description = "The ID of the lb we created."
  value       = module.nlb.nlb_id
}

