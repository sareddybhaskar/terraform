# variable "name" {
#   description = "Name to be used on all resources as prefix"
# }

# variable "environment" {
#   description = "Environment for service"
# }

variable "tags" {
  description = "A list of tag blocks. Each element should have keys named key, value, etc."
  type        = map(string)
  default     = {}
}

#variable "existing_vpc_id" {}

variable "availability_zone" {
  description = "AZ to start the instance in"
  type        = string
  default     = null
}

# variable "acm_cert_arn" {
#   type        = string
#   default     = null
#   }