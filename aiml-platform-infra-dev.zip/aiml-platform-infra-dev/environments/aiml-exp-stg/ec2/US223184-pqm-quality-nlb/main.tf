provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/us-aiml-exp-stg/US223184-pqm-quality-nlb/terraform.tfstate"
    region = "us-east-1"
  }
}

module "nlb" {
    source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/nlb?ref=dev"
    enable_nlb = true
    nlb_name = "odp-us-aiml-exp-pqm-qlty-nlb"
    nlb_subnets                    = ["subnet-0b869ba7cb42153cd", "subnet-00bdab308e7788dec"]
    nlb_enable_deletion_protection = true
    nlb_internal                   = true

  # NLB target group
    enable_nlb_target_group   = true
    nlb_target_group_target_type = "alb"
    nlb_target_group_name     = "odp-us-aiml-exp-pqm--qlty-nlb-alb-tg"
    nlb_target_group_name_prefix = "aiml-exp"
    nlb_target_group_vpc_id   = "vpc-0c41a011b63bfe291"
    nlb_target_group_protocol = "TCP"
    nlb_target_group_port     = 443
    
    # NLB target group attachment
    enable_nlb_target_group_attachment     = true
    nlb_target_group_attachment_target_ids = ["arn:aws:elasticloadbalancing:us-east-1:991497151145:loadbalancer/app/odp-us-aiml-exp-pqm-qlty-alb/a0b41e4e9d06759b"]

    # NLB listener
    enable_nlb_listener   = true
    nlb_listener_port = 443
    nlb_listener_protocol = "TCP"
    #nlb_listener_certificate_arn = var.acm_cert_arn

    tags = var.tags
}
