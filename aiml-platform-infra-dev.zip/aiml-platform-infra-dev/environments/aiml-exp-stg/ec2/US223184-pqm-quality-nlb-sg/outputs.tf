
output "odp-us-aiml-exp-pqm-qlty-nlb-sg" {
  description = "Security Group"
  value       = [
      module.nlb_sg.this_security_group_id
        ]
 }

