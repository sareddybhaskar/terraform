region            = "us-east-1"
azs               = ["us-east-1a", "us-east-1b"]
availability_zone = "us-east-1a"
vpc_id            = "vpc-0c41a011b63bfe291"


tags = {
  Project     = "aiml-cicd"
  App         = "cicd-automation"
  Environment = "stg"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "UAI3053026"
  Patch       = "Enable"
  Program     = "aiml"
  UserStory  = "US216554"
  Role        = "dt-dna"
  DLM         = "Enable"
  purpose     = "inv_2025"
  project_number = "ID7061:PR17653"
  Owner     = "vivek.agrawal1@gehealthcare.com:karthikeyan.kandasamy@gehealthcare.com"
  Contact   = "Health_ODP_CICD_Dev_Team@gehealthcare.com"
}



instance_type = "r7a.xlarge"
keypair_name  = "odp-us-aiml-exp-stg-tools-kp"


# vpc_security_group_ids = ["sg-081b7ba48a00ed59c"]

#allowed_cidr_blocks = ["10.55.246.0/23"]
use_existing_vpc = true
existing_vpc_id  = "vpc-0c41a011b63bfe291"

#### EFS ####
encrypted = "true"

#efs_name = "odp-us-aiml-cloud-jenkins"
#vpc_id = "vpc-0c41a011b63bfe291"
private_subnets = ["subnet-0b869ba7cb42153cd"]
allowed_cidr_blocks = ["10.55.246.0/23"]