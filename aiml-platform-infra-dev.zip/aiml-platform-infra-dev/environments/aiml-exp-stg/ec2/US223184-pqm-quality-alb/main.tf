provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/us-aiml-exp-stg/US223184-pqm-quality-alb/terraform.tfstate"
    region = "us-east-1"
  }
}

resource "aws_lb" "pqm-quality" {
  name               = "odp-us-aiml-exp-pqm-qlty-alb"
  internal           = true
  load_balancer_type = "application"
    security_groups    = ["sg-0d16d0449dc39bdee"]
    subnets            = ["subnet-0b869ba7cb42153cd", "subnet-00bdab308e7788dec"]

  enable_deletion_protection = true

  tags = var.tags
}

resource "aws_lb_target_group" "alb_tg" {
    name     = "odp-us-aiml-exp-pqm-qlty-tg"
    port     = 80
    protocol = "HTTP"
    vpc_id   = var.vpc_id
    tags = var.tags
}

resource "aws_lb_target_group_attachment" "pqm-quality1" {
  target_group_arn = aws_lb_target_group.alb_tg.arn
  target_id        = var.instance1
  port             = 80

}

# resource "aws_lb_listener" "pqm-quality" {
#   load_balancer_arn = aws_lb.pqm-quality.arn
#   port              = "443"
#   protocol          = "HTTPS"
#   ssl_policy        = "ELBSecurityPolicy-2016-08"
#   certificate_arn   = "arn:aws:acm:us-east-1:245792935030:certificate/b8fb42a1-c279-4e19-b9ab-8a06918a43cf"

#   default_action {
#     type             = "forward"
#     target_group_arn = aws_lb_target_group.alb_tg.arn
#   }
# }
