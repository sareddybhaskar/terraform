# name = "odp-us-prod"
region = "us-east-1"
environment = "aiml-exp-stg"


  tags = {
    Project       = "aiml-pqm-quality"
    App           = "aiml-pqm-quality"
    Platform	    = "Linux"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3032643"
    Patch	    = "Disable"
    Role      = "it-iscst-eng-quality"
    Owner     = "kelly.boyer@gehealthcare.com"
    Contact   = "kelly.boyer@gehealthcare.com"
    UserStory = "US223184"
    project_number    = "ID6115:PR17371"
    purpose = "inv_2025"
  }

  vpc_id = "vpc-0c41a011b63bfe291"
  instance1 = "i-0d98890579076118d"
  
