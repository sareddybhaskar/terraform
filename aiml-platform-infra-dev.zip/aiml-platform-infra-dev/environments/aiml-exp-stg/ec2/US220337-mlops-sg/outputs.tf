
output "odp-us-aiml-exp-stg-mlops-sg" {
  description = "Security Group"
  value       = [
      module.security_group.this_security_group_id
        ]
 }

output "odp-us-aiml-exp-stg-pqm-quality-sg" {
  description = "Security Group"
  value       = [
      module.security_group1.this_security_group_id
        ]
 }