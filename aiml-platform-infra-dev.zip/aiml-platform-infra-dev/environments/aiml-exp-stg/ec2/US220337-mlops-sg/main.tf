provider "aws" {
  # version = ">= 2.20"
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/us-aiml-exp-stg/US220337-mlops-sg/terraform.tfstate"
    region = "us-east-1"
  } 
}

#data "aws_ami" "etl-redshift" {
#  most_recent = true
#  filter {
#    name = "name"
#    values = ["matillion-etl-for-redshift-ami-1.75.0-billing-08-05-2024-09h-23m"]
#  }
#  owners = ["807659967283"]
#}

module "security_group" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sg?ref=dev"

  name        = "odp-us-aiml-exp-stg-mlops-sg"
  description = "Security group for mlops sg"
  vpc_id      = var.existing_vpc_id

  ingress_cidr_blocks = ["3.0.0.0/8","10.0.0.0/8"]
  ingress_rules       = ["https-443-tcp","http-80-tcp"]
  egress_rules        = ["all-all"]
  ingress_with_self = [
    {
      rule = "all-all"
      description = "Allow same sg"
    },
  ]
  
  tags = var.tags
}

module "security_group1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sg?ref=dev"

  name        = "odp-us-aiml-exp-stg-pqm-quality-sg"
  description = "Security group for pqm quality sg"
  vpc_id      = var.existing_vpc_id

  ingress_cidr_blocks = ["3.0.0.0/8","10.0.0.0/8"]
  ingress_rules       = ["https-443-tcp","http-80-tcp"]
  egress_rules        = ["all-all"]
  ingress_with_self = [
    {
      rule = "all-all"
      description = "Allow same sg"
    },
  ]
  
  tags = var.tags1
}


