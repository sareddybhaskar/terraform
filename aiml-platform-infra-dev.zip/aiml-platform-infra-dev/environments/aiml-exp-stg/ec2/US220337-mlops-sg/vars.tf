variable "tags" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
  default     = {}
}

variable "tags1" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
  default     = {}
}

# variable "volume_tags" {
#   description = "A mapping of volume tags to assign to the resource"
#   type        = map(string)
#   default     = {}
# }

variable "existing_vpc_id" {}

variable "availability_zone" {
  description = "AZ to start the instance in"
  type        = string
  default     = null
}
