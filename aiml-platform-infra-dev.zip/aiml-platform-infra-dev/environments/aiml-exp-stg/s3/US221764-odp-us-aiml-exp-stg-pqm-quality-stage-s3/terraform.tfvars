  tags = {
    Project       = "aiml-pqm-quality"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App = "aiml-pqm-quality"
    Role = "it-iscst-eng-quality"
    Name = "odp-us-aiml-exp-stg-pqm-quality-stage"
    ApplicationTag = "pqm-quality-stage"
    project_number = "ID6115:PR17371"
    purpose = "inv_2025"
    UserStory = "US221764"
    Owner     = "Philippe.Peloquin@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-pqm-quality-stage"