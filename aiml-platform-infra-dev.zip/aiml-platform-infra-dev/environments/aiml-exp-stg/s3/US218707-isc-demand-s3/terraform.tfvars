
  tags = {
    Project       = "aiml-isc-demand"
    Program       = "ODP"
    Environment    = "Stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App = "aiml-ofp-isc-demand"
    Role = "dt-aiml-isc-demand-ds"
    Name = "odp-us-aiml-exp-stg-isc-demand"
    ApplicationTag = "isc-demand"
    project_number = "ID5846:PR15788"
    purpose = "inv_2025"
    UserStory = "US218707"
    Owner     = "Philippe.Peloquin@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-isc-demand"
