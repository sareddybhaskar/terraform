
  tags = {
    Project       = "aiml-fin-revenue"
    Program       = "ODP"
    Environment    = "Stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App = "aiml"
    Role = "dt-aiml-fin-revenue-ds"
    Name = "odp-us-aiml-exp-stg-revenue-forecasting"
    ApplicationTag = "revenue-forecasting"
    project_number = "ID5846:PR15788"
    purpose = "inv_2025"
    UserStory = "US218873"
    Owner     = "Philippe.Peloquin@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-fin-revenue"