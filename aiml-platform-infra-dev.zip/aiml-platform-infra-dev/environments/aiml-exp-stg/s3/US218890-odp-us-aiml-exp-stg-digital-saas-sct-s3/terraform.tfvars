  tags = {
    Project       = "aiml-digital-saas-sct"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-digital-saas-sct"
    Role           = "dt-digital-saas-sct"
    Name           = "odp-us-aiml-exp-stg-digital-saas-sct"
    ApplicationTag = "digital-saas-sct"
    project_number = "ID5879:PR17103"
    purpose        = "inv_2025"
    UserStory      = "US218890"
    Owner          = "Philippe.Peloquin@gehealthcare.com"
  }


bucket-name = "odp-us-aiml-exp-stg-digital-saas-sct"