provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
  profile = "aiml-exp-stg"
}

module "s3" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/s3_new?ref=dev"
  bucket_name     = var.bucket-name
  versioning = {
  enabled = false
  }
  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm     = "AES256"
      }
    }
  }
  tags = var.tags
}
