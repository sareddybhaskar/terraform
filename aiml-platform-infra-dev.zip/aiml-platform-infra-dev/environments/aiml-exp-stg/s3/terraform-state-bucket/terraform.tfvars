tags = {
    Project       = "odp"
    Program       = "ODP"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3053026"
    App = "cloud-ops"
    Role = "dt-dna"
    Name = "odp-us-aiml-exp-stg-terraform"
  }

bucket-name = "odp-us-aiml-exp-stg-terraform"