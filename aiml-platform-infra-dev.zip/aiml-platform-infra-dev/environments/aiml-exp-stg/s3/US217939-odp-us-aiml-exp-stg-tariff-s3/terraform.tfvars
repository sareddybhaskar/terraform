tags = {
    Project       = "aiml-tariff"
    Program       = "ODP"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3053026"
    App = "aiml-tariff"
    Role = "dt-aiml-tariff"
    Name = "odp-us-aiml-exp-stg-tariff"
    ApplicationTag = "aiml-tariff"
    project_number = "ID7057:PR17752"
    purpose = "inv_2025"
    UserStory = "US217939"
    Owner     = "Philippe.Peloquin@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-tariff"