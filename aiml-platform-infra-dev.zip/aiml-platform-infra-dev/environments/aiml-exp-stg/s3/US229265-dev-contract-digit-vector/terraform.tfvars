
  tags = {
    Project       = "aiml-audit"
    Program       = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-contract-digit"
    Role           = "dt-aiml-contract-digit"
    Name           = "odp-us-aiml-exp-stg-audit-ai-vector"
    ApplicationTag = "contract-digit"
    project_number = "ID7828:PR17826"
    purpose        = "inv_2026"
    UserStory      = "US229265"
    Owner          = "Marcin.Stezowski@gehealthcare.com:Sylwia.Krakowska@gehealthcare.com"
    Contact         = "Marcin.Stezowski@gehealthcare.com:Sylwia.Krakowska@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-dev-contract-digit-service-vector"