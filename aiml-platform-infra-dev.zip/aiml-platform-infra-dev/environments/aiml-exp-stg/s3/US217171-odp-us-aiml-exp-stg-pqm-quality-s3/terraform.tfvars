tags = {
    Project       = "aiml-pqm-quality"
    Program       = "ODP"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3053026"
    App = "aiml-pqm-quality"
    Role = "it-iscst-eng-quality"
    Name = "odp-us-aiml-exp-stg-pqm-quality"
    ApplicationTag = "pqm-quality"
    project_number = "ID6115:PR17371"
    purpose = "inv_2025"
    UserStory = "US217171"
    Owner     = "Philippe.Peloquin@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-pqm-quality"