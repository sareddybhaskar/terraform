
  tags = {
    Project       = "aiml-hr-compass"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-hr-compass"
    Role           = "dt-aiml-hr-compass-ds"
    Name           = "odp-us-aiml-exp-stg-hr-compass"
    ApplicationTag = "hr-compass"
    project_number = "ID8013:PR17945"
    purpose        = "inv_2025"
    UserStory      = "US220310"
    Owner          = "Konrad.Starowicz@gehealthcare.com"
    Contact         = "Konrad.Starowicz@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-hr-compass"