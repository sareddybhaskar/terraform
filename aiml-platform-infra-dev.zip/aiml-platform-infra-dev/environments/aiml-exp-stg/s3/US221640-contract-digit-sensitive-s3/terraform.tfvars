
  tags = {
    Project       = "aiml-contract-digit"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-contract-digit"
    Role           = "dt-aiml-contract-digit"
    Name           = "odp-us-aiml-exp-dev-contract-digit-sensitive"
    ApplicationTag = "contract-digit"
    project_number = "ID7828:PR17826"
    purpose        = "inv_2025"
    UserStory      = "US221640"
    Owner          = "Marcin.Stezowski@gehealthcare.com"
    Contact         = "Marcin.Stezowski@gehealthcare.com:Sylwia.Krakowska@gehealthcare.com:Weronika.Langer@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-dev-contract-digit-sensitive"