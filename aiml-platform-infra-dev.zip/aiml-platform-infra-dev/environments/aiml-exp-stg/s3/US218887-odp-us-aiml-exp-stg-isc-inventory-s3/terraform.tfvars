
  tags = {
    Project       = "aiml-isc-inventory"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml"
    Role           = "dt-aiml-isc-inventory-ds"
    Name           = "odp-us-aiml-exp-stg-isc-inventory"
    ApplicationTag = "isc-inventory"
    project_number = "ID5846:PR15788"
    purpose        = "inv_2025"
    UserStory      = "US218887"
    Owner          = "Philippe.Peloquin@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-isc-inventory"