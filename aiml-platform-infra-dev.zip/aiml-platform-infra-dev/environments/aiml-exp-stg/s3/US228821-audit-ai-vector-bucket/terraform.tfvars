
  tags = {
    Project       = "aiml-audit"
    Program       = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml"
    Role           = "dt-aiml-audit-ds"
    Name           = "odp-us-aiml-exp-stg-audit-ai-vector"
    ApplicationTag = "aiml-audit"
    project_number = "ID7061:PR17653"
    purpose        = "inv_2026"
    UserStory      = "US228821"
    Owner          = "Mukul.Musale@gehealthcare.com"
    Contact         = "cdao_mlops@gehealthcare.com"
  }

bucket-name = "odp-us-aiml-exp-stg-audit-ai-vector"