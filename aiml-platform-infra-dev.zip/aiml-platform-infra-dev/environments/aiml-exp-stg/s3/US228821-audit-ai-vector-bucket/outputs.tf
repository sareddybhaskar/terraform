output "vector_bucket_name" {
  description = "Name of the S3 Vector Bucket"
  value = aws_s3vectors_vector_bucket.audit-ai-vector
}

output "vector_bucket_name_arn" {
  description = "ARN of the S3 Vector Bucket"
  value = aws_s3vectors_vector_bucket.audit-ai-vector.vector_bucket_arn
}