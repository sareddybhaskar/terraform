provider "aws" {
  version = ">= 6.24.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/s3/US228821-audit-ai-vector-bucket/terraform.tfstate"
    region = "us-east-1"
  }
}

/* module "s3" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/s3_new?ref=dev"
  bucket_name     = var.bucket-name
  versioning = {
  enabled = false
  }
  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm     = "AES256"
      }
    }
  }
  tags = var.tags
} */

resource "aws_s3vectors_vector_bucket" "audit-ai-vector" {
  vector_bucket_name = var.bucket-name
 
encryption_configuration {
    sse_type    = "AES256"
  }
  
  tags = var.tags
}