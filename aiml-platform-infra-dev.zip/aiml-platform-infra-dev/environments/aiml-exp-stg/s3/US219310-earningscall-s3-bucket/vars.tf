variable "tags" {
  default     = {}
  description = "Additional tags (e.g. map(`BusinessUnit`,`XYZ`)"
}

variable "bucket-name" {}
variable "bucket-name1" {}