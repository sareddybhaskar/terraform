  tags = {
    Project       = "aiml-fin-earningscal"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-fin-earningscal"
    Role           = "dt-aiml-fin-earningscall"
    Name           = "odp-us-aiml-exp-stg-earningscall"
    ApplicationTag = "aiml-fin-earningscall"
    project_number = "ID7061:PR17653"
    purpose        = "inv_2025"
    UserStory      = "US219310"
    Owner          = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact        = "cdao_mlops_support@gehealthcare.com"
  }


bucket-name = "odp-us-aiml-exp-stg-earningscall"
bucket-name1 = "odp-us-aiml-exp-stg-earningscall-sensitive"