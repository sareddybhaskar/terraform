output "bucket_name" {
  value       = [
      module.s3.s3_bucket_domain_name
    ]
  description = "FQDN of bucket"
}

output "bucket_id" {
  value       = [
      module.s3.s3_bucket_id
    ]
  description = "Bucket Name (aka ID)"
}


output "bucket_name1" {
  value       = [
      module.s3-bucket.s3_bucket_domain_name
    ]
  description = "FQDN of bucket"
}

output "bucket_id1" {
  value       = [
      module.s3-bucket.s3_bucket_id
    ]
  description = "Bucket Name (aka ID)"
}