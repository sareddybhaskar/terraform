output "domain_id" {
    value = module.domain.sagemaker_domain_id
}

output "domain_arn" {
    value = module.domain.sagemaker_domain_arn
}