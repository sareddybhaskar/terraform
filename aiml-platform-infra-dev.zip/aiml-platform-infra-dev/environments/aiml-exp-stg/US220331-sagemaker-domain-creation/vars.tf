variable "tags" {
  default     = {}
}

variable "execution_role" {}

variable "domain_name" {}

variable "kms_key_id" {}

variable "environment" {}

variable "region" {}

variable "name" {}

variable "domain_auth_mode" {}

variable "domain_vpc_id" {}

variable "domain_subnet_ids" {}

variable "security_groups" {}

variable "app_network_access_type" {}

#### User Profiles variables ####
variable "admin_user_profile_name" {}

variable "admin_execution_role" {}