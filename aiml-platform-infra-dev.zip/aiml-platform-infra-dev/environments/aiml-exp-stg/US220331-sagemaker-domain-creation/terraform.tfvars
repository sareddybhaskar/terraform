  name = "odp-us-aiml-exp-stg"
  region = "us-east-1"
  environment = "aiml-exp-stg"

  tags = {
    Project       = "aiml-ofp"
    App           = "aiml-ofp"
    Program       = "ODP"
    Environment = "stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3032643"
    ApplicationTag = "revenue-forecasting"
    Role          = "dt-aiml-ofp-ds"
    UserStory = "US220331"
    purpose = "inv_2025"
    project_number = "ID5990:PR17717"
    Owner = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact = "cdao_mlops_support@gehealthcare.com"
  }

execution_role = "arn:aws:iam::991497151145:role/odp-us-aiml-exp-stg-fin-revenue-service-role"
domain_name = "us-aiml-stg-forecating"
kms_key_id = "arn:aws:kms:us-east-1:991497151145:key/d9ec81a9-e7af-427f-8a18-ed657959e546"

domain_auth_mode = "IAM"
domain_vpc_id = "vpc-0c41a011b63bfe291"
domain_subnet_ids = ["subnet-0b869ba7cb42153cd"]
security_groups = ["sg-0707a72c8470d5c8d"]
app_network_access_type = "VpcOnly"



#### User Profiles ####
admin_user_profile_name = "hc-ai-fin-revenue-user"
admin_execution_role = "arn:aws:iam::991497151145:role/odp-us-aiml-exp-stg-fin-revenue-service-role"