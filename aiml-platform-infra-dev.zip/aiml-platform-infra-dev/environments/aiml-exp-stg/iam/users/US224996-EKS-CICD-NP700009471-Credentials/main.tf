provider "aws" {
  #version = ">= 3.0, < 4.0"
  #version = "~> 5.0"
  version = "6.2.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg/iam/users/US224996-EKS-CICD-NP700009471-Credentials/terraform.tfstate"
    region = "us-east-1"
  }
}



###### Local Template Files ######

data "template_file" "addon" {
  template = file("${path.module}/odp-us-aiml-exp-stg-digital-saas-sct-cicd-policy.json.tpl")
}


###### Creating IAM Policy ######

module "addon" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-digital-saas-sct-cicd-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-digital-saas-sct-cicd-policy"

  policy = data.template_file.addon.rendered
}


###### CICD Role ######

resource "aws_iam_role" "servicerole" {
  name        = "odp-us-aiml-exp-stg-cicd-digital-saas-sct-service-role"
  description = "odp-us-aiml-exp-stg-cicd-digital-saas-sct-service-role"

  assume_role_policy    = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": [
                    "scheduler.amazonaws.com",
                    "dynamodb.amazonaws.com",
                    "es.amazonaws.com",
                    "glue.amazonaws.com",
                    "sqs.amazonaws.com",
                    "s3.amazonaws.com",
                    "secretsmanager.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "events.amazonaws.com",
                    "states.amazonaws.com",
                    "ecr.amazonaws.com",
                    "logs.amazonaws.com",
                    "sagemaker.amazonaws.com"                   
                ]
            },
            "Action": "sts:AssumeRole"
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::991497151145:user/NP700009325"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags            = var.tags
}

###### Attaching Policies to CICD Role ######

resource "aws_iam_role_policy_attachment" "service1" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service2" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service3" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-digital-saas-sct-service-policy"
}

resource "aws_iam_role_policy_attachment" "service4" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.addon.arn
}

resource "aws_iam_role_policy_attachment" "service5" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-stg-cicd-common-api-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service6" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-stg-cicd-common-role-policy"
}

resource "aws_iam_role_policy_attachment" "service7" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-stg-cicd-logs-s3bucket-policy"  
  }

######FSSO############

data "template_file" "digital-saas-sct" {
  template = file("${path.module}/odp-us-aiml-exp-stg-digital-saas-sct-fsso-NP700009325-policy.json.tpl")
}

module "digital-saas-sct_policy" {
  source      = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-digital-saas-sct-fsso-NP700009325-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-digital-saas-sct-fsso-NP700009325-policy"

  policy      = "${data.template_file.digital-saas-sct.rendered}"
}

module "digital-saas-sct_fsso" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/user_new?ref=dev"
  name                   = "NP700009325"
  create_iam_access_key  = true
  tags                   = var.tags
}

resource "aws_iam_user_policy_attachment" "iam_user_policy_attachment" {

  user       = module.digital-saas-sct_fsso.this_iam_user_name
  policy_arn = module.digital-saas-sct_policy.arn

}