region      = "us-east-1"
environment = "aiml-exp-stg"

  tags = {
    Program        = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-digital-saas-sct"
    Project        = "aiml-digital-saas-sct"
    Role           = "dt-digital-saas-sct"
    ApplicationTag = "digital-saas-sct"
    UserStory      = "US223140"
    project_number = "ID5879:PR17103"
    purpose        = "inv_2025"
    Owner          = "Vivek.Agrawal1@gehealthcare.com"
    Contact        = "Health_ODP_CICD_Dev_Team@gehealthcare.com"
  }
