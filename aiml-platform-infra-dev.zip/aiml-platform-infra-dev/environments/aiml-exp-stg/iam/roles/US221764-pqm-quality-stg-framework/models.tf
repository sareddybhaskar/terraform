##############Bedrock Models ##############

data "template_file" "user-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-pqm-quality-stage-user-model-policy.json.tpl")

  vars = {
    # titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model1.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model2.arn
    # titan_image_generator_g1_v1_arn = aws_bedrock_inference_profile.model3.arn
    # titan_image_generator_g1_v2_arn = aws_bedrock_inference_profile.model4.arn
    # titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model5.arn
    # nova_pro_arn = aws_bedrock_inference_profile.model6.arn
    # claude_3_opus_arn = aws_bedrock_inference_profile.model7.arn
    # claude_3_haiku_arn = aws_bedrock_inference_profile.model8.arn
    # claude_3_5_sonnet_v2_arn = aws_bedrock_inference_profile.model9.arn
    # claude_3_5_haiku_arn = aws_bedrock_inference_profile.model10.arn
    # claude_3_5_sonnet_arn = aws_bedrock_inference_profile.model11.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model12.arn
        claude_sonnet_4_6_arn = aws_bedrock_inference_profile.model13.arn
    claude_sonnet_4_20250514_arn = aws_bedrock_inference_profile.model14.arn
  }
  
}

# service model policy template
data "template_file" "service-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-pqm-quality-stage-service-model-policy.json.tpl")

  vars = {
    # titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model1.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model2.arn
    # titan_image_generator_g1_v1_arn = aws_bedrock_inference_profile.model3.arn
    # titan_image_generator_g1_v2_arn = aws_bedrock_inference_profile.model4.arn
    # titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model5.arn
    # nova_pro_arn = aws_bedrock_inference_profile.model6.arn
    # claude_3_opus_arn = aws_bedrock_inference_profile.model7.arn
    # claude_3_haiku_arn = aws_bedrock_inference_profile.model8.arn
    # claude_3_5_sonnet_v2_arn = aws_bedrock_inference_profile.model9.arn
    # claude_3_5_haiku_arn = aws_bedrock_inference_profile.model10.arn
    # claude_3_5_sonnet_arn = aws_bedrock_inference_profile.model11.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model12.arn
        claude_sonnet_4_6_arn = aws_bedrock_inference_profile.model13.arn
    claude_sonnet_4_20250514_arn = aws_bedrock_inference_profile.model14.arn
  }
}

module "user-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-pqm-quality-stage-user-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-pqm-quality-stage-user-model-policy"

  policy = data.template_file.user-model-policy.rendered
}

module "service-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-pqm-quality-stage-service-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-pqm-quality-stage-service-model-policy"

  policy = data.template_file.service-model-policy.rendered
}

###### Bedrock Instance Profile ######


resource "aws_bedrock_inference_profile" "model2" {
  name        = "pqm-quality-stage-titan-text-embeddings-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-text-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-stage-titan-text-embeddings-v2"
    }
  )
}


resource "aws_bedrock_inference_profile" "model12" {
  name        = "pqm-quality-stage-claude-3-7-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-stage-claude-3-7-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model13" {
  name        = "pqm-quality-stage-claude-sonnet-4-6"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-6"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-stage-claude-sonnet-4-6"
    }
  )
}

resource "aws_bedrock_inference_profile" "model14" {
  name        = "pqm-quality-stage-claude-sonnet-4-20250514"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-stage-claude-sonnet-4-20250514"
    }
  )
}   