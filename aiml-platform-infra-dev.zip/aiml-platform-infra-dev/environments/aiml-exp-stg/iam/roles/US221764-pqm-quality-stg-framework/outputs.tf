output "login-role" {
  value = module.hc-ai-pqm-quality-stage.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}

