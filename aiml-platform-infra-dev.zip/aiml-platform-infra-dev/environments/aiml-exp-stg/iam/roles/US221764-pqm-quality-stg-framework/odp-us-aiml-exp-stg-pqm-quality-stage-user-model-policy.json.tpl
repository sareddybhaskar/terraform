{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/rvntpn2vwv36",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/rhi83plz1ij1"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/rvntpn2vwv36",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/rhi83plz1ij1",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/w40nd9munqah",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/qntkc5kyadjp"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-2::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-west-2::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/rvntpn2vwv36",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/rhi83plz1ij1",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-6",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
            ]
        }
    ],
    "Version": "2012-10-17"
}