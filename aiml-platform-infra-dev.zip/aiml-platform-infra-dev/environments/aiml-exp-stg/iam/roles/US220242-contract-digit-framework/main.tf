provider "aws" {
  #version = ">= 3.0, < 4.0"
  #version = "~> 5.0"
  version = "6.2.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/iam/roles/US220242-contract-digit-framework/terraform.tfstate"
    region = "us-east-1"
  }
}

############Cloud Ploicy############

data "template_file" "user-reservered-cloud-template" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-ai-contract-digit-user-cloud-policy.json.tpl")
}

module "user-reservered-cloud-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-ai-contract-digit-user-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-ai-contract-digit-user-cloud-policy"

  policy = data.template_file.user-reservered-cloud-template.rendered
}


data "template_file" "user-reservered-template" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-ai-contract-digit-user-policy.json.tpl")
}

module "user-reservered-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-ai-contract-digit-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-ai-contract-digit-user-policy"

  policy = data.template_file.user-reservered-template.rendered
}

###### Local Template Files ######

data "template_file" "service" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-service-policy.json.tpl")
}

data "template_file" "hc-digit-service1" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-service1-policy.json.tpl")
}

data "template_file" "user" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-user-policy.json.tpl")
}

data "template_file" "hc-digit-user1" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-user1-policy.json.tpl")
}

data "template_file" "notebook" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-sagemakernotebook-policy.json.tpl")
}

###### Creating IAM Policy ######

module "user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-user-policy"

  policy = data.template_file.user.rendered
}

module "hc-digit-user1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-user1-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-user1-policy"

  policy = data.template_file.hc-digit-user1.rendered
}

module "service" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-service-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-service-policy"

  policy = data.template_file.service.rendered
}

module "hc-digit-service1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-service1-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-service1-policy"

  policy = data.template_file.hc-digit-service1.rendered
}

module "notebook" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-sagemakernotebook-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-sagemakernotebook-policy"

  policy = data.template_file.notebook.rendered
}

###### Login Role ######

module "hc-ai-contract-digit-user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-ai-contract-digit-user"
  role_description      = "hc-ai-contract-digit-user"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-aiml-exp-dev-contract-dgt_236938c7c978bce6"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
}

###### Service Role ######

resource "aws_iam_role" "servicerole" {
  name        = "odp-us-aiml-exp-dev-contract-digit-service-role"
  description = "odp-us-aiml-exp-dev-contract-digit-service-role"

  assume_role_policy    = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": [
                    "s3.amazonaws.com",
                    "secretsmanager.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "events.amazonaws.com",
                    "states.amazonaws.com",
                    "logs.amazonaws.com",
                    "ecs.amazonaws.com",
                    "ecr.amazonaws.com",
                    "ec2.amazonaws.com",
                    "lambda.amazonaws.com",
                    "bedrock.amazonaws.com",
                    "sagemaker.amazonaws.com"

                    
                ]
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags            = var.tags
}

###### Attaching Policies to Login Role ######

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy" 
}

  resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = module.user.arn
}

  resource "aws_iam_role_policy_attachment" "user19" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = module.hc-digit-user1.arn
}

resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
} 

resource "aws_iam_role_policy_attachment" "user6" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = module.user-model.arn
} 
 
resource "aws_iam_role_policy_attachment" "user13" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = module.notebook.arn
} 

resource "aws_iam_role_policy_attachment" "user14" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-root-internet-access-policy" 
}

resource "aws_iam_role_policy_attachment" "user15" {
  role       = module.hc-ai-contract-digit-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-sagemaker-deny-instance-type-policy" 
}

###### Attaching Policies to Service Role ######

resource "aws_iam_role_policy_attachment" "service1" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service3" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service4" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service.arn
}

resource "aws_iam_role_policy_attachment" "service16" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.hc-digit-service1.arn
}

resource "aws_iam_role_policy_attachment" "service5" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service-model.arn
}

resource "aws_iam_role_policy_attachment" "service10" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.notebook.arn
}

resource "aws_iam_role_policy_attachment" "service11" {
  role       = aws_iam_role.servicerole.name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-root-internet-access-policy" 
}

resource "aws_iam_role_policy_attachment" "service12" {
  role       = aws_iam_role.servicerole.name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-sagemaker-deny-instance-type-policy" 
}
############Cloud Ploicy############

data "template_file" "user-reservered-cloud-template1" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-ai-contract-digit-non-sensitive-user-cloud-policy.json.tpl")
}

module "user-reservered-cloud-policy1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-ai-contract-digit-non-sensitive-user-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-ai-contract-digit-non-sensitive-user-cloud-policy"

  policy = data.template_file.user-reservered-cloud-template1.rendered
}


data "template_file" "user-reservered-template1" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-ai-contract-digit-non-sensitive-user-policy.json.tpl")
}

module "user-reservered-policy1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-ai-contract-digit-non-sensitive-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-ai-contract-digit-non-sensitive-user-policy"

  policy = data.template_file.user-reservered-template1.rendered
}

###### Local Template Files ######

data "template_file" "service1" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-non-sensitive-service-policy.json.tpl")
}

data "template_file" "service2" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-non-sensitive-service1-policy.json.tpl")
}

data "template_file" "user1" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-non-sensitive-user-policy.json.tpl")
}

data "template_file" "user2" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-non-sensitive-user1-policy.json.tpl")
}

data "template_file" "sagemakernotebook" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-non-sensitive-sagemakernotebook-policy.json.tpl")
}
###### Creating IAM Policy ######

module "user1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-user-policy"

  policy = data.template_file.user1.rendered
}

module "user2" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-user1-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-user1-policy"

  policy = data.template_file.user2.rendered
}

module "service1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-service-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-service-policy"

  policy = data.template_file.service1.rendered
}

module "service2" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-service1-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-service1-policy"

  policy = data.template_file.service2.rendered
}

module "sagemakernotebook" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-sagemakernotebook-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-sagemakernotebook-policy"

  policy = data.template_file.sagemakernotebook.rendered
}

###### Login Role-1 ######

module "hc-ai-contract-digit-non-sensitive-user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-ai-contract-digit-non-sensitive-user"
  role_description      = "hc-ai-contract-digit-non-sensitive-user"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-aiml-exp-stg-cntrt-dgt-sntv_1f8d8d8659d62932"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
}

###### Service Role-1 ######

resource "aws_iam_role" "servicerole1" {
  name        = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-service-role"
  description = "odp-us-aiml-exp-dev-contract-digit-non-sensitive-service-role"

  assume_role_policy    = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": [
                    "s3.amazonaws.com",
                    "secretsmanager.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "events.amazonaws.com",
                    "states.amazonaws.com",
                    "logs.amazonaws.com",
                    "ecs.amazonaws.com",
                    "ecr.amazonaws.com",
                    "lambda.amazonaws.com",
                    "bedrock.amazonaws.com",
                    "sagemaker.amazonaws.com"
                ]
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags            = var.tags
}

###### Attaching Policies to Login Role ######

resource "aws_iam_role_policy_attachment" "user7" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user8" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user9" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy" 
}

  resource "aws_iam_role_policy_attachment" "user10" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = module.user1.arn
}

resource "aws_iam_role_policy_attachment" "user30" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = module.user2.arn
}

resource "aws_iam_role_policy_attachment" "user11" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
} 

resource "aws_iam_role_policy_attachment" "user12" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = module.user-model.arn
} 

resource "aws_iam_role_policy_attachment" "user16" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = module.sagemakernotebook.arn
} 

resource "aws_iam_role_policy_attachment" "user17" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-root-internet-access-policy" 
}

resource "aws_iam_role_policy_attachment" "user18" {
  role       = module.hc-ai-contract-digit-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-sagemaker-deny-instance-type-policy" 
}
 
###### Attaching Policies to Service Role ######

resource "aws_iam_role_policy_attachment" "service6" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service7" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service8" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  module.service.arn
}

resource "aws_iam_role_policy_attachment" "service20" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  module.service2.arn
}

resource "aws_iam_role_policy_attachment" "service9" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  module.service-model.arn
}

resource "aws_iam_role_policy_attachment" "service13" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  module.sagemakernotebook.arn
}

resource "aws_iam_role_policy_attachment" "service14" {
  role       = aws_iam_role.servicerole1.name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-root-internet-access-policy" 
}

resource "aws_iam_role_policy_attachment" "service15" {
  role       = aws_iam_role.servicerole1.name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-sagemaker-deny-instance-type-policy" 
}

resource "aws_iam_role_policy_attachment" "service17" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  module.service1.arn
}