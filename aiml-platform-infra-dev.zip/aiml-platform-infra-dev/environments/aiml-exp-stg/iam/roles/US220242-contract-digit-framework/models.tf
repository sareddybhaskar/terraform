##############Bedrock Models ##############

data "template_file" "user-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-user-model-policy.json.tpl")

  vars = {
    claude_4_5_haiku_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model2.arn
    claude_4_5_sonnet_arn = aws_bedrock_inference_profile.model3.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model4.arn
    nova_pro_arn = aws_bedrock_inference_profile.model5.arn
    titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model6.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model7.arn
    titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model8.arn
    nova_multimodal_embeddings_arn = aws_bedrock_inference_profile.model9.arn
  }
}

# service model policy template
data "template_file" "service-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-dev-contract-digit-service-model-policy.json.tpl")

  vars = {
    claude_4_5_haiku_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model2.arn
    claude_4_5_sonnet_arn = aws_bedrock_inference_profile.model3.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model4.arn
    nova_pro_arn = aws_bedrock_inference_profile.model5.arn
    titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model6.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model7.arn
    titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model8.arn
    nova_multimodal_embeddings_arn = aws_bedrock_inference_profile.model9.arn
  }
}

module "user-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-user-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-user-model-policy"

  policy = data.template_file.user-model-policy.rendered
}

module "service-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-dev-contract-digit-service-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-dev-contract-digit-service-model-policy"

  policy = data.template_file.service-model-policy.rendered
}

###### Bedrock Instance Profile ######
resource "aws_bedrock_inference_profile" "model1" {
  name        = "contract-digit-claude-4-5-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-claude-4-5-haiku"
    }
  )
}

resource "aws_bedrock_inference_profile" "model2" {
  name        = "contract-digit-claude-3-5-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-claude-3-5-haiku"
    }
  )
}

resource "aws_bedrock_inference_profile" "model3" {
  name        = "contract-digit-claude-4-5-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-5-20250929-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-claude-4-5-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model4" {
  name        = "contract-digit-claude-3-7-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-claude-3-7-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model5" {
  name        = "contract-digit-nova-pro"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-nova-pro"
    }
  )
}

resource "aws_bedrock_inference_profile" "model6" {
  name        = "contract-digit-titan-embeddings-g1-text"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v1"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-titan-embeddings-g1-text"
    }
  )
}

resource "aws_bedrock_inference_profile" "model7" {
  name        = "contract-digit-titan-text-embeddings-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-titan-text-embeddings-v2"
    }
  )
}

resource "aws_bedrock_inference_profile" "model8" {
  name        = "contract-digit-ttitan-multimodal-embeddings-g1"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-image-v1"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-ttitan-multimodal-embeddings-g1"
    }
  )
}

resource "aws_bedrock_inference_profile" "model9" {
  name        = "contract-digit-nova-multimodal-embeddings"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-2-multimodal-embeddings-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-nova-multimodal-embeddings"
    }
  )
}