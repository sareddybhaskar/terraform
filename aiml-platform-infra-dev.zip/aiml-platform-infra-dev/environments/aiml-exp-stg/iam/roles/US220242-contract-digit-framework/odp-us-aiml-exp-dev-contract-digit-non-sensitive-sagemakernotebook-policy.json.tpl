{
    "Statement": [
        {
            "Action": [
                "ec2:RevokeSecurityGroupIngress",
                "ec2:AuthorizeSecurityGroupEgress",
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:CreateNetworkInterfacePermission",
                "ec2:DescribeVpcEndpoints",
                "ec2:DescribeDhcpOptions",
                "ec2:CreateNetworkInterfacePermission",
                "ec2:RevokeSecurityGroupEgress",
                "ec2:DeleteSecurityGroup"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor0"
        },
        {
            "Action": "ec2:CreateTags",
            "Effect": "Allow",
            "Resource": [
                "arn:aws:ec2:*:*:security-group/*",
                "arn:aws:ec2:*:*:network-interface/*"
            ],
            "Sid": "VisualEditor1"
        },
        {
            "Action": "elasticfilesystem:CreateFileSystem",
            "Condition": {
                "StringLike": {
                    "aws:RequestTag/ManagedByAmazonSageMakerResource": "*"
                }
            },
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor2"
        },
        {
            "Action": [
                "elasticfilesystem:CreateMountTarget",
                "elasticfilesystem:DeleteMountTarget",
                "elasticfilesystem:DeleteFileSystem"
            ],
            "Condition": {
                "StringLike": {
                    "aws:ResourceTag/ManagedByAmazonSageMakerResource": "*"
                }
            },
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor3"
        },
        {
            "Action": [
                "ec2:CreateNetworkInterface",
                "elasticfilesystem:DescribeMountTargets",
                "sagemaker:CreateUserProfile",
                "ec2:DescribeNetworkInterfaces",
                "ec2:DescribeVpcs",
                "ec2:CreateSecurityGroup",
                "ec2:ModifyNetworkInterfaceAttribute",
                "ec2:DeleteNetworkInterface",
                "elasticfilesystem:DescribeFileSystems",
                "ec2:DescribeSubnets",
                "ec2:DescribeSecurityGroups",
                "sagemaker:DescribeUserProfile"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor4"
        },
        {
            "Action": [
                "budgets:ViewBudget",
                "trustedadvisor:DescribeAccount",
                "trustedadvisor:ListOrganizationalUnitsForParent",
                "budgets:DescribeBudgetActionHistories",
                "trustedadvisor:DescribeAccountAccess",
                "aws-portal:ViewUsage",
                "ce:GetReservationPurchaseRecommendation",
                "aws-portal:ViewPaymentMethods",
                "ce:GetSavingsPlansPurchaseRecommendation",
                "ce:GetSavingsPlansUtilizationDetails",
                "ce:GetAnomalySubscriptions",
                "ce:CreateCostCategoryDefinition",
                "aws-portal:ViewBilling",
                "trustedadvisor:DescribeChecks",
                "ce:GetReservationCoverage",
                "ce:GetAnomalyMonitors",
                "trustedadvisor:DescribeNotificationPreferences",
                "ce:GetUsageForecast",
                "ce:DescribeCostCategoryDefinition",
                "trustedadvisor:DescribeServiceMetadata",
                "ce:CreateNotificationSubscription",
                "trustedadvisor:DescribeOrganizationAccounts",
                "ce:GetAnomalies",
                "ce:CreateAnomalySubscription",
                "ce:ListCostCategoryDefinitions",
                "trustedadvisor:ListAccountsForParent",
                "ce:GetCostForecast",
                "trustedadvisor:DescribeCheckSummaries",
                "cur:DescribeReportDefinitions",
                "budgets:DescribeBudgetActionsForBudget",
                "ce:GetCostAndUsage",
                "ce:GetPreferences",
                "ce:GetReservationUtilization",
                "ce:GetCostCategories",
                "ce:GetDimensionValues",
                "ce:DescribeReport",
                "trustedadvisor:ListRoots",
                "trustedadvisor:DescribeReports",
                "ce:CreateAnomalyMonitor",
                "ce:CreateReport",
                "ce:DescribeNotificationSubscription",
                "trustedadvisor:DescribeCheckRefreshStatuses",
                "ce:GetRightsizingRecommendation",
                "budgets:DescribeBudgetAction",
                "aws-portal:ViewAccount",
                "ce:GetSavingsPlansUtilization",
                "trustedadvisor:DescribeCheckItems",
                "support:*",
                "trustedadvisor:DescribeOrganization",
                "ce:GetCostAndUsageWithResources",
                "budgets:DescribeBudgetActionsForAccount",
                "ce:GetSavingsPlansCoverage",
                "ce:GetTags",
                "sagemaker:List*"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor11"
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:AddTags",
                "sagemaker:BatchPutMetrics",
                "sagemaker:CreateAlgorithm",
                "sagemaker:CreateApp",
                "sagemaker:CreateAutoMLJob",
                "sagemaker:CreateCodeRepository",
                "sagemaker:CreateCompilationJob",
                "sagemaker:CreateDomain",
                "sagemaker:CreateEndpoint",
                "sagemaker:CreateEndpointConfig",
                "sagemaker:CreateExperiment",
                "sagemaker:CreateFlowDefinition",
                "sagemaker:CreateHumanTaskUi",
                "sagemaker:CreateHyperParameterTuningJob",
                "sagemaker:CreateLabelingJob",
                "sagemaker:CreateModel",
                "sagemaker:CreateModelPackage",
                "sagemaker:CreateMonitoringSchedule",
                "sagemaker:CreateNotebookInstance",
                "sagemaker:CreateNotebookInstanceLifecycleConfig",
                "sagemaker:CreatePresignedDomainUrl",
                "sagemaker:CreatePresignedNotebookInstanceUrl",
                "sagemaker:CreateProcessingJob",
                "sagemaker:CreateTrainingJob",
                "sagemaker:CreateTransformJob",
                "sagemaker:CreateTrial",
                "sagemaker:CreateTrialComponent",
                "sagemaker:CreateUserProfile",
                "sagemaker:CreateWorkforce",
                "sagemaker:CreateWorkteam",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:StartHumanLoop",
                "sagemaker:StartMonitoringSchedule",
                "sagemaker:StartNotebookInstance",
                "sagemaker:StopAutoMLJob",
                "sagemaker:StopCompilationJob",
                "sagemaker:StopHumanLoop",
                "sagemaker:StopHyperParameterTuningJob",
                "sagemaker:StopLabelingJob",
                "sagemaker:StopMonitoringSchedule",
                "sagemaker:StopNotebookInstance",
                "sagemaker:StopProcessingJob",
                "sagemaker:StopTrainingJob",
                "sagemaker:StopTransformJob",
                "sagemaker:UpdateCodeRepository",
                "sagemaker:UpdateDomain",
                "sagemaker:UpdateEndpoint",
                "sagemaker:UpdateEndpointWeightsAndCapacities",
                "sagemaker:UpdateExperiment",
                "sagemaker:UpdateMonitoringSchedule",
                "sagemaker:UpdateNotebookInstance",
                "sagemaker:UpdateNotebookInstanceLifecycleConfig",
                "sagemaker:UpdateTrial",
                "sagemaker:UpdateTrialComponent",
                "sagemaker:UpdateUserProfile",
                "sagemaker:UpdateWorkforce",
                "sagemaker:UpdateWorkteam",
                "sagemaker:DeleteTags",
                "sagemaker:DescribeProcessingJob",
                "sagemaker:DeleteModel"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:us-east-1:991497151145:app/*/*/*",
                "arn:aws:sagemaker:us-east-1:991497151145:space/*/*",
                "arn:aws:sagemaker:us-east-1:991497151145:processing-job/*",
                "arn:aws:sagemaker:us-east-1:991497151145:training-job/*",
                "arn:aws:sagemaker:us-east-1:991497151145:notebook-instance/*"
            ],
            "Sid": "SagemakerActions"
        },
        {
            "Action": "iam:PassRole",
            "Condition": {
                "StringEquals": {
                    "iam:PassedToService": "sagemaker.amazonaws.com"
                }
            },
            "Effect": "Allow",
            "Resource": 
                  [

                  "arn:aws:iam::991497151145:role/odp-us-aiml-exp-dev-contract-digit-non-sensitive-service-role"                  
                  ],
            "Sid": "Passtosagemakerservice"
        }
    ],
    "Version": "2012-10-17"
}