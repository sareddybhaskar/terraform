{
    "Statement": [
        {
			"Sid": "S3Vector",
			"Effect": "Allow",
			"Action": [
				"s3vectors:CreateIndex",
				"s3vectors:PutVectors",
				"s3vectors:ListTagsForResource",
				"s3vectors:ListVectors",
				"s3vectors:ListIndexes",
				"s3vectors:GetIndex",
				"s3vectors:GetVectorBucket",
				"s3vectors:GetVectors",
				"s3vectors:GetVectorBucketPolicy",
				"s3vectors:QueryVectors"
			],
			"Resource": [
				"arn:aws:s3vectors:*:*:bucket/odp-us-aiml-dev-contract-digit-service-vector/index/$${aws:PrincipalTag/ApplicationTag}*",
				"arn:aws:s3vectors:*:*:bucket/odp-us-aiml-dev-contract-digit-service-vector"
			]
		},
		{
            "Action": [
                "bedrock:List*",
                "bedrock:Get*",
                "bedrock:InvokeAgent",
                "bedrock:CallWithBearerToken",
                "bedrock:InvokeInlineAgent",
                "bedrock:OptimizePrompt",
                "bedrock:RetrieveAndGenerate",
                "bedrock:ValidateFlowDefinition",
                "bedrock:GenerateQuery",
                "bedrock:CreateFlow",
                "bedrock:CreateAgent",
                "bedrock:CreatePrompt",
                "bedrock:CreateKnowledgeBase"
            ],
            "Effect": "Allow",
            "Resource": "*"
        }   
    ],
    "Version": "2012-10-17"
}