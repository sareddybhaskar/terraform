{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/f8pvjxwr2j2t",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/k214gtjgqqeh",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/t2afvtuolbuo",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/wsv3b98mdnae",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/ocfxrrp4a905",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/snjupx4fwo1q",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/tfvqxo578e1k",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/lurscghi4mwa",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/xt05usxk00cd"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/f8pvjxwr2j2t",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/k214gtjgqqeh",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/t2afvtuolbuo",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/wsv3b98mdnae",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/ocfxrrp4a905",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/snjupx4fwo1q",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/tfvqxo578e1k",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/lurscghi4mwa",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/xt05usxk00cd"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-4-5-sonnet-20250219-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-4-5-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/f8pvjxwr2j2t",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/k214gtjgqqeh",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/t2afvtuolbuo",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/wsv3b98mdnae",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/ocfxrrp4a905",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/snjupx4fwo1q",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/tfvqxo578e1k",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/lurscghi4mwa",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/xt05usxk00cd"
            ]
        }
    ],
    "Version": "2012-10-17"
}