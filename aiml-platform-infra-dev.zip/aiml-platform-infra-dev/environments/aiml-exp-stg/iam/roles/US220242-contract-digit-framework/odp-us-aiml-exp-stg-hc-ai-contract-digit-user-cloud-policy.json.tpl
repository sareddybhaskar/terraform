{
    "Statement": [
        {
            "Action": "sts:AssumeRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::991497151145:role/hc-ai-contract-digit-user",
            "Sid": "assumerole"
        }
    ],
    "Version": "2012-10-17"
}