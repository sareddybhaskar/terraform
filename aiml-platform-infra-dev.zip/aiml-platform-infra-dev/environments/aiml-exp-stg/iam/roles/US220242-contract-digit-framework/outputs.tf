output "login-role" {
  value = module.hc-ai-contract-digit-user.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}
output "login-role1" {
  value = module.hc-ai-contract-digit-non-sensitive-user.role_name
}

output "service-role1" {
  value = aws_iam_role.servicerole1.name
}

output "all-model-arns" {
  value = {
    "claude-4-5-haiku"  = aws_bedrock_inference_profile.model1.arn
    "claude-3-5-haiku"  = aws_bedrock_inference_profile.model2.arn
    "claude-4-5-sonnet" = aws_bedrock_inference_profile.model3.arn
    "claude-3-7-sonnet" = aws_bedrock_inference_profile.model4.arn
    "nova-pro"          = aws_bedrock_inference_profile.model5.arn
    "titan-embeddings-g1-text" =   aws_bedrock_inference_profile.model6.arn
    "titan-text-embeddings-v2" =       aws_bedrock_inference_profile.model7.arn
    "titan-multimodal-embeddings-g1" = aws_bedrock_inference_profile.model8.arn
    "nova-multimodal-embeddings" =     aws_bedrock_inference_profile.model9.arn
   }
}

output "all-model-arns-list" {
  value = [
    aws_bedrock_inference_profile.model1.arn,
    aws_bedrock_inference_profile.model2.arn,
    aws_bedrock_inference_profile.model3.arn,
    aws_bedrock_inference_profile.model4.arn,
    aws_bedrock_inference_profile.model5.arn,
    aws_bedrock_inference_profile.model6.arn,
    aws_bedrock_inference_profile.model7.arn,
    aws_bedrock_inference_profile.model8.arn,
    aws_bedrock_inference_profile.model9.arn


  ]
}