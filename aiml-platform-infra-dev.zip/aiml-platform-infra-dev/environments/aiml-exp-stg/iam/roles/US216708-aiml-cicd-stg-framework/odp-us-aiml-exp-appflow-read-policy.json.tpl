{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "read",
            "Effect": "Allow",
            "Action": [
                "appflow:List*",
                "appflow:Describe*",
                "cloudwatch:Describe*",
                "cloudwatch:Get*",
                "cloudwatch:List*",
                "ecr:Describe*",
                "ecr:Get*",
                "ecr:List*",
                "ec2:Describe*",
                "events:Describe*",
                "events:List*",
                "kms:Describe*",
                "kms:Get*",
                "kms:List*",
                "iam:List*",
                "iam:Get*",
                "lambda:List*",
                "lambda:Get*",
                "logs:Describe*",
                "logs:Get*",
                "logs:List*",
                "sagemaker:Describe*",
                "sagemaker:Get*",
                "sagemaker:List*",
                "sagemaker:InvokeEndpoint",
                "sagemaker:Search",
                "sns:Get*",
                "sns:List*",
                "states:Describe*",
                "states:Get*",
                "states:List*",
                "secretsmanager:List*",
                "secretsmanager:Describe*",
                "s3:ListAllMyBuckets",
                "s3:GetBucketLocation",
                "tag:GetResources"
            ],
            "Resource": "*"
        }
    ]
}