{
    "Statement": [        
        {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:PutMetricData",
            "cloudwatch:GetMetricData",
            "cloudwatch:PutAnomalyDetector",
            "cloudwatch:GetMetricStatistics",
            "cloudwatch:GetMetricWidgetImage",
            "cloudwatch:PutManagedInsightRules"
        ],
         "Resource": "*"
        },
       {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:Put*",            
            "cloudwatch:TagResource",            
            "cloudwatch:GetDashboard",
            "cloudwatch:EnableAlarmActions",
            "cloudwatch:StopMetricStreams",
            "cloudwatch:GetInsightRuleReport",
            "cloudwatch:SetAlarmState",
            "cloudwatch:EnableInsightRules",
            "cloudwatch:StartMetricStreams"
        ],
         "Resource": [
            "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:insight-rule/*",
            "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
         ]
       },       
        {
            "Effect": "Allow",
            "Action": [
                "logs:Put*",
                "logs:Get*",
		        "logs:Describe*",
		        "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",				
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"				
            ],
            "Resource": [
		        "*"
            ]
        },
        {
            "Action": [
                "events:PutPartnerEvents",
                "events:PutPermission"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:DisableRule"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:events:*:*:rule/$${aws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:ActivateEventSource",
                "events:DisableRule"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:events:*:*:rule/$${aws:PrincipalTag/ApplicationTag}*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:archive/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:connection/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:event-bus/default",
                "arn:aws:events:*:*:api-destination/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:endpoint/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*::event-source/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject"                
            ],
            "Effect": "Allow",
            "Resource": [               
                "arn:aws:s3:::odp-us-aiml-exp-stg-aiml-cicd",
                "arn:aws:s3:::odp-us-aiml-exp-stg-aiml-cicd/*"
            ]
        },
                {
            "Action": [
                "sqs:Get*",
                "sqs:List*",
                "sqs:ChangeMessageVisibility",
                "sqs:PurgeQueue",
                "sqs:ReceiveMessage",
                "sqs:SendMessage",
                "sqs:CreateQueue",
                "sqs:SetQueueAttributes"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:sqs:*:*:$${aws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Action": [
                "opensearch:Get*",
                "opensearch:ApplicationAccessAll",
                "opensearch:StartDirectQuery"
            ],
            "Effect": "Allow",
            "Resource": [ "arn:aws:opensearch:*:*:application/$${aws:PrincipalTag/ApplicationTag}*", 
                            "arn:aws:opensearch:*:*:datasource/$${aws:PrincipalTag/ApplicationTag}*"
                        ]
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:InvokeEndpoint",
                "sagemaker:Describe*",
                "sagemaker:List*",
                "sagemaker:Search",
                "sagemaker:AddTags"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*"
            ]
        },
                {
            "Action": [
                "bedrock:Create*",
                "bedrock:Invoke*",
                "bedrock:Get*",
                "bedrock:List*",
                 "bedrock:Stop*",
                "bedrock:Start*",
                "bedrock:Update*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "states:StopExecution",
                "states:StartSyncExecution",
                "states:Describe*",
                "states:SendTaskSuccess",
                "states:SendTaskFailure",
                "states:List*",
                "states:GetExecutionHistory",
                "states:StartExecution",
                "states:SendTaskHeartbeat",
                "states:GetActivityTask"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:states:*:*:activity:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:states:*:*:execution:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:states:*:*:stateMachine:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "sns:ConfirmSubscription",
                "sns:GetTopicAttributes",
                "sns:Publish",
                "sns:SetTopicAttributes",
                "sns:SetSubscriptionAttributes",
                "sns:Subscribe",
                "sns:TagResource",
                "sns:Unsubscribe"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sns:*:*:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "glue:StartJobRun",
                "glue:BatchStopJobRun"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:glue:*:*:job/$${aws:PrincipalTag/ApplicationTag}*",
            "Sid": "VisualEditor0"
        },
        {
            "Action": [
                "glue:ResetJobBookmark",
                "glue:StartCrawlerSchedule",
                "glue:StopCrawlerSchedule"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor1"
        },
        {
            "Action": [
                "glue:SearchTables",
                "glue:GetDatabase",
                "glue:GetTables",
                "glue:GetDatabases",
                "glue:GetTable",
                "glue:GetPartitions",
                "glue:GetPartition"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:glue:*:*:database/aiml-cicd",
                "arn:aws:glue:*:*:table/aiml-cicd/*",
                "arn:aws:glue:*:*:catalog"
            ]
        },
        {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        }       
    ],
    "Version": "2012-10-17"
}