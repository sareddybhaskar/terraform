provider "aws" {
  version = ">= 3.0, < 4.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/iam/roles/US216708-aiml-cicd-stg-framework/terraform.tfstate"
    region = "us-east-1"
  }
}



############Cloud Ploicy############

data "template_file" "user-reservered-cloud-template" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-aiml-cicd-user-cloud-policy.json.tpl")
}

module "user-reservered-cloud-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-aiml-cicd-user-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-aiml-cicd-user-cloud-policy"

  policy = data.template_file.user-reservered-cloud-template.rendered
}


data "template_file" "user-reservered-template" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-aiml-cicd-user-policy.json.tpl")
}

module "user-reservered-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-aiml-cicd-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-aiml-cicd-user-policy"

  policy = data.template_file.user-reservered-template.rendered
}

###### Local Template Files ######

data "template_file" "user" {
  template = file("${path.module}/odp-us-aiml-exp-aiml-cicd-user-policy.json.tpl")
}

data "template_file" "user1" {
  template = file("${path.module}/odp-us-aiml-exp-aiml-cicd-user1-policy.json.tpl")
}
data "template_file" "appflow" {
  template = file("${path.module}/odp-us-aiml-exp-appflow-read-policy.json.tpl")
}


###### Creating IAM Policy ######

module "user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-aiml-cicd-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-aiml-cicd-user-policy"

  policy = data.template_file.user.rendered
}

module "user1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-aiml-cicd-user1-policy"
  path        = "/"
  description = "odp-us-aiml-exp-aiml-cicd-user1-policy"

  policy = data.template_file.user1.rendered
}

module "appflow" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-appflow-read-policy"
  path        = "/"
  description = "odp-us-aiml-exp-appflow-read-policy"

  policy = data.template_file.appflow.rendered
}


###### Login Role ######

module "hc-aiml-cicd-user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-aiml-cicd-user"
  role_description      = "hc-aiml-cicd-user"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-uaiml-exp-stg-aiml-cicd-user_55176444a38d020c"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
}



###### Attaching Policies to user Role ######

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-aiml-cicd-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-aiml-cicd-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.hc-aiml-cicd-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy" 
  }

  resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.hc-aiml-cicd-user.role_name
  policy_arn = module.user.arn
}

resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.hc-aiml-cicd-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
} 

resource "aws_iam_role_policy_attachment" "user6" {
  role       = module.hc-aiml-cicd-user.role_name
  policy_arn = module.appflow.arn
} 
 
resource "aws_iam_role_policy_attachment" "user7" {
  role       = module.hc-aiml-cicd-user.role_name
  policy_arn = module.user1.arn
} 



