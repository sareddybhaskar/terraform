{
    "Statement": [        
        {
            "Action": [
                "redshift-data:ListTables",
                "redshift-data:DescribeTable",
                "redshift-data:BatchExecuteStatement",
                "redshift-data:ListSchemas",
                "redshift-data:ExecuteStatement",
                "redshift-data:ListDatabases",
                "redshift-data:GetStatementResult",
                "redshift-data:CancelStatement",
                "redshift-data:DescribeStatement",
                "redshift-data:ListStatements"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "lambda:PublishLayerVersion",
                "lambda:InvokeAsync",
                "lambda:PutFunctionConcurrency",
                "lambda:EnableReplication",
                "lambda:DisableReplication",
                "lambda:PutFunctionEventInvokeConfig",
                "lambda:InvokeFunction",
                "lambda:AddLayerVersionPermission",
                "lambda:AddPermission",
                "lambda:PutProvisionedConcurrencyConfig",
                "lambda:PublishVersion",
                "lambda:RemovePermission"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:lambda:*:*:event-source-mapping:*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "dynamodb:BatchGetItem",
                "dynamodb:ConditionCheckItem",
                "dynamodb:PutItem",
                "dynamodb:Scan",
                "dynamodb:Query",
                "dynamodb:UpdateItem",
                "dynamodb:BatchWriteItem",
                "dynamodb:PartiQLSelect",
                "dynamodb:PartiQLUpdate",
                "dynamodb:PartiQLInsert",
                "dynamodb:ImportTable"
            ],
            "Resource": [
                "arn:aws:dynamodb:*:*:table/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:dynamodb:*:*:table/$${aws:PrincipalTag/ApplicationTag}*/index/*"
            ]
        },
        {
            "Sid": "ECRActions",
            "Effect": "Allow",
            "Action": [
                "ecr:BatchCheckLayerAvailability",
                "ecr:BatchGetImage",
                "ecr:CompleteLayerUpload",
                "ecr:CreateRepository",
                "ecr:GetAuthorizationToken",
                "ecr:GetDownloadUrlForLayer",
                "ecr:GetLifecyclePolicy",
                "ecr:GetLifecyclePolicyPreview",
                "ecr:GetRepositoryPolicy",
                "ecr:InitiateLayerUpload",
                "ecr:PutImage",
                "ecr:PutImageScanningConfiguration",
                "ecr:PutImageTagMutability",
                "ecr:PutLifecyclePolicy",
                "ecr:StartImageScan",
                "ecr:StartLifecyclePolicyPreview",
                "ecr:TagResource",
                "ecr:UploadLayerPart",
                "ecr:DeleteRepository"
            ],
            "Resource": [
                "arn:aws:ecr:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecr:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
		{
            "Effect": "Allow",
            "Action": [
				"rds:Describe*",
				"rds:List*"
            ],
            "Resource": "*"
        },
		{
            "Sid": "es",
            "Effect": "Allow",
            "Action": [
                "es:Describe*",
                "es:ESHttpGet",
                "es:ESHttpHead",
                "es:ESHttpPost",
                "es:Get*",
                "es:List*"
            ],
            "Resource": [
                "arn:aws:es:us-east-1:991497151145:domain/odp-us-aiml-exp-stg-aiml-cicd"
            ]
        },
        {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        }    
    ],
    "Version": "2012-10-17"
}