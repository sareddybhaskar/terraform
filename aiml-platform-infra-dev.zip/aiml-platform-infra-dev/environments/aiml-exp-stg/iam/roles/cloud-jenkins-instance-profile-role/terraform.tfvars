# name = "odp-us-prod"
region      = "us-east-1"
environment = "aiml-exp-stg"


tags = {
  Project     = "odp"
  App         = "cloud-ops"
  Environment = "stg"
  ManagedBy   = "Terraform"
  Automation  = "Jenkins"
  uai         = "UAI3053026"
  Patch       = "Enable"
  Program     = "ODP"
  Role        = "dt-dna"
  DLM         = "Enable"
  purpose     = "run"
}


