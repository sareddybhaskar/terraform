{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "SourceBucketAccess",
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket",
                "s3:GetObject"
            ],
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-exp-stg*",
                "arn:aws:s3:::odp-us-aiml-exp-stg*/*"
            ]
        },
        {
            "Sid": "DestinationBucketAccess",
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket",
                "s3:PutObject",
                "s3:PutObjectAcl"
            ],
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-prod*",
                "arn:aws:s3:::odp-us-aiml-prod*/*"
            ]
        }
    ]
}