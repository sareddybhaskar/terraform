output "role" {
  value = aws_iam_role.servicerole.name
}

