provider "aws" {
  version = ">= 3.0, < 4.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/iam/roles/cloud-jenkins-instance-profile-role/terraform.tfstate"
    region = "us-east-1"
  }
}

data "template_file" "s3addon" {
  template = file("${path.module}/odp-us-aiml-exp-stg-s3-addon-policy.json.tpl")
}

data "template_file" "usprod" {
  template = file("${path.module}/odp-us-prod-bucket-policy.json.tpl")
}

module "s3addon" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-s3-addon-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-s3-addon-policy"

  policy = data.template_file.s3addon.rendered
}

module "usprod" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-prod-bucket-policy"
  path        = "/"
  description = "odp-us-prod-bucket-policy"

  policy = data.template_file.usprod.rendered
}


######  Role ######

resource "aws_iam_role" "servicerole" {
  name        = "odp-us-aiml-exp-stg-cloud-jenkins-instance-role"
  description = "odp-us-aiml-exp-stg-cloud-jenkins-instance-role"

  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "ec2.amazonaws.com",
                "AWS": [
                    "arn:aws:iam::245792935030:root",
                    "arn:aws:iam::245792935030:role/instance-role/odp-us-prod-jenkins-app-instance-role-a93d6e4656c88322"
                ]
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags               = var.tags
}


resource "aws_iam_instance_profile" "cloud-jenkins-instance-profile" {
  name = "cloud-jenkins-instance-profile"
  role = aws_iam_role.servicerole.name
}


resource "aws_iam_role_policy_attachment" "service1" {
  role       = aws_iam_role.servicerole.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonEC2RoleforSSM"
}

resource "aws_iam_role_policy_attachment" "service2" {
  role       = aws_iam_role.servicerole.name
  policy_arn = "arn:aws:iam::aws:policy/IAMFullAccess"
}
resource "aws_iam_role_policy_attachment" "service3" {
  role       = aws_iam_role.servicerole.name
  policy_arn = "arn:aws:iam::aws:policy/PowerUserAccess"
}
resource "aws_iam_role_policy_attachment" "service4" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.s3addon.arn
}
resource "aws_iam_role_policy_attachment" "service5" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.usprod.arn
}