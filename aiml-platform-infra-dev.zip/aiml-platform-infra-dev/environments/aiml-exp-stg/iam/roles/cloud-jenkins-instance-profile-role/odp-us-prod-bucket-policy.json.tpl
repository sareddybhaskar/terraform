{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "UsProdPlatformS3Bucket",
            "Effect": "Allow",
            "Action": "s3:*",
            "Resource": [
                "arn:aws:s3:::odp-us-prod-platform",
                "arn:aws:s3:::odp-us-prod-platform/*"
            ]
        }
    ]
}