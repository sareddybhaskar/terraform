provider "aws" {
  #version = ">= 3.0, < 4.0"
  #version = "~> 5.0"
  version = "6.2.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg/iam/US220322-aiml-mlops-sagemaker-policy/terraform.tfstate"
    region = "us-east-1"
  }
}



############Cloud Ploicy############

data "template_file" "sagemakernotebook-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-aiml-mlops-sagemakernotebook-policy.json.tpl")
}

data "template_file" "deny-root-internet" {
  template = file("${path.module}/odp-us-aiml-exp-stg-common-deny-root-internet-access-policy.json.tpl")
}


data "template_file" "sagemaker-deny-instance" {
  template = file("${path.module}/odp-us-aiml-exp-stg-sagemaker-deny-instance-type-policy.json.tpl")
}

module "sagemakernotebook-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-aiml-mlops-sagemakernotebook-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-aiml-mlops-sagemakernotebook-policy"

  policy = data.template_file.sagemakernotebook-policy.rendered
}

module "deny-root-internet" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-common-deny-root-internet-access-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-common-deny-root-internet-access-policy"
  policy = data.template_file.deny-root-internet.rendered
}

module "sagemaker-deny-instance" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-sagemaker-deny-instance-type-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-sagemaker-deny-instance-type-policy"

  policy = data.template_file.sagemaker-deny-instance.rendered
}
