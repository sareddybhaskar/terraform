{
    "Statement": [
        {
            "Action": [
                "sagemaker:CreateNotebookInstance",
                "sagemaker:UpdateNotebookInstance"
            ],
            "Condition": {
                "StringEquals": {
                    "sagemaker:RootAccess": "Enabled"
                }
            },
            "Effect": "Deny",
            "Resource": "*",
            "Sid": "SageMakerDenyRootAccess"
        },
        {
            "Action": "sagemaker:CreateNotebookInstance",
            "Condition": {
                "StringEquals": {
                    "sagemaker:DirectInternetAccess": [
                        "Enabled"
                    ]
                }
            },
            "Effect": "Deny",
            "Resource": "*",
            "Sid": "SageMakerPreventDirectInternet"
        },
        {
            "Action": "sagemaker:CreateNotebookInstance",
            "Condition": {
                "Null": {
                    "sagemaker:VpcSecurityGroupIds": "true",
                    "sagemaker:VpcSubnets": "true"
                }
            },
            "Effect": "Deny",
            "Resource": "*",
            "Sid": "SageMakerDenyIfNoNetwork"
        },
        {
            "Action": [
                "sagemaker:CreatePresignedNotebookInstanceUrl",
                "sagemaker:DescribeNotebookInstance"
            ],
            "Condition": {
                "ForAllValues:NotIpAddress": {
                    "aws:SourceIp": [
                        "34.98.0.0/16",
                        "34.100.0.0/16",
                        "34.103.0.0/16",
                        "66.159.0.0/16",
                        "114.141.0.0/16",
                        "128.77.0.0/16",
                        "130.41.0.0/16",
                        "134.238.0.0/16",
                        "137.83.0.0/16",
                        "140.209.0.0/16",
                        "165.1.0.0/16",
                        "165.85.0.0/16",
                        "165.156.0.0/16",
                        "208.127.0.0/16",
                        "136.226.0.0/16"
                    ]
                }
            },
            "Effect": "Deny",
            "Resource": "*",
            "Sid": "SageMakerDenyOtherThanGlobalProtectRanges"
        }
    ],
    "Version": "2012-10-17"
}