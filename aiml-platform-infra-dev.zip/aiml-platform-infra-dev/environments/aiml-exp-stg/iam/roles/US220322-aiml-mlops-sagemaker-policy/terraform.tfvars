region      = "us-east-1"
environment = "aiml-exp-stg"

  tags = {
    Program        = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-mlops"
    Project        = "aiml-mlops"
    Role           = "dt-aiml-mlops"
    ApplicationTag = "aiml-mlops"
    UserStory      = "US220322"
    project_number = "ID5990:PR17717"
    purpose        = "inv_2025"
    Owner = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact = "cdao_mlops_support@gehealthcare.com"
  }

