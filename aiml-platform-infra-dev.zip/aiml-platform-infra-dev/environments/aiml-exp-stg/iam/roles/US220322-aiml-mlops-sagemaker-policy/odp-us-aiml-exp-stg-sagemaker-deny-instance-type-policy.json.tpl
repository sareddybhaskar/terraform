{
    "Statement": [
        {
            "Action": [
                "sagemaker:CreateTrainingJob",
                "sagemaker:CreateProcessingJob",
                "sagemaker:CreateTransformJob",
                "sagemaker:UpdateTrainingJob"
            ],
            "Condition": {
                "ForAnyValue:StringLike": {
                    "sagemaker:InstanceTypes": [
                        "ml.m4*",
                        "ml.c5*",
                        "ml.c4*",
                        "ml.r5*",
                        "ml.p2*",
                        "ml.p3*",
                        "ml.r5*"
                    ]
                }
            },
            "Effect": "Deny",
            "Resource": "*",
            "Sid": "sagemakerother"
        },
        {
            "Action": [
                "sagemaker:UpdateNotebookInstance",
                "sagemaker:CreateNotebookInstance"
            ],
            "Condition": {
                "ForAnyValue:StringLike": {
                    "sagemaker:InstanceTypes": [
                        "ml.c4*",
                        "ml.p3*",
                        "ml.g4*",
                        "ml.c5.large",
                        "ml.c5.2xlarge",
                        "ml.c5.9xlarge",
                        "ml.c5.12xlarge",
                        "ml.c5.24xlarge",
                        "ml.c5d.xlarge",
                        "ml.c5d.2xlarge",
                        "ml.c5d.4xlarge",
                        "ml.c5d.9xlarge",
                        "ml.r5.large",
                        "ml.r5.xlarge",
                        "ml.r5.2xlarge",
                        "ml.r5.8xlarge",
                        "ml.r5.12xlarge",
                        "ml.r5.16xlarge",
                        "ml.r5.24xlarge",
                        "ml.r5.xlarge",
                        "ml.m5d*",
                        "ml.m6i*",
                        "ml.m7i*",
                        "m6id*",
                        "c5d*",
                        "c6i*",
                        "c6id*",
                        "c7i*",
                        "r6*",
                        "r6*",
                        "g5*",
                        "p2*",
                        "inf*",
                        "g6*",
                        "p4*",
                        "r5*"
                    ]
                }
            },
            "Effect": "Deny",
            "Resource": "*",
            "Sid": "sagemakernotebook"
        }
    ],
    "Version": "2012-10-17"
}