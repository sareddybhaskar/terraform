{
    "Statement": [
        {
            "Action": [
                "logs:Put*",
                "logs:Get*",
                "logs:Describe*",
                "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"
            ],
            "Effect": "Allow",
            "Resource": [
                "*"
            ]
        },
        {
            "Action": [
                "events:PutPartnerEvents",
                "events:RemovePermission",
                "events:PutPermission"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:events:*:*:rule/$${aws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:ActivateEventSource",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule",
                "events:DescribeRule"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:events:*:*:rule/*",
                "arn:aws:events:*:*:archive/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:connection/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:event-bus/default",
                "arn:aws:events:*:*:api-destination/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:endpoint/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*::event-source/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:rule/StepFunctionsGetEventsForStepFunctionsExecutionRule"
            ]
        },
        {
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricData",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutManagedInsightRules"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "cloudwatch:PutInsightRule",
                "cloudwatch:PutMetricAlarm",
                "cloudwatch:TagResource",
                "cloudwatch:PutDashboard",
                "cloudwatch:GetDashboard",
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:StopMetricStreams",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:SetAlarmState",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:StartMetricStreams"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": "cloudwatch:Put*",
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "states:List*",
                "states:Describe*",
                "states:CreateActivity",
                "states:UpdateStateMachine",
                "states:StopExecution",
                "states:StartSyncExecution",
                "states:SendTaskSuccess",
                "states:SendTaskFailure",
                "states:GetExecutionHistory",
                "states:StartExecution",
                "states:SendTaskHeartbeat",
                "states:GetActivityTask",
                "states:CreateStateMachine"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:states:*:*:activity:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:states:*:*:execution:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:states:*:*:stateMachine:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "sns:ConfirmSubscription",
                "sns:CreateTopic",
                "sns:GetTopicAttributes",
                "sns:Publish",
                "sns:SetTopicAttributes",
                "sns:SetSubscriptionAttributes",
                "sns:Subscribe",
                "sns:Unsubscribe"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sns:*:*:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": [
                "arn:aws:iam::*:role/odp-us-aiml-exp-stg-isc-inventory-service-role"
            ],
            "Sid": "Passrole"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-prod-isc-inv",
                "arn:aws:s3:::odp-us-prod-isc-inv/*"
            ]
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-exp-stg-isc-inventory",
                "arn:aws:s3:::odp-us-aiml-exp-stg-isc-inventory/*"
            ]
        },
        {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:InvokeEndpoint",
                "sagemaker:Describe*",
                "sagemaker:List*",
                "sagemaker:Search",
                "sagemaker:AddTags"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*"
            ]
        },
        {
            "Action": [
                "athena:TagResource",
                "athena:CreateDataCatalog",
                "athena:UpdateDataCatalog",
                "athena:GetTableMetadata",
                "athena:StartQueryExecution",
                "athena:GetQueryResultsStream",
                "athena:GetQueryResults",
                "athena:GetDatabase",
                "athena:GetDataCatalog",
                "athena:GetNamedQuery",
                "athena:ListTagsForResource",
                "athena:ListQueryExecutions",
                "athena:ListNamedQueries",
                "athena:GetWorkGroup",
                "athena:CreateNamedQuery",
                "athena:ListDatabases",
                "athena:StopQueryExecution",
                "athena:GetQueryExecution",
                "athena:BatchGetNamedQuery",
                "athena:ListTableMetadata",
                "athena:BatchGetQueryExecution"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:athena:us-east-1:*:workgroup/*",
                "arn:aws:athena:*:*:datacatalog/*"
            ]
        }
    ],
    "Version": "2012-10-17"
}