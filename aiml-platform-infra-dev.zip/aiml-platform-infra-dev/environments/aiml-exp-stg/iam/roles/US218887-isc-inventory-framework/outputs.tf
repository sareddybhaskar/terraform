output "login-role" {
  value = module.hc-ai-isc-inventory-user.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}

