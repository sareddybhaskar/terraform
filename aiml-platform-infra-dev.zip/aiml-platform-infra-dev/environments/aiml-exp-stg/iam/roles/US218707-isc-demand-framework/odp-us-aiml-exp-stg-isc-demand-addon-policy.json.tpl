{
    "Statement": [
        {
            "Action": [
                "logs:Put*",
                "logs:Get*",
                "logs:Describe*",
                "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:logs:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:logs:*:*:log-group:/aws*",
                "arn:aws:logs:*:*:log-group:*:log-stream:*"
            ],
            "Sid": "LogsActions"
        },
        {
            "Action": [
                "events:PutPartnerEvents",
                "events:RemovePermission",
                "events:PutPermission"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:events:*:*:rule/$${aws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:ActivateEventSource",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:events:*:*:rule/$${aws:PrincipalTag/ApplicationTag}*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:archive/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:connection/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:event-bus/default",
                "arn:aws:events:*:*:api-destination/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:endpoint/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*::event-source/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricData",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutManagedInsightRules"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:DeleteApp",
                "sagemaker:AddTags"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:sagemaker:*:*:user-profile/*/hc-isc-demand-ds-user",
                "arn:aws:sagemaker:*:*:training-job/*",
                "arn:aws:sagemaker:*:*:space/*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:sagemaker:*:*:app/*/$${aws:PrincipalTag/ApplicationTag}/*/*"
            ]
        },
        {
            "Action": [
                "sagemaker-mlflow:Get*",
                "sagemaker-mlflow:DeleteTraces",
                "sagemaker-mlflow:DeleteRun",
                "sagemaker-mlflow:UpdateRun",
                "sagemaker-mlflow:EndTrace",
                "sagemaker-mlflow:Search*",
                "sagemaker-mlflow:List*",
                "sagemaker-mlflow:CreateRun",
                "sagemaker-mlflow:CreateExperiment",
                "sagemaker-mlflow:SearchExperiments",
                "sagemaker-mlflow:GetExperiment",
                "sagemaker-mlflow:GetExperimentByName",
                "sagemaker-mlflow:RestoreExperiment",
                "sagemaker-mlflow:UpdateExperiment",
                "sagemaker-mlflow:SetExperimentTag",
                "sagemaker-mlflow:SetTag",
                "sagemaker-mlflow:LogParam",
                "sagemaker-mlflow:GetMetricHistory",
                "sagemaker-mlflow:SearchRuns",
                "sagemaker-mlflow:ListArtifacts",
                "sagemaker-mlflow:CreateRegisteredModel",
                "sagemaker-mlflow:GetRegisteredModel",
                "sagemaker-mlflow:GetLatestModelVersions",
                "sagemaker-mlflow:CreateModelVersion",
                "sagemaker-mlflow:GetModelVersion",
                "sagemaker-mlflow:SearchModelVersions",
                "sagemaker-mlflow:GetDownloadURIForModelVersionArtifacts",
                "sagemaker-mlflow:TransitionModelVersionStage",
                "sagemaker-mlflow:SearchRegisteredModels",
                "sagemaker-mlflow:SetRegisteredModelTag",
                "sagemaker-mlflow:SetRegisteredModelAlias",
                "sagemaker-mlflow:GetModelVersionByAlias",
                "sagemaker-mlflow:RestoreRun",
                "sagemaker-mlflow:LogMetric",
                "sagemaker-mlflow:LogBatch",
                "sagemaker-mlflow:LogModel",
                "sagemaker-mlflow:LogInputs",
                "sagemaker-mlflow:UpdateModelVersion",
                "sagemaker-mlflow:StartTrace"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:sagemaker:*:991497151145:mlflow-tracking-server/isc-demand*"
        },
        {
            "Action": "sagemaker-mlflow:AccessUI",
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "cloudwatch:Put*",
                "cloudwatch:PutMetricAlarm",
                "cloudwatch:TagResource",
                "cloudwatch:PutDashboard",
                "cloudwatch:GetDashboard",
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:StopMetricStreams",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:SetAlarmState",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:StartMetricStreams"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        }
    ],
    "Version": "2012-10-17"
}