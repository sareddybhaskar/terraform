{
    "Statement": [
        {
            "Action": [
                "ec2:RevokeSecurityGroupIngress",
                "ec2:AuthorizeSecurityGroupEgress",
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:CreateNetworkInterfacePermission",
                "ec2:DescribeVpcEndpoints",
                "ec2:DescribeDhcpOptions",
                "ec2:CreateNetworkInterfacePermission",
                "ec2:RevokeSecurityGroupEgress",
                "ec2:DeleteSecurityGroup"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor0"
        },
        {
            "Action": "ec2:CreateTags",
            "Effect": "Allow",
            "Resource": [
                "arn:aws:ec2:*:*:security-group/*",
                "arn:aws:ec2:*:*:network-interface/*"
            ],
            "Sid": "VisualEditor1"
        },
        {
            "Action": "elasticfilesystem:CreateFileSystem",
            "Condition": {
                "StringLike": {
                    "aws:RequestTag/ManagedByAmazonSageMakerResource": "*"
                }
            },
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor2"
        },
        {
            "Action": [
                "elasticfilesystem:CreateMountTarget",
                "elasticfilesystem:DeleteMountTarget",
                "elasticfilesystem:DeleteFileSystem"
            ],
            "Condition": {
                "StringLike": {
                    "aws:ResourceTag/ManagedByAmazonSageMakerResource": "*"
                }
            },
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor3"
        },
        {
            "Action": [
                "ec2:CreateNetworkInterface",
                "elasticfilesystem:DescribeMountTargets",
                "sagemaker:CreateUserProfile",
                "ec2:DescribeNetworkInterfaces",
                "ec2:DescribeVpcs",
                "ec2:CreateSecurityGroup",
                "ec2:ModifyNetworkInterfaceAttribute",
                "ec2:DeleteNetworkInterface",
                "elasticfilesystem:DescribeFileSystems",
                "ec2:DescribeSubnets",
                "ec2:DescribeSecurityGroups",
                "sagemaker:DescribeUserProfile"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor4"
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:AddTags",
                "sagemaker:UpdateTrainingJob",
                "sagemaker:StopTrainingJob",
                "sagemaker:CreateTrainingJob",
                "sagemaker:DescribeNotebookInstance"

            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:us-east-1:991497151145:app/*/*/*",
				"arn:aws:sagemaker:us-east-1:991497151145:space/*/*",
                "arn:aws:sagemaker:us-east-1:991497151145:processing-job/*",
				"arn:aws:sagemaker:us-east-1:991497151145:training-job/*",
                "arn:aws:sagemaker:us-east-1:991497151145:notebook-instance/*"
            ],
            "Sid": "SagemakerActions"
        },
        {
            "Action": "iam:PassRole",
            "Condition": {
                "StringEquals": {
                    "iam:PassedToService": "sagemaker.amazonaws.com"
                }
            },
            "Effect": "Allow",
            "Resource": "arn:aws:iam::991497151145:role/odp-us-aiml-exp-stg-isc-demand-service-role",
            "Sid": "Passtosagemakerservice"
        },
         {
            "Action": [
                "sagemaker:CreateNotebookInstance"
            ],
            "Condition": {
                "StringEquals": {
                    "sagemaker:RootAccess": "Disabled"
                }
            },
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "LockDownCreateNotebookInstance"
        },
        {
            "Action": [
                "sagemaker:UpdateNotebookInstance"
            ],
            "Condition": {
                "StringEquals": {
                    "sagemaker:RootAccess": "Disabled"
                }
            },
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "LockDownUpdateNotebookInstance"
        }
    ],
    "Version": "2012-10-17"
}