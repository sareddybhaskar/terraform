{
    "Statement": [        
       
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::*:role/odp-us-aiml-exp-stg-isc-demand-service-role",
            "Sid": "Passrole"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject"                
            ],
            "Effect": "Allow",
            "Resource": [               
                "arn:aws:s3:::odp-us-aiml-exp-stg-isc-demand",
                "arn:aws:s3:::odp-us-aiml-exp-stg-isc-demand/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:Get*",
                "s3:List*"
            ],
            "Resource": ["arn:aws:s3:::odp-us-aiml-innovation-isc-outbound/*",
			"arn:aws:s3:::odp-us-innovation-aiml-isc/*",
			"arn:aws:s3:::odp-us-innovation-aiml-isc-dropbox/*"]
        }
                         
       
    ],
    "Version": "2012-10-17"
}