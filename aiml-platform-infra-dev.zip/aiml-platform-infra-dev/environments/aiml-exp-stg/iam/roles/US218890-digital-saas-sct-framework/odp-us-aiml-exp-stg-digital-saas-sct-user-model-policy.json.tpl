{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*",
                "bedrock:Converse",
                "bedrock:ConverseStream"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/7j6isalalnmy",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/fbu8tjhar202",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/i4wf3vnouq1z"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*",
                "bedrock:Converse",
                "bedrock:ConverseStream"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/7j6isalalnmy",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/fbu8tjhar202",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/i4wf3vnouq1z"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*::foundation-model/*",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/7j6isalalnmy",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/fbu8tjhar202",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/i4wf3vnouq1z",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/global.anthropic.claude-sonnet-4-20250514-v1:0"
            ]
        }
    ],
    "Version": "2012-10-17"
}