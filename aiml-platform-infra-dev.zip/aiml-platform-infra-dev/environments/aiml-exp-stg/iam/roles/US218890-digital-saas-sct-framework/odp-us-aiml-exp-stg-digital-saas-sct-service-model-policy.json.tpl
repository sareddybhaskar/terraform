{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/7j6isalalnmy",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/fbu8tjhar202",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/i4wf3vnouq1z"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/7j6isalalnmy",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/fbu8tjhar202",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/i4wf3vnouq1z"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*::foundation-model/*",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/7j6isalalnmy",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/fbu8tjhar202",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/i4wf3vnouq1z"
            ]
        },
        {
            "Action": [
                "ec2:RevokeSecurityGroupIngress",
                "ec2:AuthorizeSecurityGroupEgress",
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:CreateNetworkInterfacePermission",
                "ec2:DescribeVpcEndpoints",
                "ec2:DescribeDhcpOptions",
                "ec2:CreateNetworkInterfacePermission",
                "ec2:RevokeSecurityGroupEgress",
                "ec2:DeleteSecurityGroup"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor0"
        },
        {
            "Action": [
                "ec2:CreateNetworkInterface",
                "elasticfilesystem:DescribeMountTargets",
                "sagemaker:CreateUserProfile",
                "ec2:DescribeNetworkInterfaces",
                "ec2:DescribeVpcs",
                "ec2:CreateSecurityGroup",
                "ec2:ModifyNetworkInterfaceAttribute",
                "ec2:DeleteNetworkInterface",
                "elasticfilesystem:DescribeFileSystems",
                "ec2:DescribeSubnets",
                "ec2:DescribeSecurityGroups",
                "sagemaker:DescribeUserProfile"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor4"
        }
    ],
    "Version": "2012-10-17"
}