{
    "Statement": [
        {
            "Action": [
                "lambda:CreateFunction",
                "lambda:PublishLayerVersion",
                "lambda:InvokeAsync",
                "lambda:CreateEventSourceMapping",
                "lambda:RemoveLayerVersionPermission",
                "lambda:PutFunctionConcurrency",
                "lambda:EnableReplication",
                "lambda:DisableReplication",
                "lambda:PutFunctionEventInvokeConfig",
                "lambda:UpdateFunctionEventInvokeConfig",
                "lambda:UpdateEventSourceMapping",
                "lambda:InvokeFunction",
                "lambda:UpdateFunctionConfiguration",
                "lambda:AddLayerVersionPermission",
                "lambda:UpdateAlias",
                "lambda:UpdateFunctionCode",
                "lambda:AddPermission",
                "lambda:PutProvisionedConcurrencyConfig",
                "lambda:PublishVersion",
                "lambda:RemovePermission",
                "lambda:CreateAlias"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:lambda:*:*:event-source-mapping:*"
            ]
        },
        {
            "Action": [
                "comprehend:List*",
                "comprehend:Describe*",
                "comprehend:Batch*",
                "comprehend:Detect*"
            ],
            "Effect": "Allow",
            "Resource":"*"
        },
        {
            "Action": [
                "textract:AnalyzeDocument",
                "textract:DetectDocumentText",
                "textract:GetDocumentAnalysis",
                "textract:StartDocumentAnalysis",
                "textract:StartDocumentTextDetection"
            ],
            "Effect": "Allow",
            "Resource": "*"           
        },
        {
            "Effect": "Allow",
            "Action": [

                "aoss:CreateCollection",
                "aoss:ListCollections",
                "aoss:BatchGetCollection",
                "aoss:UpdateCollection",
                "aoss:CreateSecurityPolicy",
                "aoss:CreateAccessPolicy",
                "aoss:APIAccessAll",
                "aoss:Get*",
                "aoss:List*",
                "aoss:CreateIndex",
                "aoss:TagResource"
            ],
            "Resource": [
                "*"
            ]
        },
        {
            "Sid": "ServiceLinkedRolePermissions",
            "Effect": "Allow",
            "Action": [
                "iam:CreateServiceLinkedRole"
            ],
            "Resource": [
                "arn:aws:iam::*:role/aws-service-role/bedrock.amazonaws.com/AWSServiceRoleForAmazonBedrock*",
                "arn:aws:iam::*:role/aws-service-role/opensearchserverless.amazonaws.com/*",
                "arn:aws:iam::*:role/aws-service-role/observability.aoss.amazonaws.com/*"
            ]
        },
                {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
              ]
        },
                {
            "Action": [
                "scheduler:ListSchedules",
                "scheduler:ListScheduleGroups"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
			"Sid": "S3Vector",
			"Effect": "Allow",
			"Action": [
				"s3vectors:CreateIndex",
				"s3vectors:PutVectors",
				"s3vectors:ListTagsForResource",
				"s3vectors:ListVectors",
				"s3vectors:ListIndexes",
				"s3vectors:GetIndex",
				"s3vectors:GetVectorBucket",
				"s3vectors:GetVectors",
				"s3vectors:GetVectorBucketPolicy",
				"s3vectors:QueryVectors",
                "s3vectors:DeleteIndex"
			],
			"Resource": [
				"arn:aws:s3vectors:us-east-1:991497151145:bucket/odp-us-aiml-exp-stg-sct-ai-vector/index/$${aws:PrincipalTag/ApplicationTag}*",
				"arn:aws:s3vectors:us-east-1:991497151145:bucket/odp-us-aiml-exp-stg-sct-ai-vector"
			]
		}
    ],
    "Version": "2012-10-17"
}