{
    "Statement": [
        {
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricData",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutManagedInsightRules"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "cloudwatch:Put*",
                "cloudwatch:TagResource",
                "cloudwatch:GetDashboard",
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:StopMetricStreams",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:SetAlarmState",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:StartMetricStreams"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "logs:Put*",
                "logs:Get*",
                "logs:Describe*",
                "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"
            ],
            "Effect": "Allow",
            "Resource": [
                "*"
            ]
        },
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::*:role/odp-us-aiml-exp-stg-digital-saas-sct-service-role",
            "Sid": "Passrole"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-exp-stg-digital-saas-sct",
                "arn:aws:s3:::odp-us-aiml-exp-stg-digital-saas-sct/*"
            ]
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-innovation-ds-ctss",
                "arn:aws:s3:::odp-us-innovation-ds-ctss/*",
                "arn:aws:s3:::odp-us-innovation-ctss",
                "arn:aws:s3:::odp-us-innovation-ctss/*"
            ]
        },
        {
            "Action": [
                "sqs:Get*",
                "sqs:List*",
                "sqs:ChangeMessageVisibility",
                "sqs:PurgeQueue",
                "sqs:ReceiveMessage",
                "sqs:SendMessage",
                "sqs:CreateQueue",
                "sqs:SetQueueAttributes"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:sqs:*:*:$${aws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Action": [
                "opensearch:Get*",
                "opensearch:ApplicationAccessAll",
                "opensearch:StartDirectQuery",
                "opensearch:CreateCollection",
                "opensearch:UpdateCollection",
                "opensearch:DeleteCollection",
                "opensearch:GetCollection",
                "opensearch:ListCollections"
            ],
            "Effect": "Allow",
            "Resource": [
                "*"
            ]
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:InvokeEndpoint",
                "sagemaker:Describe*",
                "sagemaker:List*",
                "sagemaker:Search",
                "sagemaker:AddTags"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:processing-job/*"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeFlow",
                "bedrock:UpdateFlowAlias",
                "bedrock:StopEvaluationJob",
                "bedrock:PrepareFlow",
                "bedrock:UpdateAgentAlias",
                "bedrock:DetectGeneratedContent",
                "bedrock:InvokeDataAutomationAsync",
                "bedrock:CreateInferenceProfile",
                "bedrock:UpdateAgent",
                "bedrock:Retrieve",
                "bedrock:CreateAgentActionGroup",
                "bedrock:UpdateAgentKnowledgeBase",
                "bedrock:AssociateAgentCollaborator",
                "bedrock:DisassociateAgentCollaborator",
                "bedrock:UpdateDataAutomationProject",
                "bedrock:ApplyGuardrail",
                "bedrock:CreateEvaluationJob",
                "bedrock:UpdateAgentActionGroup",
                "bedrock:UpdateKnowledgeBase",
                "bedrock:CreateModelEvaluationJob",
                "bedrock:DisassociateAgentKnowledgeBase",
                "bedrock:CreateFlowVersion",
                "bedrock:CreateGuardrailVersion",
                "bedrock:UpdateFlow",
                "bedrock:CreateDataAutomationProject",
                "bedrock:UpdateAgentCollaborator",
                "bedrock:IngestKnowledgeBaseDocuments",
                "bedrock:AssociateAgentKnowledgeBase",
                "bedrock:RenderPrompt",
                "bedrock:CreateFlowAlias",
                "bedrock:CreatePromptRouter",
                "bedrock:StartFlowExecution",
                "bedrock:CreateAgentAlias",
                "bedrock:CreateGuardrail",
                "bedrock:PrepareAgent",
                "bedrock:UpdateGuardrail",
                "bedrock:StopFlowExecution",
                "bedrock:CreatePromptVersion",
                "bedrock:StopFlowExecution",
                "bedrock:RenderPrompt",
                "bedrock:UpdatePrompt"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:bedrock:*::*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*/execution/*",
                "arn:aws:bedrock:*:*:marketplace/model-endpoint/all-access",
                "arn:aws:bedrock:*:*:agent-alias/*/*",
                "arn:aws:bedrock:*:*:*/*"
            ]
        },
        {
            "Action": [
                "bedrock:List*",
                "bedrock:Get*",
                "bedrock:InvokeAgent",
                "bedrock:CallWithBearerToken",
                "bedrock:InvokeInlineAgent",
                "bedrock:OptimizePrompt",
                "bedrock:RetrieveAndGenerate",
                "bedrock:ValidateFlowDefinition",
                "bedrock:GenerateQuery",
                "bedrock:CreateFlow",
                "bedrock:CreateAgent",
                "bedrock:CreatePrompt",
                "bedrock:CreateKnowledgeBase",
                "bedrock:CreateDataSource",
                "bedrock:StartIngestionJob"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "athena:TagResource",
                "athena:CreateDataCatalog",
                "athena:UpdateDataCatalog",
                "athena:GetTableMetadata",
                "athena:StartQueryExecution",
                "athena:GetQueryResultsStream",
                "athena:GetQueryResults",
                "athena:GetDatabase",
                "athena:GetDataCatalog",
                "athena:GetNamedQuery",
                "athena:ListTagsForResource",
                "athena:ListQueryExecutions",
                "athena:ListNamedQueries",
                "athena:GetWorkGroup",
                "athena:CreateNamedQuery",
                "athena:ListDatabases",
                "athena:StopQueryExecution",
                "athena:GetQueryExecution",
                "athena:BatchGetNamedQuery",
                "athena:ListTableMetadata",
                "athena:BatchGetQueryExecution"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:athena:us-east-1:*:workgroup/us-dev-ds-digital-saas-sct-scientist",
                "arn:aws:athena:*:*:datacatalog/*"
            ]
        }
    ],
    "Version": "2012-10-17"
}