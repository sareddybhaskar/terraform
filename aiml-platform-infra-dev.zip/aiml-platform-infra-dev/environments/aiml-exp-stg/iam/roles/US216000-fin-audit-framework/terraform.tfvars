region      = "us-east-1"
environment = "aiml-exp-stg"

  tags = {
    Program        = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml"
    Project        = "aiml-audit"
    Role           = "dt-aiml-audit-ds"
    ApplicationTag = "aiml-audit"
    UserStory      = "US216001"
    project_number = "ID7061:PR17653"
    purpose        = "inv_2025"
    Owner          = "Mukul.Musale@gehealthcare.com"
    Contact        = "cdao_mlops@gehealthcare.com"
  }
