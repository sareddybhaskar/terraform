{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AllowInferenceProfileInvoke",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:inferenceProfileName": [
                        "fin-audit-titan-embeddings-g1-text",
                        "fin-audit-titan-text-embeddings-v2",
                        "fin-audit-titan-image-generator-g1-v1",
                        "fin-audit-titan-image-generator-g1-v2",
                        "fin-audit-titan-multimodal-embeddings-g1",
                        "fin-audit-nova-pro",
                        "fin-audit-claude-3-opus",
                        "fin-audit-claude-3-haiku",
                        "fin-audit-claude-3-5-sonnet-v2",
                        "fin-audit-claude-3-5-haiku",
                        "fin-audit-claude-3-5-sonnet",
                        "fin-audit-claude-3-7-sonnet",
                        "fin-audit-nova-lite",
                        "fin-audit-nova-micro",
                        "fin-audit-claude-4-sonnet",
                        "fin-audit-claude-4-5-sonnet",
                        "fin-audit-claude-4-5-haiku"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v1",                
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-image-generator-v1",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-image-generator-v2:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-image-v1",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-haiku-20240307-v1:0",                
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",                
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-sonnet-4-5-20250929-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",                
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",            
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-lite-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-micro-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-5-sonnet-20241022-v2:0",                
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-haiku-20240307-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.amazon.nova-pro-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-opus-20240229-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-sonnet-4-5-20250929-v1:0",
                "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0"
            ]
        },
        {
            "Sid": "AllowDirectFoundationModelInvoke",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",                
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-sonnet-4-5-20250929-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",                
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-haiku-20240307-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0"
            ]
        },
        {
            "Sid": "AllowApplicationInferenceProfiles",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/a2z7tarco58u",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/dsgjj91jgzjg",               
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/ngajb6xcng53",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/zctjk1ryfmy8",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/dd80118c3nnm",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/a2z7tarco58u",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/ctzudxp8p68v",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/qzyl9pumwa6g",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/nhrszhwfjnkv"
            ]
        }
    ]
}