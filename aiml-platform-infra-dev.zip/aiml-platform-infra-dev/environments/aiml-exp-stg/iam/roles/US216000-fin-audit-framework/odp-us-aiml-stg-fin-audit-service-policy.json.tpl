{
    "Statement": [        
        {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:PutMetricData",
            "cloudwatch:GetMetricData",
            "cloudwatch:PutAnomalyDetector",
            "cloudwatch:GetMetricStatistics",
            "cloudwatch:GetMetricWidgetImage",
            "cloudwatch:PutManagedInsightRules"
        ],
         "Resource": "*"
        },
       {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:Put*",            
            "cloudwatch:TagResource",            
            "cloudwatch:GetDashboard",
            "cloudwatch:EnableAlarmActions",
            "cloudwatch:StopMetricStreams",
            "cloudwatch:GetInsightRuleReport",
            "cloudwatch:SetAlarmState",
            "cloudwatch:EnableInsightRules",
            "cloudwatch:StartMetricStreams"
        ],
         "Resource": [
            "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:insight-rule/*",
            "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
         ]
       },       
        {
            "Effect": "Allow",
            "Action": [
                "logs:Put*",
                "logs:Get*",
		        "logs:Describe*",
		        "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",				
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"				
            ],
            "Resource": [
		        "*"
            ]
        },
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::*:role/odp-us-aiml-stg-fin-audit-service-role",
            "Sid": "Passrole"
        },
        {
            "Sid": "S3Bucket1",
            "Action": [
                "s3:List*",
                "s3:Get*",
                "s3:Put*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-exp-stg-audit-ai",
                "arn:aws:s3:::odp-us-aiml-exp-stg-audit-ai/*"
            ]
        },
        {
			"Sid": "S3Vector",
			"Effect": "Allow",
			"Action": [
				"s3vectors:CreateIndex",
				"s3vectors:PutVectors",
				"s3vectors:ListTagsForResource",
				"s3vectors:ListVectors",
				"s3vectors:ListIndexes",
				"s3vectors:GetIndex",
				"s3vectors:GetVectorBucket",
				"s3vectors:GetVectors",
				"s3vectors:GetVectorBucketPolicy",
				"s3vectors:QueryVectors"
			],
			"Resource": [
				"arn:aws:s3vectors:*:*:bucket/odp-us-aiml-exp-stg-audit-ai-vector",
				"arn:aws:s3vectors:*:*:bucket/odp-us-aiml-exp-stg-audit-ai-vector/index/$${aws:PrincipalTag/ApplicationTag}*"
			]
         },
         {
      "Action": [
        "bedrock:InvokeFlow",
        "bedrock:UpdateFlowAlias",
        "bedrock:StopEvaluationJob",
        "bedrock:PrepareFlow",
        "bedrock:UpdateAgentAlias",
        "bedrock:DetectGeneratedContent",
        "bedrock:InvokeDataAutomationAsync",
        "bedrock:CreateInferenceProfile",
        "bedrock:UpdateAgent",
        "bedrock:Retrieve",
        "bedrock:CreateAgentActionGroup",
        "bedrock:UpdateAgentKnowledgeBase",
        "bedrock:AssociateAgentCollaborator",
        "bedrock:DisassociateAgentCollaborator",
        "bedrock:UpdateDataAutomationProject",
        "bedrock:ApplyGuardrail",
        "bedrock:CreateEvaluationJob",
        "bedrock:UpdateAgentActionGroup",
        "bedrock:UpdateKnowledgeBase",
        "bedrock:CreateModelEvaluationJob",
        "bedrock:DisassociateAgentKnowledgeBase",
        "bedrock:CreateFlowVersion",
        "bedrock:CreateGuardrailVersion",
        "bedrock:UpdateFlow",
        "bedrock:CreateDataAutomationProject",
        "bedrock:UpdateAgentCollaborator",
        "bedrock:IngestKnowledgeBaseDocuments",
        "bedrock:AssociateAgentKnowledgeBase",
        "bedrock:InvokeModelWithResponseStream",
        "bedrock:RenderPrompt",
        "bedrock:CreateFlowAlias",
        "bedrock:CreatePromptRouter",
        "bedrock:StartFlowExecution",
        "bedrock:CreateAgentAlias",
        "bedrock:CreateGuardrail",
        "bedrock:PrepareAgent",
        "bedrock:UpdateGuardrail",
        "bedrock:StopFlowExecution",
        "bedrock:CreatePromptVersion",
        "bedrock:StopFlowExecution",
        "bedrock:ListKnowledgeBases",
        "bedrock:CreateDataSource",
        "bedrock:GetDataSource",
        "bedrock:UpdateDataSource",
        "bedrock:ListDataSources",
        "bedrock:StartIngestionJob",
        "bedrock:GetIngestionJob",
        "bedrock:ListIngestionJobs",
        "bedrock:RenderPrompt",
        "bedrock:UpdatePrompt"
      ],
      "Effect": "Allow",
      "Resource": [
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*",
        "arn:aws:bedrock:*::*/$${aws:PrincipalTag/ApplicationTag}*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*:*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*/execution/*",
        "arn:aws:bedrock:*:*:marketplace/model-endpoint/all-access",
        "arn:aws:bedrock:*:*:agent-alias/*/*",
        "arn:aws:bedrock:*:*:*/*"
      ]
    },
    {
      "Action": [
        "bedrock:List*",
        "bedrock:Get*",
        "bedrock:InvokeAgent",
        "bedrock:CallWithBearerToken",
        "bedrock:InvokeInlineAgent",
        "bedrock:OptimizePrompt",
        "bedrock:RetrieveAndGenerate",
        "bedrock:ValidateFlowDefinition",
        "bedrock:GenerateQuery",
        "bedrock:CreateFlow",
        "bedrock:CreateAgent",
        "bedrock:CreatePrompt",
        "bedrock:CreateKnowledgeBase"
      ],
      "Effect": "Allow",
      "Resource": "*"
    },
    {
      "Sid": "ManageCollections",
      "Effect": "Allow",
      "Action": [
        "aoss:CreateCollection",
        "aoss:ListCollections",
        "aoss:BatchGetCollection",
        "aoss:UpdateCollection",
        "aoss:APIAccessAll",
        "aoss:Get*",
        "aoss:List*",
        "aoss:CreateSecurityPolicy",
        "aoss:CreateAccessPolicy",
        "aoss:CreateIndex"
      ],
      "Resource": [
        "arn:aws:aoss:*:*:collection/$${aws:PrincipalTag/ApplicationTag}*",
        "arn:aws:aoss:*:*:index/$${aws:PrincipalTag/ApplicationTag}*",
        "arn:aws:aoss:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
      ]
    }   
    ],
    "Version": "2012-10-17"
}