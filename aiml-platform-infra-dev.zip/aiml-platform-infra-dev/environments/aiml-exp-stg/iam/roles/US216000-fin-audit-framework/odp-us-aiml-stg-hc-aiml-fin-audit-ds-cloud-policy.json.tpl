{
    "Statement": [
        {
            "Action": "sts:AssumeRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::991497151145:role/hc-aiml-fin-audit-ds",
            "Sid": "assumerole"
        }
    ],
    "Version": "2012-10-17"
}