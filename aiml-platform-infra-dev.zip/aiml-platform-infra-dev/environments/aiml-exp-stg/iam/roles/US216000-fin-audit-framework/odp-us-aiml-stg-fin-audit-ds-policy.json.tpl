{
    "Version": "2012-10-17",
    "Statement": [
       {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:PutMetricData",
            "cloudwatch:GetMetricData",
            "cloudwatch:PutAnomalyDetector",
            "cloudwatch:GetMetricStatistics",
            "cloudwatch:GetMetricWidgetImage",
            "cloudwatch:PutManagedInsightRules"
         ],
         "Resource": "*"
       },
       {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:PutInsightRule",
            "cloudwatch:PutMetricAlarm",
            "cloudwatch:TagResource",
            "cloudwatch:PutDashboard",
            "cloudwatch:GetDashboard",
            "cloudwatch:EnableAlarmActions",
            "cloudwatch:StopMetricStreams",
            "cloudwatch:GetInsightRuleReport",
            "cloudwatch:SetAlarmState",
            "cloudwatch:EnableInsightRules",
            "cloudwatch:StartMetricStreams"
         ],
         "Resource": [
            "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:insight-rule/*",
            "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
         ]
       },
       {
         "Effect": "Allow",
         "Action": "cloudwatch:Put*",
         "Resource": [
            "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:insight-rule/*",
            "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*"
         ]
        },
         {
            "Effect": "Allow",
            "Action": [
                "logs:Put*",
                "logs:Get*",
		          "logs:Describe*",
		          "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",				
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"				
            ],
            "Resource": [
		"*"
            ]
        }, {
         "Effect": "Allow",
         "Action": [
            "events:PutPartnerEvents",
            "events:RemovePermission",
            "events:PutPermission"
         ],
         "Resource": "*"
      },
      {
         "Effect": "Allow",
         "Action": [
            "events:TagResource",
            "events:Put*",
            "events:EnableRule",
            "events:RemoveTargets",
            "events:Create*",
            "events:UntagResource",
            "events:DisableRule"
         ],
         "Resource": "arn:aws:events:*:*:rule/$${awsaws:PrincipalTag/ApplicationTag}*"
      },
      {
         "Effect": "Allow",
         "Action": [
            "events:TagResource",
            "events:Put*",
            "events:EnableRule",
            "events:RemoveTargets",
            "events:ActivateEventSource",
            "events:Create*",
            "events:UntagResource",
            "events:DisableRule"
         ],
         "Resource": [
            "arn:aws:events:*:*:rule/$${awsaws:PrincipalTag/ApplicationTag}*/$${awsaws:PrincipalTag/ApplicationTag}*",
            "arn:aws:events:*:*:archive/$${awsaws:PrincipalTag/ApplicationTag}*",
            "arn:aws:events:*:*:connection/$${awsaws:PrincipalTag/ApplicationTag}*",
            "arn:aws:events:*:*:event-bus/default",
            "arn:aws:events:*:*:api-destination/$${awsaws:PrincipalTag/ApplicationTag}*",
            "arn:aws:events:*:*:endpoint/$${awsaws:PrincipalTag/ApplicationTag}*",
            "arn:aws:events:*::event-source/$${awsaws:PrincipalTag/ApplicationTag}*"
         ]
        },
        {
            "Sid": "SagemakerActions",
            "Effect": "Allow",
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*"
            ],
            "Resource": [
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*"
            ]
        },
        {
			"Sid": "S3Vector",
			"Effect": "Allow",
			"Action": [
				"s3vectors:CreateIndex",
				"s3vectors:PutVectors",
				"s3vectors:ListTagsForResource",
				"s3vectors:ListVectors",
				"s3vectors:ListIndexes",
				"s3vectors:GetIndex",
				"s3vectors:GetVectorBucket",
				"s3vectors:GetVectors",
				"s3vectors:GetVectorBucketPolicy",
				"s3vectors:QueryVectors"
			],
			"Resource": [
            "arn:aws:s3vectors:*:*:bucket/odp-us-aiml-exp-stg-audit-ai-vector",
				"arn:aws:s3vectors:*:*:bucket/odp-us-aiml-exp-stg-audit-ai-vector/index/$${aws:PrincipalTag/ApplicationTag}*"
			]
         },
        {
            "Action": [
                "bedrock:InvokeFlow",
                "bedrock:UpdateFlowAlias",
                "bedrock:StopEvaluationJob",
                "bedrock:PrepareFlow",
                "bedrock:UpdateAgentAlias",
                "bedrock:DetectGeneratedContent",
                "bedrock:InvokeDataAutomationAsync",
                "bedrock:CreateInferenceProfile",
                "bedrock:UpdateAgent",
                "bedrock:Retrieve",
                "bedrock:CreateAgentActionGroup",
                "bedrock:UpdateAgentKnowledgeBase",
                "bedrock:AssociateAgentCollaborator",
                "bedrock:DisassociateAgentCollaborator",
                "bedrock:UpdateDataAutomationProject",
                "bedrock:ApplyGuardrail",
                "bedrock:CreateEvaluationJob",
                "bedrock:UpdateAgentActionGroup",
                "bedrock:UpdateKnowledgeBase",
                "bedrock:CreateModelEvaluationJob",
                "bedrock:DisassociateAgentKnowledgeBase",
                "bedrock:CreateFlowVersion",
                "bedrock:CreateGuardrailVersion",
                "bedrock:UpdateFlow",
                "bedrock:CreateDataAutomationProject",
                "bedrock:UpdateAgentCollaborator",
                "bedrock:IngestKnowledgeBaseDocuments",
                "bedrock:AssociateAgentKnowledgeBase",
                "bedrock:RenderPrompt",
                "bedrock:CreateFlowAlias",
                "bedrock:CreatePromptRouter",
                "bedrock:StartFlowExecution",
                "bedrock:CreateAgentAlias",
                "bedrock:CreateGuardrail",
                "bedrock:PrepareAgent",
                "bedrock:UpdateGuardrail",
                "bedrock:StopFlowExecution",
                "bedrock:CreatePromptVersion",
                "bedrock:StopFlowExecution",
                "bedrock:RenderPrompt",
                "bedrock:GetKnowledgeBase",
                "bedrock:ListKnowledgeBases",
                "bedrock:CreateDataSource",
                "bedrock:GetDataSource",
                "bedrock:UpdateDataSource",
                "bedrock:ListDataSources",
                "bedrock:StartIngestionJob",
                "bedrock:InvokeModelWithResponseStream",
                "bedrock:GetIngestionJob",
                "bedrock:ListIngestionJobs",
                "bedrock:UpdatePrompt",
        		    "bedrock:UpdateDataSource",
        		    "bedrock:CreateDataSource"              
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:bedrock:*::*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*",
                "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*/execution/*",
                "arn:aws:bedrock:*:*:marketplace/model-endpoint/all-access",
                "arn:aws:bedrock:*:*:agent-alias/*/*",
                "arn:aws:bedrock:*:*:*/*"
            ]
        },
        {
            "Action": [
                "bedrock:List*",
                "bedrock:Get*",
                "bedrock:InvokeAgent",
                "bedrock:CallWithBearerToken",
                "bedrock:InvokeInlineAgent",
                "bedrock:OptimizePrompt",
                "bedrock:RetrieveAndGenerate",
                "bedrock:ValidateFlowDefinition",
                "bedrock:GenerateQuery",
                "bedrock:CreateFlow",
                "bedrock:CreateAgent",
                "bedrock:CreatePrompt",
                "bedrock:CreateKnowledgeBase"
            ],
            "Effect": "Allow",
            "Resource": "*"
        }		
    ]
}