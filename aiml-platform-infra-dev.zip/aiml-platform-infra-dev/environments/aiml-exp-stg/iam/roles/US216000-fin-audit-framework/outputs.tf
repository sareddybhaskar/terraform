output "login-role" {
  value = module.hc-aiml-fin-audit-ds.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}

