{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8z1lkxwv2sd6",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/oprotdodk44e",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/xb55kxmav1yz",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/kpwfjekjrg7k",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0lgo5jkjdsui"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8z1lkxwv2sd6",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/oprotdodk44e",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/xb55kxmav1yz",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/kpwfjekjrg7k",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0lgo5jkjdsui"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-4-5-sonnet-20250219-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-4-5-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8z1lkxwv2sd6",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/oprotdodk44e",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/xb55kxmav1yz",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/kpwfjekjrg7k",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0lgo5jkjdsui"
            ]
        }
    ],
    "Version": "2012-10-17"
}