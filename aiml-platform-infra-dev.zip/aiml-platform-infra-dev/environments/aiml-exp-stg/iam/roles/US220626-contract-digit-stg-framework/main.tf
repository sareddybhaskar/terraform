provider "aws" {
  #version = ">= 3.0, < 4.0"
  #version = "~> 5.0"
  version = "6.2.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/iam/roles/US220626-contract-digit-stg-framework/terraform.tfstate"
    region = "us-east-1"
  }
}

############Cloud Ploicy############

data "template_file" "user-reservered-cloud-template" {
  template = file("${path.module}/odp-us-aiml-exp-hc-ai-contract-digit-stg-user-cloud-policy.json.tpl")
}

module "user-reservered-cloud-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-hc-ai-contract-digit-stg-user-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-hc-ai-contract-digit-stg-user-cloud-policy"

  policy = data.template_file.user-reservered-cloud-template.rendered
}


data "template_file" "user-reservered-template" {
  template = file("${path.module}/odp-us-aiml-exp-hc-ai-contract-digit-stg-user-policy.json.tpl")
}

module "user-reservered-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-hc-ai-contract-digit-stg-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-hc-ai-contract-digit-stg-user-policy"

  policy = data.template_file.user-reservered-template.rendered
}

###### Local Template Files ######

data "template_file" "service" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-service-policy.json.tpl")
}

data "template_file" "service2" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-service1-policy.json.tpl")
}

data "template_file" "user" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-user-policy.json.tpl")
}

data "template_file" "user2" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-user1-policy.json.tpl")
}

###### Creating IAM Policy ######

module "user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-contract-digit-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-contract-digit-user-policy"

  policy = data.template_file.user.rendered
}

module "user2" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-contract-digit-user2-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-contract-digit-user2-policy"

  policy = data.template_file.user2.rendered
}

module "service" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-contract-digit-stg-service-policy"
  path        = "/"
  description = "odp-us-aiml-exp-contract-digit-stg-service-policy"

  policy = data.template_file.service.rendered
}

module "service2" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-contract-digit-stg-service1-policy"
  path        = "/"
  description = "odp-us-aiml-exp-contract-digit-stg-service1-policy"

  policy = data.template_file.service2.rendered
}

###### Login Role ######

module "hc-ai-contract-digit-stg-user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-ai-contract-digit-stg-user"
  role_description      = "hc-ai-contract-digit-stg-user"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-aiml-exp-cntrt-dgt-stg_f60bc0b174b4264e"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
}

###### Service Role ######

resource "aws_iam_role" "servicerole" {
  name        = "odp-us-aiml-exp-stg-contract-digit-service-role"
  description = "odp-us-aiml-exp-stg-contract-digit-service-role"

  assume_role_policy    = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": [
                    "s3.amazonaws.com",
                    "secretsmanager.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "events.amazonaws.com",
                    "states.amazonaws.com",
                    "logs.amazonaws.com",
                    "ecs.amazonaws.com",
                    "ecr.amazonaws.com",
                    "lambda.amazonaws.com",
                    "bedrock.amazonaws.com"

                    
                ]
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags            = var.tags
}

###### Attaching Policies to Login Role ######

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-ai-contract-digit-stg-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-ai-contract-digit-stg-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.hc-ai-contract-digit-stg-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy" 
}

  resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.hc-ai-contract-digit-stg-user.role_name
  policy_arn = module.user.arn
}

resource "aws_iam_role_policy_attachment" "user13" {
  role       = module.hc-ai-contract-digit-stg-user.role_name
  policy_arn = module.user2.arn
}

resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.hc-ai-contract-digit-stg-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
} 

resource "aws_iam_role_policy_attachment" "user6" {
  role       = module.hc-ai-contract-digit-stg-user.role_name
  policy_arn = module.user-model.arn
} 
 
###### Attaching Policies to Service Role ######

resource "aws_iam_role_policy_attachment" "service1" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service3" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service4" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service.arn
}

resource "aws_iam_role_policy_attachment" "service5" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service-model.arn
}

resource "aws_iam_role_policy_attachment" "service12" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service2.arn
}

############Cloud Ploicy############

data "template_file" "user-reservered-cloud-template1" {
  template = file("${path.module}/odp-us-aiml-exp-hc-ai-contract-digit-stg-non-sensitive-user-cloud-policy.json.tpl")
}

module "user-reservered-cloud-policy1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-hc-ai-contract-digit-stg-non-sensitive-user-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-hc-ai-contract-digit-stg-non-sensitive-user-cloud-policy"

  policy = data.template_file.user-reservered-cloud-template1.rendered
}


data "template_file" "user-reservered-template1" {
  template = file("${path.module}/odp-us-aiml-exp-hc-ai-contract-digit-stg-non-sensitive-user-policy.json.tpl")
}

module "user-reservered-policy1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-hc-ai-contract-digit-stg-non-sensitive-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-hc-ai-contract-digit-stg-non-sensitive-user-policy"

  policy = data.template_file.user-reservered-template1.rendered
}

###### Local Template Files ######

data "template_file" "service1" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-non-sensitive-service-policy.json.tpl")
}

data "template_file" "user1" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-non-sensitive-user-policy.json.tpl")
}

###### Creating IAM Policy ######

module "user1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-contract-digit-non-sensitive-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-contract-digit-non-sensitive-user-policy"

  policy = data.template_file.user1.rendered
}

module "service1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-contract-digit-non-sensitive-service-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-contract-digit-non-sensitive-service-policy"

  policy = data.template_file.service1.rendered
}

###### Login Role-1 ######

module "hc-ai-contract-digit-stg-non-sensitive-user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-ai-contract-digit-stg-non-sensitive-user"
  role_description      = "hc-ai-contract-digit-stg-non-sensitive-user"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-aiml-exp-cntrt-dgt-stg-sntv_929c9d7f51ce00b5"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
}

###### Service Role-1 ######

resource "aws_iam_role" "servicerole1" {
  name        = "odp-us-aiml-exp-stg-contract-digit-non-sensitive-service-role"
  description = "odp-us-aiml-exp-stg-contract-digit-non-sensitive-service-role"

  assume_role_policy    = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": [
                    "s3.amazonaws.com",
                    "secretsmanager.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "events.amazonaws.com",
                    "states.amazonaws.com",
                    "logs.amazonaws.com",
                    "ecs.amazonaws.com",
                    "ecr.amazonaws.com",
                    "lambda.amazonaws.com",
                    "bedrock.amazonaws.com"
                ]
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags            = var.tags
}

###### Attaching Policies to Login Role ######

resource "aws_iam_role_policy_attachment" "user7" {
  role       = module.hc-ai-contract-digit-stg-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user8" {
  role       = module.hc-ai-contract-digit-stg-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user9" {
  role       = module.hc-ai-contract-digit-stg-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy" 
}

  resource "aws_iam_role_policy_attachment" "user10" {
  role       = module.hc-ai-contract-digit-stg-non-sensitive-user.role_name
  policy_arn = module.user1.arn
}

resource "aws_iam_role_policy_attachment" "user11" {
  role       = module.hc-ai-contract-digit-stg-non-sensitive-user.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
} 

resource "aws_iam_role_policy_attachment" "user12" {
  role       = module.hc-ai-contract-digit-stg-non-sensitive-user.role_name
  policy_arn = module.user-model.arn
} 
 
###### Attaching Policies to Service Role ######

resource "aws_iam_role_policy_attachment" "service6" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service7" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service8" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  module.service.arn
}

resource "aws_iam_role_policy_attachment" "service9" {
  role       = aws_iam_role.servicerole1.name
  policy_arn =  module.service-model.arn
}
