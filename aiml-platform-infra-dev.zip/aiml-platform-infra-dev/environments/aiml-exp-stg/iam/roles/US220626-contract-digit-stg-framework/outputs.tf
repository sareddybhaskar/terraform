output "login-role" {
  value = module.hc-ai-contract-digit-stg-user.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}
output "login-role1" {
  value = module.hc-ai-contract-digit-stg-non-sensitive-user.role_name
}

output "service-role1" {
  value = aws_iam_role.servicerole1.name
}

output "all-model-arns" {
  value = {
    "claude-4-5-haiku"  = aws_bedrock_inference_profile.model1.arn
    "claude-3-5-haiku"  = aws_bedrock_inference_profile.model2.arn
    "claude-4-5-sonnet" = aws_bedrock_inference_profile.model3.arn
    "claude-3-7-sonnet" = aws_bedrock_inference_profile.model4.arn
    "nova-pro"          = aws_bedrock_inference_profile.model5.arn
   }
}

output "all-model-arns-list" {
  value = [
    aws_bedrock_inference_profile.model1.arn,
    aws_bedrock_inference_profile.model2.arn,
    aws_bedrock_inference_profile.model3.arn,
    aws_bedrock_inference_profile.model4.arn,
    aws_bedrock_inference_profile.model5.arn
  ]
}