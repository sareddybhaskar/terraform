{
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricData",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutManagedInsightRules"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudwatch:Put*",
                "cloudwatch:TagResource",
                "cloudwatch:GetDashboard",
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:StopMetricStreams",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:SetAlarmState",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:StartMetricStreams"
            ],
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:Put*",
                "logs:Get*",
                "logs:Describe*",
                "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"
            ],
            "Resource": [
                "*"
            ]
        },
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::*:role/odp-us-aiml-exp-stg-contract-digit-non-sensitive-service-role",
            "Sid": "Passrole"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-exp-stg-contract-digit-non-sensitive",
                "arn:aws:s3:::odp-us-aiml-exp-stg-contract-digit-non-sensitive/*"
            ]
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-innovation-ent-raw-sensitive/coupa",
                "arn:aws:s3:::odp-us-innovation-ent-raw-sensitive/coupa/*",
                "arn:aws:s3:::odp-us-innovation-ent-raw/coupa",
                "arn:aws:s3:::odp-us-innovation-ent-raw/coupa/*"
            ]
        },
        {
            "Action": [
                "bedrock:List*",
                "bedrock:Get*",
                "bedrock:InvokeAgent",
                "bedrock:CallWithBearerToken",
                "bedrock:InvokeInlineAgent",
                "bedrock:OptimizePrompt",
                "bedrock:RetrieveAndGenerate",
                "bedrock:ValidateFlowDefinition",
                "bedrock:GenerateQuery",
                "bedrock:CreateFlow",
                "bedrock:CreateAgent",
                "bedrock:CreatePrompt",
                "bedrock:CreateKnowledgeBase"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "lambda:CreateFunction",
                "lambda:UpdateFunctionCode",
                "lambda:UpdateFunctionConfiguration",
                "lambda:InvokeFunction",
                "lambda:DeleteFunction",
                "lambda:GetFunction",
                "lambda:ListFunctions"
            ],
            "Resource": [
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:lambda:*:*:event-source-mapping:*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "states:CreateStateMachine",
                "states:UpdateStateMachine",
                "states:StartExecution",
                "states:DescribeExecution",
                "states:StopExecution",
                "states:DeleteStateMachine"
            ],
            "Resource": [
                "arn:aws:states:*:*:activity:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:states:*:*:execution:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:states:*:*:stateMachine:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "events:PutPartnerEvents",
                "events:RemovePermission",
                "events:PutPermission"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule"
            ],
            "Resource": "arn:aws:events:*:*:rule/$${awsaws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:ActivateEventSource",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule"
            ],
            "Resource": [
                "arn:aws:events:*:*:rule/$${awsaws:PrincipalTag/ApplicationTag}*/$${awsaws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:archive/$${awsaws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:connection/$${awsaws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:event-bus/default",
                "arn:aws:events:*:*:api-destination/$${awsaws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:endpoint/$${awsaws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*::event-source/$${awsaws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "ecs:CreateCluster",
                "ecs:CreateService",
                "ecs:UpdateService",
                "ecs:DescribeServices",
                "ecs:RegisterTaskDefinition",
                "ecs:RunTask",
                "ecs:StopTask"
            ],
            "Resource": [
                "arn:aws:ecs:*:*:cluster/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecs:*:*:service/$${aws:PrincipalTag/ApplicationTag}*/*",
                "arn:aws:ecs:*:*:task-definition/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecs:*:*:task/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "ecr:CreateRepository",
                "ecr:PutImage",
                "ecr:BatchGetImage",
                "ecr:GetDownloadUrlForLayer"
            ],
            "Resource": [
                "arn:aws:ecr:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecr:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "ce:GetCostAndUsage",
                "ce:GetCostForecast",
                "ce:GetUsageForecast",
                "ce:GetDimensionValues",
                "ce:GetTags",
                "ce:GetReservationUtilization",
                "ce:GetSavingsPlansUtilization",
                "ce:GetSavingsPlansCoverage"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "aws-portal:ViewBilling",
                "aws-portal:ViewUsage"
            ],
            "Resource": "*"
        }
    ],
    "Version": "2012-10-17"
}