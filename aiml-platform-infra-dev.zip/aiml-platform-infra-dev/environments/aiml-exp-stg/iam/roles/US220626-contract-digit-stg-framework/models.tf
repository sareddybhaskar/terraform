##############Bedrock Models ##############

data "template_file" "user-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-user-model-policy.json.tpl")

  vars = {
    claude_4_5_haiku_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model2.arn
    claude_4_5_sonnet_arn = aws_bedrock_inference_profile.model3.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model4.arn
    nova_pro_arn = aws_bedrock_inference_profile.model5.arn
  }
}

# service model policy template
data "template_file" "service-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-contract-digit-service-model-policy.json.tpl")

  vars = {
    claude_4_5_haiku_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model2.arn
    claude_4_5_sonnet_arn = aws_bedrock_inference_profile.model3.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model4.arn
    nova_pro_arn = aws_bedrock_inference_profile.model5.arn
  }
}

module "user-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-contract-digit-user-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-contract-digit-user-model-policy"

  policy = data.template_file.user-model-policy.rendered
}

module "service-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-contract-digit-service-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-contract-digit-service-model-policy"

  policy = data.template_file.service-model-policy.rendered
}

###### Bedrock Instance Profile ######
resource "aws_bedrock_inference_profile" "model1" {
  name        = "contract-digit-stg-claude-4-5-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-stg-claude-4-5-haiku"
    }
  )
}

resource "aws_bedrock_inference_profile" "model2" {
  name        = "contract-digit-stg-claude-3-5-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-nova-pro"
    }
  )
}

resource "aws_bedrock_inference_profile" "model3" {
  name        = "contract-digit-stg-claude-4-5-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-5-20250929-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-stg-claude-4-5-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model4" {
  name        = "contract-digit-stg-claude-3-7-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-stg-claude-3-7-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model5" {
  name        = "contract-digit-stg-nova-pro"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "contract-digit-stg-nova-pro"
    }
  )
}
