region      = "us-east-1"
environment = "aiml-exp-stg"

  tags = {
    Project        = "aiml-contract-digit"
    Program        = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml-contract-digit"
    Role           = "dt-aiml-contract-digit"
    Name           = "odp-us-aiml-exp-stg-contract-digit"
    ApplicationTag = "contract-digit"
    project_number = "ID7828:PR17826"
    purpose        = "inv_2025"
    UserStory      = "US220626"
    Contact        = "Marcin.Stezowski@gehealthcare.com:Sylwia.Krakowska@gehealthcare.com"
  }
