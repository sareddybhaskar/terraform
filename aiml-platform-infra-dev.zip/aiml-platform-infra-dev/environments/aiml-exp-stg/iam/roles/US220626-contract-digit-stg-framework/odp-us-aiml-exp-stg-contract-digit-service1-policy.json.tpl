{
    "Statement": [
        {
            "Action": [
                "bedrock:List*",
                "bedrock:Get*",
                "bedrock:InvokeAgent",
                "bedrock:CallWithBearerToken",
                "bedrock:InvokeInlineAgent",
                "bedrock:OptimizePrompt",
                "bedrock:RetrieveAndGenerate",
                "bedrock:ValidateFlowDefinition",
                "bedrock:GenerateQuery",
                "bedrock:CreateFlow",
                "bedrock:CreateAgent",
                "bedrock:CreatePrompt",
                "bedrock:CreateKnowledgeBase"
            ],
            "Effect": "Allow",
            "Resource": "*"
        }
    ],
    "Version": "2012-10-17"
}