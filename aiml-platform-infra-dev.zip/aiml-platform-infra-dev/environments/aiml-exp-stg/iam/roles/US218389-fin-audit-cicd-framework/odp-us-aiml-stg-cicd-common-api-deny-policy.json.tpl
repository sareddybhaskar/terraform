{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "ScopeToPrivateApis",
            "Effect": "Deny",
            "Action": [
                "apigateway:PATCH",
                "apigateway:POST",
                "apigateway:PUT"
            ],
            "Resource": [
                "arn:aws:apigateway:*::/restapis",
                "arn:aws:apigateway:*::/restapis/??????????"
            ],
            "Condition": {
                "ForAnyValue:StringEqualsIfExists": {
                    "apigateway:Request/EndpointType": "REGIONAL"
                }
            }
        },
        {
            "Sid": "DenyOtherAPIActions",
            "Effect": "Deny",
            "Action": [
                "apigateway:PATCH",
                "apigateway:POST",
                "apigateway:PUT",
                "apigateway:GET",
                "apigateway:AddCertificateToDomain"
            ],
            "Resource": [
                "arn:aws:apigateway:*::/domainnames",
                "arn:aws:apigateway:*::/domainnames/*",
                "arn:aws:apigateway:*::/vpclinks",
                "arn:aws:apigateway:*::/vpclinks/*",
                "arn:aws:apigateway:*::/apikeys",
                "arn:aws:apigateway:*::/apikeys/*",
                "arn:aws:apigateway:*::/usageplans",
                "arn:aws:apigateway:*::/usageplans/*",
                "arn:aws:apigateway:*::/clientcertificates",
                "arn:aws:apigateway:*::/clientcertificates/*"
            ]
        }
    ]
}