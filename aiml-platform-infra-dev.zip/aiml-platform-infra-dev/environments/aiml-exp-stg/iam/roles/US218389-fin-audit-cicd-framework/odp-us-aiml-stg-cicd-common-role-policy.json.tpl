{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "lambda:CreateFunction",
                "lambda:PublishLayerVersion",
                "lambda:InvokeAsync",
                "lambda:CreateEventSourceMapping",
                "lambda:RemoveLayerVersionPermission",
                "lambda:PutFunctionConcurrency",
                "lambda:EnableReplication",
                "lambda:DisableReplication",
                "lambda:PutFunctionEventInvokeConfig",
                "lambda:UpdateFunctionEventInvokeConfig",
                "lambda:UpdateEventSourceMapping",
                "lambda:InvokeFunction",
                "lambda:UpdateFunctionConfiguration",
                "lambda:AddLayerVersionPermission",
                "lambda:UpdateAlias",
                "lambda:UpdateFunctionCode",
                "lambda:AddPermission",
                "lambda:PutProvisionedConcurrencyConfig",
                "lambda:PublishVersion",
                "lambda:RemovePermission",
                "lambda:CreateAlias"
            ],
            "Resource": [
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:lambda:*:*:event-source-mapping:*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "states:List*",
                "states:Describe*",
                "states:CreateActivity",
                "states:UpdateStateMachine",
                "states:StopExecution",
                "states:StartSyncExecution",
                "states:SendTaskSuccess",
                "states:SendTaskFailure",
                "states:GetExecutionHistory",
                "states:StartExecution",
                "states:SendTaskHeartbeat",
                "states:GetActivityTask",
                "states:CreateStateMachine"
            ],
            "Resource": [
                "arn:aws:states:*:*:activity:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:states:*:*:execution:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:states:*:*:stateMachine:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "sqs:Get*",
                "sqs:List*",
                "sqs:ChangeMessageVisibility",
                "sqs:PurgeQueue",
                "sqs:ReceiveMessage",
                "sqs:SendMessage",
                "sqs:CreateQueue",
                "sqs:SetQueueAttributes"
            ],
            "Resource": "arn:aws:sqs:*:*:$${aws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "dynamodb:BatchGetItem",
                "dynamodb:ConditionCheckItem",
                "dynamodb:PutItem",
                "dynamodb:Scan",
                "dynamodb:Query",
                "dynamodb:UpdateItem",
                "dynamodb:BatchWriteItem",
                "dynamodb:PartiQLSelect",
                "dynamodb:PartiQLUpdate",
                "dynamodb:PartiQLInsert",
                "dynamodb:ImportTable"
            ],
            "Resource": [
                "arn:aws:dynamodb:*:*:table/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:dynamodb:*:*:table/$${aws:PrincipalTag/ApplicationTag}*/index/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "glue:BatchStopJobRun",
                "glue:ResetJobBookmark",
                "glue:StartCrawlerSchedule",
                "glue:StartJobRun",
                "glue:StopCrawlerSchedule"
            ],
            "Resource": "*"
        },
        {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "sns:ConfirmSubscription",
                "sns:CreateTopic",
                "sns:GetTopicAttributes",
                "sns:Publish",
                "sns:SetTopicAttributes",
                "sns:SetSubscriptionAttributes",
                "sns:Subscribe",
                "sns:Unsubscribe"
            ],
            "Resource": [
                "arn:aws:sns:*:*:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:GetDashboard",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:PutDashboard",
                "cloudwatch:PutInsightRule",
                "cloudwatch:PutMetricAlarm",
                "cloudwatch:TagResource",
                "cloudwatch:GetMetricData",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:PutMetricData"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:Put*",
                "logs:Get*",
                "logs:Describe*",
                "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "events:Put*",
                "events:Create*",
                "events:List*",
                "events:Update*",
                "events:Describe*",
                "events:Put*",
                "events:ActivateEventSource",
                "events:RemoveTargets",
                "events:EnableRule",
                "events:DisableRule"
            ],
            "Resource": "*"
        },
        {
            "Sid": "ECRActions",
            "Effect": "Allow",
            "Action": [
                "ecr:BatchCheckLayerAvailability",
                "ecr:BatchGetImage",
                "ecr:CompleteLayerUpload",
                "ecr:CreateRepository",
                "ecr:GetAuthorizationToken",
                "ecr:GetDownloadUrlForLayer",
                "ecr:GetLifecyclePolicy",
                "ecr:GetLifecyclePolicyPreview",
                "ecr:GetRepositoryPolicy",
                "ecr:InitiateLayerUpload",
                "ecr:PutImage",
                "ecr:PutImageScanningConfiguration",
                "ecr:PutImageTagMutability",
                "ecr:PutLifecyclePolicy",
                "ecr:StartImageScan",
                "ecr:StartLifecyclePolicyPreview",
                "ecr:TagResource",
                "ecr:UploadLayerPart",
                "ecr:DeleteRepository"
            ],
            "Resource": [
                "arn:aws:ecr:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecr:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "s3:List*",
                "s3:Get*",
                "s3:Put*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-stg-cicd",
                "arn:aws:s3:::odp-us-aiml-stg-cicd/*"
            ]
        }
    ]
}
