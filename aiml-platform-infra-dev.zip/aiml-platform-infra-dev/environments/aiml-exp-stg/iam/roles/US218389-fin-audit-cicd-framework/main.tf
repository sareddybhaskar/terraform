provider "aws" {
  #version = ">= 3.0, < 4.0"
  #version = "~> 5.0"
  version = "6.2.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg/iam/US218389-fin-audit-cicd-framework/terraform.tfstate"
    region = "us-east-1"
  }
}



###### Local Template Files ######

data "template_file" "addon" {
  template = file("${path.module}/odp-us-aiml-stg-fin-audit-cicd-policy.json.tpl")
}

data "template_file" "cicd-logs-s3bucket" {
  template = file("${path.module}/odp-us-aiml-stg-cicd-logs-s3bucket-policy.json.tpl")
}

data "template_file" "cicd-common-role" {
  template = file("${path.module}/odp-us-aiml-stg-cicd-common-role-policy.json.tpl")
}

data "template_file" "cicd-common-api-deny" {
  template = file("${path.module}/odp-us-aiml-stg-cicd-common-api-deny-policy.json.tpl")
}
###### Creating IAM Policy ######

module "addon" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-stg-fin-audit-cicd-policy"
  path        = "/"
  description = "odp-us-aiml-stg-fin-audit-cicd-policy"

  policy = data.template_file.addon.rendered
}


module "cicd-logs-s3bucket" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-stg-cicd-logs-s3bucket-policy"
  path        = "/"
  description = "odp-us-aiml-stg-cicd-logs-s3bucket-policy"

  policy = "${data.template_file.cicd-logs-s3bucket.rendered}"
}

module "cicd-common-role" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-stg-cicd-common-role-policy"
  path        = "/"
  description = "odp-us-aiml-stg-cicd-common-role-policy"

  policy = "${data.template_file.cicd-common-role.rendered}"
}

module "cicd-common-api-deny" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-stg-cicd-common-api-deny-policy"
  path        = "/"
  description = "odp-us-aiml-stg-cicd-common-api-deny-policy"

  policy = "${data.template_file.cicd-common-api-deny.rendered}"
}


###### CICD Role ######

resource "aws_iam_role" "servicerole" {
  name        = "odp-us-aiml-stg-cicd-fin-audit-service-role"
  description = "odp-us-aiml-stg-cicd-fin-audit-service-role"

  assume_role_policy    = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": [
                    "scheduler.amazonaws.com",
                    "dynamodb.amazonaws.com",
                    "es.amazonaws.com",
                    "glue.amazonaws.com",
                    "sqs.amazonaws.com",
                    "s3.amazonaws.com",
                    "secretsmanager.amazonaws.com",
                    "cloudwatch.amazonaws.com",
                    "events.amazonaws.com",
                    "states.amazonaws.com",
                    "ecr.amazonaws.com",
                    "logs.amazonaws.com",
                    "sagemaker.amazonaws.com"                   
                ]
            },
            "Action": "sts:AssumeRole"
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::991497151145:user/NP700009040"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
  tags            = var.tags
}

###### Attaching Policies to CICD Role ######

resource "aws_iam_role_policy_attachment" "service1" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service2" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service3" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-stg-fin-audit-service-policy"
}

resource "aws_iam_role_policy_attachment" "service4" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.addon.arn
}

resource "aws_iam_role_policy_attachment" "service5" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.cicd-logs-s3bucket.arn
}

resource "aws_iam_role_policy_attachment" "service6" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.cicd-common-role.arn
}

resource "aws_iam_role_policy_attachment" "service7" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.cicd-common-api-deny.arn  
  }

######FSSO############

data "template_file" "fin-audit" {
  template = file("${path.module}/odp-us-aiml-stg-fin-audit-fsso-NP700009040-policy.json.tpl")
}

module "fin-audit_policy" {
  source      = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-stg-fin-audit-fsso-NP700009040-policy"
  path        = "/"
  description = "odp-us-aiml-stg-fin-audit-fsso-NP700009040-policy"

  policy      = "${data.template_file.fin-audit.rendered}"
}

module "fin-audit_fsso" {
  source                 = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/user_new?ref=dev"
  name                   = "NP700009040"
  create_iam_access_key  = true
  tags                   = var.tags
}

resource "aws_iam_user_policy_attachment" "iam_user_policy_attachment" {

  user       = module.fin-audit_fsso.this_iam_user_name
  policy_arn = module.fin-audit_policy.arn

}