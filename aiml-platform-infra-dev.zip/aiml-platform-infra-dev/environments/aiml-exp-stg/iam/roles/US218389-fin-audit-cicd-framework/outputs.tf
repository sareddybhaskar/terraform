output "cicd-role" {
  value = aws_iam_role.servicerole.name
}

output "user_name" {
  description = "The user's name"
  value       = module.fin-audit_fsso.this_iam_user_name
}

output "access_key_id" {
  description = "The access key ID"
  value       = module.fin-audit_fsso.this_iam_access_key_id
}

output "access_key_secret" {
  description = "The access key secret"
  value       = module.fin-audit_fsso.this_iam_access_key_secret
}