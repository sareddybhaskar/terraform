{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "cicdbucket",
            "Action": [
                "s3:List*",
                "s3:Get*",
                "s3:Put*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-stg-cicd",
                "arn:aws:s3:::odp-us-aiml-stg-cicd/*",
                "arn:aws:s3:::odp-us-aiml-stg-raw",
                "arn:aws:s3:::odp-us-aiml-stg-raw/*"
            ]
        }
    ]
}
