{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Resource": [
                "arn:aws:iam::991497151145:role/odp-us-aiml-stg-cicd-fin-audit-service-role",
                "arn:aws:iam::991497151145:role/odp-us-aiml-stg-fin-audit-service-role"
            ]
        }
    ]
}   