region      = "us-east-1"
environment = "aiml-exp-stg"

  tags = {
    Program        = "ODP"
    Environment    = "aiml-exp-stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml"
    Project        = "aiml-audit"
    Role           = "dt-aiml-audit-ds"
    ApplicationTag = "aiml-audit"
    UserStory      = "US218389"
    project_number = "ID7061:PR17653"
    purpose        = "inv_2025"
    Owner          = "Vivek.Agrawal1@gehealthcare.com"
    Contact        = "Health_ODP_CICD_Dev_Team@gehealthcare.com"
  }
