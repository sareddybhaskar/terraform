{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/3ah6i0mlxpw2",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0flpbpvvi5i2"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/3ah6i0mlxpw2",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0flpbpvvi5i2",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/r65x59v5vo88",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/bdrku0ojw9rw"                  
                        ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
                "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-2::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-west-2::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/3ah6i0mlxpw2",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0flpbpvvi5i2",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-6",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"

            ]
        }
    ],
    "Version": "2012-10-17"
}