##############Bedrock Models ##############

data "template_file" "user-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-pqm-quality-user-model-policy.json.tpl")

  vars = {
    # titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model1.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model2.arn
    # titan_image_generator_g1_v1_arn = aws_bedrock_inference_profile.model3.arn
    # titan_image_generator_g1_v2_arn = aws_bedrock_inference_profile.model4.arn
    # titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model5.arn
    # nova_pro_arn = aws_bedrock_inference_profile.model6.arn
    # claude_3_opus_arn = aws_bedrock_inference_profile.model7.arn
    # claude_3_haiku_arn = aws_bedrock_inference_profile.model8.arn
    # claude_3_5_sonnet_v2_arn = aws_bedrock_inference_profile.model9.arn
    # claude_3_5_haiku_arn = aws_bedrock_inference_profile.model10.arn
    # claude_3_5_sonnet_arn = aws_bedrock_inference_profile.model11.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model12.arn
    claude_sonnet_4_6_arn = aws_bedrock_inference_profile.model13.arn
    claude_sonnet_4_20250514_arn = aws_bedrock_inference_profile.model14.arn

}
}
# service model policy template
data "template_file" "service-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-pqm-quality-service-model-policy.json.tpl")

  vars = {
    # titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model1.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model2.arn
    # titan_image_generator_g1_v1_arn = aws_bedrock_inference_profile.model3.arn
    # titan_image_generator_g1_v2_arn = aws_bedrock_inference_profile.model4.arn
    # titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model5.arn
    # nova_pro_arn = aws_bedrock_inference_profile.model6.arn
    # claude_3_opus_arn = aws_bedrock_inference_profile.model7.arn
    # claude_3_haiku_arn = aws_bedrock_inference_profile.model8.arn
    # claude_3_5_sonnet_v2_arn = aws_bedrock_inference_profile.model9.arn
    # claude_3_5_haiku_arn = aws_bedrock_inference_profile.model10.arn
    # claude_3_5_sonnet_arn = aws_bedrock_inference_profile.model11.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model12.arn
    claude_sonnet_4_6_arn = aws_bedrock_inference_profile.model13.arn
    claude_sonnet_4_20250514_arn = aws_bedrock_inference_profile.model14.arn
  }
}

module "user-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-pqm-quality-user-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-pqm-quality-user-model-policy"

  policy = data.template_file.user-model-policy.rendered
}

module "service-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-pqm-quality-service-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-pqm-quality-service-model-policy"

  policy = data.template_file.service-model-policy.rendered
}

###### Bedrock Instance Profile ######

# resource "aws_bedrock_inference_profile" "model1" {
#   name        = "pqm-quality-titan-embeddings-g1-text"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-text-v1"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-titan-embeddings-g1-text"
#   }
# }

resource "aws_bedrock_inference_profile" "model2" {
  name        = "pqm-quality-titan-text-embeddings-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-text-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-titan-text-embeddings-v2"
    }
  )
}

# resource "aws_bedrock_inference_profile" "model3" {
#   name        = "pqm-quality-titan-image-generator-g1-v1"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-image-generator-v1"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-titan-image-generator-g1-v1"
#   }
# }

# resource "aws_bedrock_inference_profile" "model4" {
#   name        = "pqm-quality-titan-image-generator-g1-v2"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-image-generator-v2:0"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-titan-image-generator-g1-v2"
#   }
# }

# resource "aws_bedrock_inference_profile" "model5" {
#   name        = "pqm-quality-titan-multimodal-embeddings-g1"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-image-v1"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-titan-multimodal-embeddings-g1"
#   }
# }

# resource "aws_bedrock_inference_profile" "model6" {
#   name        = "pqm-quality-nova-pro"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0"
#     # copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.amazon.nova-pro-v1:0"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-nova-pro"
#   }
# }

# resource "aws_bedrock_inference_profile" "model7" {
#   name        = "pqm-quality-claude-3-opus"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-opus-20240229-v1:0"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-claude-3-opus"
#   }
# }

# resource "aws_bedrock_inference_profile" "model8" {
#   name        = "pqm-quality-claude-3-haiku"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/anthropic.claude-3-haiku-20240307-v1:0"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-claude-3-haiku"
#   }
# }

# resource "aws_bedrock_inference_profile" "model9" {
#   name        = "pqm-quality-claude-3-5-sonnet-v2"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-sonnet-20241022-v2:0"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-claude-3-5-sonnet-v2"
#   }
# }

# resource "aws_bedrock_inference_profile" "model10" {
#   name        = "pqm-quality-claude-3-5-haiku"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-claude-3-5-haiku"
#   }
# }

# resource "aws_bedrock_inference_profile" "model11" {
#   name        = "pqm-quality-claude-3-5-sonnet"

#   model_source {
#     copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0"
#   }

#   tags = {
#     App            = "aiml"
#     Project        = "aiml-pqm-quality"
#     Role           = "it-iscst-eng-quality"
#     Model          = "pqm-quality-claude-3-5-sonnet"
#   }
# }

resource "aws_bedrock_inference_profile" "model12" {
  name        = "pqm-quality-claude-3-7-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-claude-3-7-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model13" {
  name        = "pqm-quality-claude-sonnet-4-6"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-6"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-claude-sonnet-4-6"
    }
  )
}

resource "aws_bedrock_inference_profile" "model14" {
  name        = "pqm-quality-claude-sonnet-4-20250514"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "pqm-quality-claude-sonnet-4-20250514"
    }
  )
}   