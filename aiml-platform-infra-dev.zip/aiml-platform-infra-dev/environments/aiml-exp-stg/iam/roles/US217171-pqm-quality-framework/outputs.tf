output "login-role" {
  value = module.hc-ai-pqm-quality.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}

# output "pqm-quality-claude-sonnet-4-20250514" {
#   value = aws_bedrock_inference_profile.model14.arn
# }

# output "pqm-quality-claude-sonnet-4-6" {
#   value = aws_bedrock_inference_profile.model13.arn
# }