{
    "Statement": [        
       
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::*:role/odp-us-aiml-exp-stg-fin-revenue-service-role",
            "Sid": "Passrole"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject"                
            ],
            "Effect": "Allow",
            "Resource": [               
                "arn:aws:s3:::odp-us-aiml-exp-stg-fin-revenue",
                "arn:aws:s3:::odp-us-aiml-exp-stg-fin-revenue/*"
            ]
        },
                         {
            "Action": [
                "sns:ConfirmSubscription",
                "sns:CreateTopic",
                "sns:GetTopicAttributes",
                "sns:Publish",
                "sns:SetTopicAttributes",
                "sns:SetSubscriptionAttributes",
                "sns:Subscribe",
                "sns:Unsubscribe"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sns:*:*:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "scheduler:ListSchedules",
                "scheduler:ListScheduleGroups"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "redshift-data:GetStatementResult",
                "redshift-data:CancelStatement",
                "redshift-data:DescribeStatement",
                "redshift-data:ListStatements",
                "redshift-data:ListTables",
                "redshift-data:DescribeTable",
                "redshift-data:BatchExecuteStatement",
                "redshift-data:ListSchemas",
                "redshift-data:ExecuteStatement",
                "redshift-data:ListDatabases"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "glue:UpdateCrawlerSchedule",
                "glue:StartCrawler",
                "glue:StartCrawlerSchedule",
                "glue:StopCrawler",
                "glue:StopCrawlerSchedule",
                "glue:GetCrawler",
                "glue:GetCrawlers",
                "glue:UpdateCrawler",
                "glue:UpdateCrawler"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:glue:*:*:job/gehc_data*",
                "arn:aws:glue:*:*:crawler/*"
            ],
            "Sid": "Glue2"
        },
         {
            "Action": [
                "glue:SearchTables",
                "glue:GetDatabase",
                "glue:GetTables",
                "glue:GetDatabases",
                "glue:GetTable",
                "glue:GetPartitions",
                "glue:GetPartition"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:glue:*:*:database/gehc_data*",
                "arn:aws:glue:*:*:table/gehc_data/*",
                "arn:aws:glue:*:*:catalog"
            ],
            "Sid": "GlueTables"
        },
                {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:InvokeEndpoint",
                "sagemaker:Describe*",
                "sagemaker:List*",
                "sagemaker:Search",
                "sagemaker:AddTags"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/*/hc-ai-fin-revenue-user",
                "arn:aws:sagemaker:*:*:training-job/*",
                "arn:aws:sagemaker:*:*:space/*/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "ecr:BatchCheckLayerAvailability",
                "ecr:BatchGetImage",
                "ecr:CompleteLayerUpload",
                "ecr:GetAuthorizationToken",
                "ecr:GetDownloadUrlForLayer",
                "ecr:GetLifecyclePolicy",
                "ecr:GetLifecyclePolicyPreview",
                "ecr:GetRepositoryPolicy",
                "ecr:InitiateLayerUpload",
                "ecr:PutImage",
                "ecr:PutImageScanningConfiguration",
                "ecr:PutImageTagMutability",
                "ecr:PutLifecyclePolicy",
                "ecr:StartImageScan",
                "ecr:StartLifecyclePolicyPreview",
                "ecr:TagResource",
                "ecr:UploadLayerPart"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:ecr:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:ecr:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*"
            ],
            "Sid": "ECRActions"
        }  
       
    ],
    "Version": "2012-10-17"
}