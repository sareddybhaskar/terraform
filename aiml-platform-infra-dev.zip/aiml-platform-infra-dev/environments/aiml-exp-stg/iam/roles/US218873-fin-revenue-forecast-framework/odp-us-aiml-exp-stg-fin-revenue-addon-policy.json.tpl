{
    "Statement": [        
        {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:PutMetricData",
            "cloudwatch:GetMetricData",
            "cloudwatch:PutAnomalyDetector",
            "cloudwatch:GetMetricStatistics",
            "cloudwatch:GetMetricWidgetImage",
            "cloudwatch:PutManagedInsightRules"
        ],
         "Resource": "*"
        },
       {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:Put*",            
            "cloudwatch:TagResource",            
            "cloudwatch:GetDashboard",
            "cloudwatch:EnableAlarmActions",
            "cloudwatch:StopMetricStreams",
            "cloudwatch:GetInsightRuleReport",
            "cloudwatch:SetAlarmState",
            "cloudwatch:EnableInsightRules",
            "cloudwatch:StartMetricStreams"
        ],
         "Resource": [
            "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:insight-rule/*",
            "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
         ]
       },       
        {
            "Effect": "Allow",
            "Action": [
                "logs:Put*",
                "logs:Get*",
		        "logs:Describe*",
		        "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",				
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"				
            ],
            "Resource": [
		        "*"
            ]
        },
        {
            "Action": [
                "sqs:Get*",
                "sqs:List*",
                "sqs:ChangeMessageVisibility",
                "sqs:PurgeQueue",
                "sqs:ReceiveMessage",
                "sqs:SendMessage",
                "sqs:CreateQueue",
                "sqs:SetQueueAttributes"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:sqs:*:*:$${aws:PrincipalTag/ApplicationTag}*"
        },
        
         {
            "Action": [
                "sns:ConfirmSubscription",
                "sns:CreateTopic",
                "sns:GetTopicAttributes",
                "sns:Publish",
                "sns:SetTopicAttributes",
                "sns:SetSubscriptionAttributes",
                "sns:Subscribe",
                "sns:Unsubscribe"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sns:*:*:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "states:List*",
                "states:Describe*",
                "states:CreateActivity",
                "states:UpdateStateMachine",
                "states:StopExecution",
                "states:StartSyncExecution",
                "states:SendTaskSuccess",
                "states:SendTaskFailure",
                "states:GetExecutionHistory",
                "states:StartExecution",
                "states:SendTaskHeartbeat",
                "states:GetActivityTask",
                "states:CreateStateMachine"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:states:*:*:activity:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:states:*:*:execution:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:states:*:*:stateMachine:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "athena:TagResource",
                "athena:CreateDataCatalog",
                "athena:UpdateDataCatalog",
                "athena:GetTableMetadata",
                "athena:StartQueryExecution",
                "athena:GetQueryResultsStream",
                "athena:GetQueryResults",
                "athena:GetDatabase",
                "athena:GetDataCatalog",
                "athena:GetNamedQuery",
                "athena:ListTagsForResource",
                "athena:ListQueryExecutions",
                "athena:ListNamedQueries",
                "athena:GetWorkGroup",
                "athena:CreateNamedQuery",
                "athena:ListDatabases",
                "athena:StopQueryExecution",
                "athena:GetQueryExecution",
                "athena:BatchGetNamedQuery",
                "athena:ListTableMetadata",
                "athena:BatchGetQueryExecution"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:athena:us-east-1:991497151145:workgroup/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:athena:us-east-1:991497151145:datacatalog/*"
            ],
            "Sid": "athena"
        },
        {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "scheduler:ListSchedules",
                "scheduler:ListScheduleGroups"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "glue:SearchTables",
                "glue:GetDatabase",
                "glue:GetTables",
                "glue:GetDatabases",
                "glue:GetTable",
                "glue:GetPartitions",
                "glue:GetPartition"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:glue:*:*:database/gehc_data*",
                "arn:aws:glue:*:*:table/gehc_data/*",
                "arn:aws:glue:*:*:catalog"
            ],
            "Sid": "GlueTables"
        },
                {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:Get*",
                "s3:List*"
            ],
            "Resource": [
                "arn:aws:s3:::odp-us-prod-ds-isc-global",
                "arn:aws:s3:::odp-us-prod-ds-isc-global/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:Get*",
                "s3:Put*",
                "s3:List*"
            ],
            "Resource": "arn:aws:s3:::odp-fin-nprod-forecasting/*"
        }
       
    ],
    "Version": "2012-10-17"
}