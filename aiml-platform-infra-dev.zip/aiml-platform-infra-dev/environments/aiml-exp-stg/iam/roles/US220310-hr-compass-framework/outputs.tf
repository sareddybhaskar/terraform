output "login-role" {
  value = module.hc-ai-hr-compass-user.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}

