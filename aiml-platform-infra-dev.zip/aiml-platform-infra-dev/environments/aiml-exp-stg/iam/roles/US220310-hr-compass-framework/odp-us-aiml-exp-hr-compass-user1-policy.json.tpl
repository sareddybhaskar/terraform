{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "lambda:CreateFunction",
                "lambda:PublishLayerVersion",
                "lambda:InvokeAsync",
                "lambda:CreateEventSourceMapping",
                "lambda:RemoveLayerVersionPermission",
                "lambda:PutFunctionConcurrency",
                "lambda:EnableReplication",
                "lambda:DisableReplication",
                "lambda:PutFunctionEventInvokeConfig",
                "lambda:UpdateFunctionEventInvokeConfig",
                "lambda:UpdateEventSourceMapping",
                "lambda:InvokeFunction",
                "lambda:UpdateFunctionConfiguration",
                "lambda:AddLayerVersionPermission",
                "lambda:UpdateAlias",
                "lambda:UpdateFunctionCode",
                "lambda:AddPermission",
                "lambda:PutProvisionedConcurrencyConfig",
                "lambda:PublishVersion",
                "lambda:RemovePermission",
                "lambda:CreateAlias"
            ],
            "Resource": [
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:lambda:*:*:event-source-mapping:*"
            ]
        },
        {
            "Action": [
                "events:PutPartnerEvents",
                "events:RemovePermission",
                "events:PutPermission"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:events:*:*:rule/$${aws:PrincipalTag/ApplicationTag}*"
        },
        {
            "Action": [
                "events:TagResource",
                "events:Put*",
                "events:EnableRule",
                "events:RemoveTargets",
                "events:ActivateEventSource",
                "events:Create*",
                "events:UntagResource",
                "events:DisableRule",
                "events:DescribeRule"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:events:*:*:rule/*",
                "arn:aws:events:*:*:archive/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:connection/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:event-bus/default",
                "arn:aws:events:*:*:api-destination/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:endpoint/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*::event-source/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:events:*:*:rule/StepFunctionsGetEventsForStepFunctionsExecutionRule"
            ]
        },
        {
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricData",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutManagedInsightRules"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "cloudwatch:PutInsightRule",
                "cloudwatch:PutMetricAlarm",
                "cloudwatch:TagResource",
                "cloudwatch:PutDashboard",
                "cloudwatch:GetDashboard",
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:StopMetricStreams",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:SetAlarmState",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:StartMetricStreams"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": "cloudwatch:Put*",
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
      "Sid": "ManageCollections",
      "Effect": "Allow",
      "Action": [
        "aoss:CreateCollection",
        "aoss:ListCollections",
        "aoss:BatchGetCollection",
        "aoss:UpdateCollection",
        "aoss:CreateSecurityPolicy",
        "aoss:CreateAccessPolicy",
        "aoss:APIAccessAll",
        "aoss:Get*",
        "aoss:List*",
        "aoss:CreateIndex"
      ],
      "Resource": "*"
    },
    {
      "Sid": "ViewPoliciesAndAccountSettings",
      "Effect": "Allow",
      "Action": [
        "aoss:GetAccessPolicy",
        "aoss:GetSecurityPolicy",
        "aoss:ListAccessPolicies",
        "aoss:ListSecurityPolicies",
        "aoss:GetPoliciesStats",
        "aoss:GetAccountSettings",
        "aoss:ListTagsForResource"
      ],
      "Resource": "*"
    }          
    ]
}