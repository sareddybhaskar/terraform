##############Bedrock Models ##############

data "template_file" "user-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-hr-compass-user-model-policy.json.tpl")

  vars = {
    claude_4_5_haiku_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model2.arn
    claude_4_5_sonnet_arn = aws_bedrock_inference_profile.model3.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model4.arn
    nova_pro_arn = aws_bedrock_inference_profile.model5.arn
    claude_4_5_opus_arn = aws_bedrock_inference_profile.model6.arn
    titan_text_embeddings_v2_arn       = aws_bedrock_inference_profile.model7.arn
  }
}

# service model policy template
data "template_file" "service-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-hr-compass-service-model-policy.json.tpl")

  vars = {
    claude_4_5_haiku_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model2.arn
    claude_4_5_sonnet_arn = aws_bedrock_inference_profile.model3.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model4.arn
    nova_pro_arn = aws_bedrock_inference_profile.model5.arn
    claude_4_5_opus_arn = aws_bedrock_inference_profile.model6.arn
    titan_text_embeddings_v2_arn       = aws_bedrock_inference_profile.model7.arn
  }
}

module "user-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-hr-compass-user-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-hr-compass-user-model-policy"

  policy = data.template_file.user-model-policy.rendered
}

module "service-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-hr-compass-service-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-hr-compass-service-model-policy"

  policy = data.template_file.service-model-policy.rendered
}

###### Bedrock Instance Profile ######
resource "aws_bedrock_inference_profile" "model1" {
  name        = "hr-compass-claude-4-5-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0"
  }

    tags = merge(
    var.tags,
    {
      Model = "hr-compass-claude-4-5-haiku"
    }
  )
}

resource "aws_bedrock_inference_profile" "model2" {
  name        = "hr-compass-claude-3-5-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "hr-compass-claude-3-5-haiku"
    }
  )
}

resource "aws_bedrock_inference_profile" "model3" {
  name        = "hr-compass-claude-4-5-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-5-20250929-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "hr-compass-claude-4-5-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model4" {
  name        = "hr-compass-claude-3-7-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "hr-compass-claude-3-7-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model5" {
  name        = "hr-compass-nova-pro"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "hr-compass-nova-pro"
    }
  )
}

resource "aws_bedrock_inference_profile" "model6" {
  name        = "hr-compass-claude-4-5-opus"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-opus-4-5-20251101-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "hr-compass-claude-4-5-opus"
    }
  )
}

resource "aws_bedrock_inference_profile" "model7" {
  name        = "hr-compass-titan-text-embeddings-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "hr-compass-titan-text-embeddings-v2"
    }
  )
}