{
    "Statement": [
        {
            "Action": [
                "ecr:BatchCheckLayerAvailability",
                "ecr:BatchGetImage",
                "ecr:CompleteLayerUpload",
                "ecr:CreateRepository",
                "ecr:GetAuthorizationToken",
                "ecr:GetDownloadUrlForLayer",
                "ecr:GetLifecyclePolicy",
                "ecr:GetLifecyclePolicyPreview",
                "ecr:GetRepositoryPolicy",
                "ecr:InitiateLayerUpload",
                "ecr:PutImage",
                "ecr:PutImageScanningConfiguration",
                "ecr:PutImageTagMutability",
                "ecr:PutLifecyclePolicy",
                "ecr:StartImageScan",
                "ecr:StartLifecyclePolicyPreview",
                "ecr:TagResource",
                "ecr:UploadLayerPart",
                "ecr:DeleteRepository"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:ecr:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecr:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
            ],
            "Sid": "ECRActions"
        },        
        {
            "Action": [
                "kms:EnableKey",
                "kms:ImportKeyMaterial",
                "kms:Decrypt",
                "kms:PutKeyPolicy",
                "kms:GenerateDataKeyWithoutPlaintext",
                "kms:Verify",
                "kms:GenerateDataKeyPairWithoutPlaintext",
                "kms:DisableKey",
                "kms:GenerateDataKeyPair",
                "kms:ReEncryptFrom",
                "kms:DisableKeyRotation",
                "kms:Encrypt",
                "kms:GenerateDataKey",
                "kms:CreateGrant"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:kms:*:991497151145:key/$${aws:PrincipalTag/ApplicationTag}*",
            "Sid": "KMS"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-fin-prod-hr-compass/PBCS",  
                "arn:aws:s3:::odp-fin-prod-hr-compass/PBCS/*"
            ]
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-fin-prod-hr-compass/Alteryx",  
                "arn:aws:s3:::odp-fin-prod-hr-compass/Alteryx/*"
            ]
        },
        {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "scheduler:ListSchedules",
                "scheduler:ListScheduleGroups"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "lambda:CreateFunction",
                "lambda:PublishLayerVersion",
                "lambda:InvokeAsync",
                "lambda:CreateEventSourceMapping",
                "lambda:RemoveLayerVersionPermission",
                "lambda:PutFunctionConcurrency",
                "lambda:EnableReplication",
                "lambda:DisableReplication",
                "lambda:PutFunctionEventInvokeConfig",
                "lambda:UpdateFunctionEventInvokeConfig",
                "lambda:UpdateEventSourceMapping",
                "lambda:InvokeFunction",
                "lambda:UpdateFunctionConfiguration",
                "lambda:AddLayerVersionPermission",
                "lambda:UpdateAlias",
                "lambda:UpdateFunctionCode",
                "lambda:AddPermission",
                "lambda:PutProvisionedConcurrencyConfig",
                "lambda:PublishVersion",
                "lambda:RemovePermission",
                "lambda:CreateAlias"
            ],
            "Resource": [
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:lambda:*:*:*:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:lambda:*:*:event-source-mapping:*"
            ]
        },
        {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "scheduler:ListSchedules",
                "scheduler:ListScheduleGroups"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "bedrock:List*",
                "bedrock:Get*",
                "bedrock:InvokeAgent",
                "bedrock:CallWithBearerToken",
                "bedrock:InvokeInlineAgent",
                "bedrock:OptimizePrompt",
                "bedrock:RetrieveAndGenerate",
                "bedrock:ValidateFlowDefinition",
                "bedrock:GenerateQuery",
                "bedrock:CreateFlow",
                "bedrock:CreateAgent",
                "bedrock:CreatePrompt",
                "bedrock:CreateKnowledgeBase",
                "bedrock:InvokeModel",
                "bedrock:InvokeModelWithResponseStream"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
      "Sid": "ProvisionAndInspectHrCompassCollections",
      "Effect": "Allow",
      "Action": [
        "aoss:CreateCollection",
        "aoss:ListCollections",
        "aoss:BatchGetCollection",
        "aoss:UpdateCollection",
        "aoss:ReadDocument",
        "aoss:WriteDocument"
      ],
      "Resource": "*",
      "Condition": {
        "StringLike": {
          "aoss:collection": "$${aws:PrincipalTag/ApplicationTag}*"
        }
      }
    },
    {
  "Sid": "AllowListCollectionsForHrCompass",
  "Effect": "Allow",
  "Action": [
    "aoss:ListCollections",
    "aoss:BatchGetCollection",
    "aoss:ReadDocument",
    "aoss:WriteDocument"
  ],
  "Resource": "*",
  "Condition": {
    "ArnLike": {
      "aws:PrincipalArn": [ 
      "arn:aws:iam::991497151145:role/odp-us-aiml-exp-hr-compass-service-role"
      ]
    }
  }
},
    {
      "Sid": "HrCompassCollectionDataPlane",
      "Effect": "Allow",
      "Action": [
        "aoss:ReadDocument",
        "aoss:WriteDocument",
        "aoss:UpdateDocument"
      ],
      "Resource": "arn:aws:aoss:us-east-1:991497151145:collection/npmgl0txhpjlqrwmmnv4"
    },
    {
      "Sid": "DataPlaneForHrCompassCollections",
      "Effect": "Allow",
      "Action": [
        "aoss:APIAccessAll"
      ],
      "Resource": [
        "arn:aws:aoss:us-east-1:991497151145:collection/*"
      ],
      "Condition": {
        "StringLike": {
          "aoss:collection": "$${aws:PrincipalTag/ApplicationTag}*"
        }
      }
    }                   
    ],
    "Version": "2012-10-17"
}