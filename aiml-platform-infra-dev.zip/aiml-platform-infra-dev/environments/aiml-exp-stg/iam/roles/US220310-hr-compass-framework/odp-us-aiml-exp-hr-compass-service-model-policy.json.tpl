{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/lvennehco5z9",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/4jk06n94as2e",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0gjcit5kas5n",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/r6vmqetcg18y",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/yb77n1pdc7gb",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/6lgblv051bwi",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/n54bdscp8f2o",
		"arn:aws:bedrock:*::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-4-5-sonnet-20250219-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-opus-4-5-20251101-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
		"arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-4-5-sonnet-20250219-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-opus-4-5-20251101-v1:0"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/lvennehco5z9",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/4jk06n94as2e",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0gjcit5kas5n",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/r6vmqetcg18y",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/yb77n1pdc7gb",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/6lgblv051bwi",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/n54bdscp8f2o",
		"arn:aws:bedrock:*::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-4-5-sonnet-20250219-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-opus-4-5-20251101-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
		"arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-4-5-sonnet-20250219-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-opus-4-5-20251101-v1:0"
						
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-4-5-sonnet-20250219-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-opus-4-5-20251101-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-4-5-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-opus-4-5-20251101-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/lvennehco5z9",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/4jk06n94as2e",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0gjcit5kas5n",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/r6vmqetcg18y",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/yb77n1pdc7gb",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/6lgblv051bwi",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/n54bdscp8f2o"
            ]
        }
    ],
    "Version": "2012-10-17"
}