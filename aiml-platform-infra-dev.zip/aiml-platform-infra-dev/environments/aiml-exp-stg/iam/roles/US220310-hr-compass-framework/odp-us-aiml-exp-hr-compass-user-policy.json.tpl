{
    "Statement": [
        {
            "Action": [
                "logs:Put*",
                "logs:Get*",
                "logs:Describe*",
                "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"
            ],
            "Effect": "Allow",
            "Resource": [
                "*"
            ]
        },
        {
            "Action": [
                "states:List*",
                "states:Describe*",
                "states:CreateActivity",
                "states:UpdateStateMachine",
                "states:StopExecution",
                "states:StartSyncExecution",
                "states:SendTaskSuccess",
                "states:SendTaskFailure",
                "states:GetExecutionHistory",
                "states:StartExecution",
                "states:SendTaskHeartbeat",
                "states:GetActivityTask",
                "states:CreateStateMachine",
                "states:RedriveExecution"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:states:*:*:activity:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:states:*:*:execution:$${aws:PrincipalTag/ApplicationTag}*:*",
                "arn:aws:states:*:*:stateMachine:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "sns:ConfirmSubscription",
                "sns:CreateTopic",
                "sns:GetTopicAttributes",
                "sns:Publish",
                "sns:SetTopicAttributes",
                "sns:SetSubscriptionAttributes",
                "sns:Subscribe",
                "sns:Unsubscribe"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sns:*:*:$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "ecr:BatchCheckLayerAvailability",
                "ecr:BatchGetImage",
                "ecr:CompleteLayerUpload",
                "ecr:CreateRepository",
                "ecr:GetAuthorizationToken",
                "ecr:GetDownloadUrlForLayer",
                "ecr:GetLifecyclePolicy",
                "ecr:GetLifecyclePolicyPreview",
                "ecr:GetRepositoryPolicy",
                "ecr:InitiateLayerUpload",
                "ecr:PutImage",
                "ecr:PutImageScanningConfiguration",
                "ecr:PutImageTagMutability",
                "ecr:PutLifecyclePolicy",
                "ecr:StartImageScan",
                "ecr:StartLifecyclePolicyPreview",
                "ecr:TagResource",
                "ecr:UploadLayerPart",
                "ecr:DeleteRepository"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:ecr:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecr:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
            ],
            "Sid": "ECRActions"
        },
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::*:role/odp-us-aiml-exp-hr-compass-service-role",
            "Sid": "Passrole"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-aiml-exp-stg-hr-compass",
                "arn:aws:s3:::odp-us-aiml-exp-stg-hr-compass/*"
            ]
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-us-prod-hr-downstream/compass",
                "arn:aws:s3:::odp-us-prod-hr-downstream/compass/*"
            ]
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:InvokeEndpoint",
                "sagemaker:Describe*",
                "sagemaker:List*",
                "sagemaker:Search",
                "sagemaker:AddTags"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*"
            ]
        },
        {
            "Action": [
                "glue:StartJobRun",
                "glue:BatchStopJobRun"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:glue:*:*:job/$${aws:PrincipalTag/ApplicationTag}*",
            "Sid": "VisualEditor0"
        },
        {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ],
            "Sid": "AccessSecret"
        },
        {
            "Action": [
                "kms:EnableKey",
                "kms:ImportKeyMaterial",
                "kms:Decrypt",
                "kms:PutKeyPolicy",
                "kms:GenerateDataKeyWithoutPlaintext",
                "kms:Verify",
                "kms:GenerateDataKeyPairWithoutPlaintext",
                "kms:DisableKey",
                "kms:GenerateDataKeyPair",
                "kms:ReEncryptFrom",
                "kms:DisableKeyRotation",
                "kms:Encrypt",
                "kms:GenerateDataKey",
                "kms:CreateGrant"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:kms:*:991497151145:key/$${aws:PrincipalTag/ApplicationTag}*",
            "Sid": "KMS"
        },
        {
            "Action": [
                "athena:TagResource",
                "athena:CreateDataCatalog",
                "athena:UpdateDataCatalog",
                "athena:GetTableMetadata",
                "athena:StartQueryExecution",
                "athena:GetQueryResultsStream",
                "athena:GetQueryResults",
                "athena:GetDatabase",
                "athena:GetDataCatalog",
                "athena:GetNamedQuery",
                "athena:ListTagsForResource",
                "athena:ListQueryExecutions",
                "athena:ListNamedQueries",
                "athena:GetWorkGroup",
                "athena:CreateNamedQuery",
                "athena:ListDatabases",
                "athena:StopQueryExecution",
                "athena:GetQueryExecution",
                "athena:BatchGetNamedQuery",
                "athena:ListTableMetadata",
                "athena:BatchGetQueryExecution"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:athena:us-east-1:*:workgroup/*",
                "arn:aws:athena:*:*:datacatalog/*"
            ]
        },
        {
            "Action": [
                "bedrock:List*",
                "bedrock:Get*",
                "bedrock:InvokeAgent",
                "bedrock:CallWithBearerToken",
                "bedrock:InvokeInlineAgent",
                "bedrock:OptimizePrompt",
                "bedrock:RetrieveAndGenerate",
                "bedrock:ValidateFlowDefinition",
                "bedrock:GenerateQuery",
                "bedrock:CreateFlow",
                "bedrock:CreateAgent",
                "bedrock:CreatePrompt",
                "bedrock:CreateKnowledgeBase",
                "bedrock:InvokeModel",
                "bedrock:InvokeModelWithResponseStream"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-opus-4-5-20251101-v1:0"                
        },
        {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "scheduler:ListSchedules",
                "scheduler:ListScheduleGroups"
            ],
            "Effect": "Allow",
            "Resource": "*"
        }        
    ],
    "Version": "2012-10-17"
}