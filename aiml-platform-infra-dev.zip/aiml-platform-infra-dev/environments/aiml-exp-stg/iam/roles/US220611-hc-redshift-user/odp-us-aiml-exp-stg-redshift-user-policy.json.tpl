{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "s3:ListBucketMultipartUploads",
                "s3:ListAllMyBuckets",
                "s3:ListBucketVersions",
                "s3:ListBucket",
                "s3:GetBucket*",
                "redshift:GetClusterCredentials",
                "redshift:List*",
                "redshift:ViewQueriesInConsole",
                "redshift:FetchResults",
                "redshift:ViewQueriesFromConsole",
                "support:*",
                "redshift:Describe*",
                "redshift:ExecuteQuery",
                "redshift:GetReservedNodeExchangeOfferings",
                "trustedadvisor:Describe*",
                "autoscaling:Describe*",
                "cloudwatch:Describe*",
                "cloudwatch:Get*",
                "cloudwatch:List*",
                "logs:Get*",
                "logs:List*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:Describe*",
                "logs:TestMetricFilter",
                "logs:FilterLogEvents",
                "sns:Get*",
                "sns:List*",
                "rds:Describe*",
                "rds:List*",
                "ec2:Describe*",
                "events:Describe*",
                "events:List*",
                "events:TestEventPattern",
                "rds:DownloadDBLogFilePortion"
            ],
            "Resource": "*"
        },
        {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:secretsmanager:*:*:secret:*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "pi:GetResourceMetrics"
            ],
            "Resource": "*"
        },
        {
            "Action": [
                "ssm:Describe*",
                "ssm:Get*",
                "ssm:List*"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricData",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutManagedInsightRules",
                "cloudwatch:PutDashboard*",
                "cloudwatch:GetDashboard*"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "cloudwatch:PutInsightRule",
                "cloudwatch:PutMetricAlarm",
                "cloudwatch:TagResource",
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:StopMetricStreams",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:SetAlarmState",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:StartMetricStreams",
                "cloudwatch:PutDashboard",
                "cloudwatch:GetDashboard"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch::*:dashboard/*"
            ]
        },
        {
            "Action": [
                "redshift-data:BatchExecuteStatement",
                "redshift-data:ExecuteStatement",
                "redshift-data:CancelStatement",
                "redshift-data:ListStatements",
                "redshift-data:GetStatementResult",
                "redshift-data:DescribeStatement",
                "redshift-data:ListDatabases",
                "redshift-data:ListSchemas",
                "redshift-data:ListTables",
                "redshift-data:DescribeTable"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "DataAPIPermissions"
        },
        {
            "Action": [
                "redshift-data:GetStatementResult",
                "redshift-data:CancelStatement",
                "redshift-data:DescribeStatement",
                "redshift-data:ListStatements"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "DataAPIPermissions1"
        }
    ]
}