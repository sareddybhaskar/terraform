output "login-role" {
  value = module.hc-redshift-user.role_name
}