region      = "us-east-1"
environment = "aiml-exp-stg"

  tags = {
    Project       = "aiml-isc-logistics"
    Program       = "ODP"
    Environment    = "Prod"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App            = "aiml"
    Role           = "dt-aiml-isc-logistics-ds"
    Name           = "odp-us-aiml-exp-stg-isc-logistics"
    ApplicationTag = "isc-logistics"
    project_number = "ID5846:PR15788"
    purpose        = "inv_2025"
    UserStory      = "US218886"
    Owner          = "Philippe.Peloquin@gehealthcare.com"
  }
