{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/f6f5ax6luwhf",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0o7wgkrioqmo",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8sury2783uv0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/osoop0930rk5",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/qh7pb5w74hsh"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/f6f5ax6luwhf",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0o7wgkrioqmo",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8sury2783uv0",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/osoop0930rk5",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/qh7pb5w74hsh"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-sonnet-4-5-20250929-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-haiku-4-5-20251001-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-4-5-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/f6f5ax6luwhf",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/0o7wgkrioqmo",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8sury2783uv0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/osoop0930rk5",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/qh7pb5w74hsh"
            ]
        }
    ],
    "Version": "2012-10-17"
}