{
    "Statement": [
        {
            "Action": [
                "kms:EnableKey",
                "kms:ImportKeyMaterial",
                "kms:Decrypt",
                "kms:PutKeyPolicy",
                "kms:GenerateDataKeyWithoutPlaintext",
                "kms:Verify",
                "kms:GenerateDataKeyPairWithoutPlaintext",
                "kms:DisableKey",
                "kms:GenerateDataKeyPair",
                "kms:ReEncryptFrom",
                "kms:DisableKeyRotation",
                "kms:Encrypt",
                "kms:GenerateDataKey",
                "kms:CreateGrant"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:kms:*:991497151145:key/$${aws:PrincipalTag/ApplicationTag}*",
            "Sid": "KMS"
        },
        {
            "Action": [
                "ecr:BatchCheckLayerAvailability",
                "ecr:BatchGetImage",
                "ecr:CompleteLayerUpload",
                "ecr:CreateRepository",
                "ecr:GetAuthorizationToken",
                "ecr:GetDownloadUrlForLayer",
                "ecr:GetLifecyclePolicy",
                "ecr:GetLifecyclePolicyPreview",
                "ecr:GetRepositoryPolicy",
                "ecr:InitiateLayerUpload",
                "ecr:PutImage",
                "ecr:PutImageScanningConfiguration",
                "ecr:PutImageTagMutability",
                "ecr:PutLifecyclePolicy",
                "ecr:StartImageScan",
                "ecr:StartLifecyclePolicyPreview",
                "ecr:TagResource",
                "ecr:UploadLayerPart",
                "ecr:DeleteRepository"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:ecr:*:*:*:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:ecr:*:*:*/$${aws:PrincipalTag/ApplicationTag}*"
            ],
            "Sid": "ECRActions"
        },
         {
      "Action": [
        "bedrock:InvokeFlow",
        "bedrock:UpdateFlowAlias",
        "bedrock:StopEvaluationJob",
        "bedrock:PrepareFlow",
        "bedrock:UpdateAgentAlias",
        "bedrock:DetectGeneratedContent",
        "bedrock:InvokeDataAutomationAsync",
        "bedrock:CreateInferenceProfile",
        "bedrock:UpdateAgent",
        "bedrock:Retrieve",
        "bedrock:CreateAgentActionGroup",
        "bedrock:UpdateAgentKnowledgeBase",
        "bedrock:AssociateAgentCollaborator",
        "bedrock:DisassociateAgentCollaborator",
        "bedrock:UpdateDataAutomationProject",
        "bedrock:ApplyGuardrail",
        "bedrock:CreateEvaluationJob",
        "bedrock:UpdateAgentActionGroup",
        "bedrock:UpdateKnowledgeBase",
        "bedrock:CreateModelEvaluationJob",
        "bedrock:DisassociateAgentKnowledgeBase",
        "bedrock:CreateFlowVersion",
        "bedrock:CreateGuardrailVersion",
        "bedrock:UpdateFlow",
        "bedrock:CreateDataAutomationProject",
        "bedrock:UpdateAgentCollaborator",
        "bedrock:IngestKnowledgeBaseDocuments",
        "bedrock:AssociateAgentKnowledgeBase",
        "bedrock:RenderPrompt",
        "bedrock:CreateFlowAlias",
        "bedrock:CreatePromptRouter",
        "bedrock:StartFlowExecution",
        "bedrock:CreateAgentAlias",
        "bedrock:CreateGuardrail",
        "bedrock:PrepareAgent",
        "bedrock:UpdateGuardrail",
        "bedrock:StopFlowExecution",
        "bedrock:CreatePromptVersion",
        "bedrock:StopFlowExecution",
        "bedrock:RenderPrompt",
        "bedrock:UpdatePrompt"
      ],
      "Effect": "Allow",
      "Resource": [
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*",
        "arn:aws:bedrock:*::*/$${aws:PrincipalTag/ApplicationTag}*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*:*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*",
        "arn:aws:bedrock:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/alias/*/execution/*",
        "arn:aws:bedrock:*:*:marketplace/model-endpoint/all-access",
        "arn:aws:bedrock:*:*:agent-alias/*/*",
        "arn:aws:bedrock:*:*:*/*"
      ]
    },
    {
      "Action": [
        "bedrock:List*",
        "bedrock:Get*",
        "bedrock:InvokeAgent",
        "bedrock:CallWithBearerToken",
        "bedrock:InvokeInlineAgent",
        "bedrock:OptimizePrompt",
        "bedrock:RetrieveAndGenerate",
        "bedrock:ValidateFlowDefinition",
        "bedrock:GenerateQuery",
        "bedrock:CreateFlow",
        "bedrock:CreateAgent",
        "bedrock:CreatePrompt",
        "bedrock:CreateKnowledgeBase"
      ],
      "Effect": "Allow",
      "Resource": "*"
        },
        {
            "Action": [
                "scheduler:GetSchedule",
                "scheduler:UpdateSchedule",
                "scheduler:CreateSchedule",
                "scheduler:GetScheduleGroup"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:scheduler:*:*:schedule-group/default",
                "arn:aws:scheduler:*:*:schedule/default/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "scheduler:ListSchedules",
                "scheduler:ListScheduleGroups"
            ],
            "Effect": "Allow",
            "Resource": "*"
        }
    ],
    "Version": "2012-10-17"
}