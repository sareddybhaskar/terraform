provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
  # profile = "aiml-exp-stg-power-user"
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg/iam/roles/cloud-ops-team/hc-cloud-L3/terraform.tfstate"
    region = "us-east-1"
  }
}

data "template_file" "cloud_deny" {
  template = file("${path.module}/odp-us-aiml-exp-stg-cloud-deny-policy.json.tpl")
}

data "template_file" "cloud_L3_iam" {
  template = file("${path.module}/odp-us-aiml-exp-stg-cloud-l3-iam-policy.json.tpl")
}

data "template_file" "cloud_L3_user" {
  template = file("${path.module}/odp-us-aiml-exp-stg-cloud-l3-user-policy.json.tpl")
}

data "template_file" "cloud_policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-cloud-L3-cloud-policy.json.tpl")
}

data "template_file" "role_policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-cloud-L3-user-policy.json.tpl")
}

module "cloud_deny" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-cloud-deny-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-cloud-deny-policy"

  policy = "${data.template_file.cloud_deny.rendered}"
}

module "cloud_L3_iam" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-cloud-l3-iam-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-cloud-l3-iam-policy"

  policy = "${data.template_file.cloud_L3_iam.rendered}"
}

module "cloud_L3_user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-cloud-l3-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-cloud-l3-user-policy"

  policy = "${data.template_file.cloud_L3_user.rendered}"
}

module "cloud_policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-cloud-L3-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-cloud-L3-cloud-policy"

  policy = "${data.template_file.cloud_policy.rendered}"
}

module "role_policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-cloud-L3-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-cloud-L3-user-policy"

  policy = "${data.template_file.role_policy.rendered}"
}

module "hc-cloud-L3" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-cloud-L3"
  role_description      = "hc-cloud-L3"
  environment           = var.environment
  region                = var.region
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = module.cloud_deny.arn
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-deny-other-regions-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-cloud-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-tag-editor-policy"
}

resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user6" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user7" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy"
}

resource "aws_iam_role_policy_attachment" "user8" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
}

resource "aws_iam_role_policy_attachment" "user9" {
  role       = module.hc-cloud-L3.role_name
  policy_arn = module.cloud_L3_iam.arn
}