output "hc-cloud-l3" {
  value = module.hc-cloud-L3.role_name
}