{
    "Statement": [
        {
            "Action": "sts:AssumeRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::991497151145:role/hc-cloud-L2",
            "Sid": "assumerole"
        }
    ],
    "Version": "2012-10-17"
}