region = "us-east-1"
environment = "aiml-exp-stg"
tags = {
    Project       = "odp"
    Program       = "ODP"
    Environment = "aiml-exp-stg"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3053026"
    App = "cloud-ops"
    Role = "dt-dna"
    ApplicationTag = "us-dev-cloud"
    role_name = "hc-cloud-L2"
  }

  