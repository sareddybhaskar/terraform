provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
  # profile = "aiml-exp-stg-power-user"
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg/iam/roles/cloud-ops-team/hc-hcl-cloud-L1/terraform.tfstate"
    region = "us-east-1"
  }
}

data "template_file" "cloud-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-hcl-cloud-L1-cloud-policy.json.tpl")
}

data "template_file" "role-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-hcl-cloud-L1-user-policy.json.tpl")
}

data "template_file" "user" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hcl-cloud-L1-user-policy.json.tpl")
}

module "cloud-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-hcl-cloud-L1-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-cloud-policy"

  policy = "${data.template_file.cloud-policy.rendered}"
}

module "role-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-hcl-cloud-L1-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-role-policy-policy"

  policy = "${data.template_file.role-policy.rendered}"
}

module "user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hcl-cloud-L1-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hcl-cloud-L1-user-policy"

  policy = "${data.template_file.user.rendered}"
}

module "hc-hcl-cloud-L1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-hcl-cloud-L1"
  role_description      = "hc-hcl-cloud-L1"
  environment           = var.environment
  region                = var.region
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-udev-hc-hcl-cloud-L1_bbec27ca2892bb9e"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = module.user.arn
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-deny-other-regions-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-cloud-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-tag-editor-policy"
}

resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user6" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user7" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy"
}

resource "aws_iam_role_policy_attachment" "user8" {
  role       = module.hc-hcl-cloud-L1.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
}

