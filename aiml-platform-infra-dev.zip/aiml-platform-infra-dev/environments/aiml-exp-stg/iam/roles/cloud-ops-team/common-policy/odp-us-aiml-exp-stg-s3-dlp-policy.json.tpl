{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Deny",
            "Action": [
                "s3:GetObject"
            ],
            "Resource": [
                "arn:aws:s3:::*/*"
            ],
            "Condition": {
                "ForAnyValue:StringNotEquals": {
                    "aws:CalledVia": [
                        "athena.amazonaws.com",
                        "lambda.amzonaws.com",
                        "elasticmapreuce.amazonaws.com",
                        "sagemaker.amazonaws.com",
                        "sts.amazonaws.com",
                        "glue.amazonaws.com",
                        "s3.amazonaws.com",
                        "textract.amazonaws.com",
                        "bedrock.amazonaws.com"
                    ]
                }
            }
        }
    ]
}