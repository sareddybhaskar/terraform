{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "DenyAllOutsideRequestedRegions",
            "Effect": "Deny",
            "Action": [
                "athena:*",
                "databrew:*",
                "states:*",
                "sns:*",
                "glue:*",
                "sagemaker:*",
                "lambda:*",
                "cloudwatch:*",
                "events:*",
                "logs:*",
                "secretsmanager:*",
                "sqs:*",
                "dynamodb:*",
                "ecr:*",
                "ecs:*",
                "elasticfilesystem:*",
                "redshift:*",
                "kinesis:*",
                "eks:*",
                "timestream:*",
                "rds:*",
                "s3:*"
            ],
            "Resource": "*",
            "Condition": {
                "StringNotEquals": {
                    "aws:RequestedRegion": [
                        "us-east-1"
                    ]
                }
            }
        }
    ]
}