{
    "Statement": [
        {
            "Action": [
                "s3:CreateBucket"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::aws-glue-*"
            ],
            "Sid": "S3Bucket"
        },
        {
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:secretsmanager:*:*:secret:$${aws:PrincipalTag/ApplicationTag}*"
            ],
            "Sid": "secretsmanager"
        },
        {
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::aws-glue-*/*",
                "arn:aws:s3:::*/*aws-glue-*/*"
            ],
            "Sid": "S3Bucket1"
        },
        {
            "Action": [
                "s3:GetObject"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::crawler-public*",
                "arn:aws:s3:::aws-glue-*"
            ],
            "Sid": "S3Bucket3"
        },
        {
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:logs:*:*:/aws-glue/*"
            ],
            "Sid": "Logs"
        },
        {
            "Action": [
                "ec2:CreateTags",
                "ec2:DeleteTags"
            ],
            "Condition": {
                "ForAllValues:StringEquals": {
                    "aws:TagKeys": [
                        "aws-glue-service-resource"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:ec2:*:*:network-interface/*",
                "arn:aws:ec2:*:*:security-group/*",
                "arn:aws:ec2:*:*:instance/*"
            ],
            "Sid": "EC2"
        },
        {
            "Action": [
                "glue:BatchCreatePartition",
                "glue:BatchDeleteConnection",
                "glue:BatchDeletePartition",
                "glue:BatchDeleteTable",
                "glue:BatchDeleteTableVersion",
                "glue:BatchGetPartition",
                "glue:BatchStopJobRun",
                "glue:BatchUpdatePartition",
                "glue:CreateConnection",
                "glue:CreateDatabase",
                "glue:CreatePartition",
                "glue:CreatePartitionIndex",
                "glue:CreateTable",
                "glue:CreateUserDefinedFunction",
                "glue:DeleteColumnStatisticsForPartition",
                "glue:DeleteColumnStatisticsForTable",
                "glue:DeletePartition",
                "glue:DeletePartitionIndex",
                "glue:DeleteTable",
                "glue:DeleteTableVersion",
                "glue:DeleteUserDefinedFunction",
                "glue:GetColumnStatisticsForPartition",
                "glue:GetColumnStatisticsForTable",
                "glue:GetDatabase",
                "glue:ImportCatalogToGlue",
                "glue:PutDataCatalogEncryptionSettings",
                "glue:StartCrawler",
                "glue:StopCrawler",
                "glue:UpdateColumnStatisticsForPartition",
                "glue:UpdateColumnStatisticsForTable",
                "glue:UpdateConnection",
                "glue:UpdateCrawler",
                "glue:UpdateDatabase",
                "glue:UpdateDevEndpoint",
                "glue:UpdateJob",
                "glue:UpdatePartition",
                "glue:UpdateTable",
                "glue:UpdateUserDefinedFunction"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:glue:*:*:*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:glue:*:*:job/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:glue:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/*",
                "arn:aws:glue:*:*:catalog",
                "arn:aws:glue:*:991497151145:database/default",
                "arn:aws:glue:*:991497151145:table/default/*"
            ],
            "Sid": "Glue1"
        },
        {
            "Action": [
                "glue:CancelMLTaskRun",
                "glue:CancelStatement",
                "glue:CreateBlueprint",
                "glue:CreateClassifier",
                "glue:CreateCrawler",
                "glue:CreateCustomEntityType",
                "glue:CreateDevEndpoint",
                "glue:CreateJob",
                "glue:CreateMLTransform",
                "glue:CreateRegistry",
                "glue:CreateSchema",
                "glue:CreateScript",
                "glue:CreateSecurityConfiguration",
                "glue:CreateSession",
                "glue:CreateTrigger",
                "glue:CreateWorkflow",
                "glue:NotifyEvent",
                "glue:PutSchemaVersionMetadata",
                "glue:PutWorkflowRunProperties",
                "glue:RegisterSchemaVersion",
                "glue:RemoveSchemaVersionMetadata",
                "glue:ResetJobBookmark",
                "glue:ResumeWorkflowRun",
                "glue:RunStatement",
                "glue:StartBlueprintRun",
                "glue:StartCrawlerSchedule",
                "glue:StartExportLabelsTaskRun",
                "glue:StartImportLabelsTaskRun",
                "glue:StartMLEvaluationTaskRun",
                "glue:StartMLLabelingSetGenerationTaskRun",
                "glue:StartTrigger",
                "glue:StartWorkflowRun",
                "glue:StopCrawlerSchedule",
                "glue:StopSession",
                "glue:StopTrigger",
                "glue:StopWorkflowRun",
                "glue:StartJobRun",
                "glue:TagResource",
                "glue:UntagResource",
                "glue:UpdateBlueprint",
                "glue:UpdateClassifier",
                "glue:UpdateCrawlerSchedule",
                "glue:UpdateMLTransform",
                "glue:UpdateRegistry",
                "glue:UpdateSchema",
                "glue:UpdateTrigger",
                "glue:UpdateWorkflow",
                "glue:UseMLTransforms"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "Glue2"
        },
        {
            "Action": [
                "events:PutTargets",
                "events:PutRule",
                "events:DescribeRule"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:events:us-east-1:991497151145:rule/StepFunctionsGetEventsForStepFunctionsExecutionRule"
            ],
            "Sid": "Events"
        }
    ],
    "Version": "2012-10-17"
}