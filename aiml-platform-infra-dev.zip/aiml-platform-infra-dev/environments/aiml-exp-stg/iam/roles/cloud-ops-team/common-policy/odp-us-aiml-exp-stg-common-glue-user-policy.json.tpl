{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:CreateBucket"
            ],
            "Resource": [
                "arn:aws:s3:::aws-glue-*"
            ]
        },
        {
            "Action": [
                "s3:List*",
                "s3:Get*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::odp-fin-nprod-arc-sensitive/mirror_staging/file_ingestion/ghc_arcs",
                "arn:aws:s3:::odp-fin-nprod-arc-sensitive/mirror_staging/file_ingestion/ghc_arcs/*"
            ],
            "Sid": "S3"
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::aws-glue-*/*",
                "arn:aws:s3:::*/*aws-glue-*/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject"
            ],
            "Resource": [
                "arn:aws:s3:::crawler-public*",
                "arn:aws:s3:::aws-glue-*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": [
                "arn:aws:logs:*:*:/aws-glue/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:CreateTags",
                "ec2:DeleteTags"
            ],
            "Condition": {
                "ForAllValues:StringEquals": {
                    "aws:TagKeys": [
                        "aws-glue-service-resource"
                    ]
                }
            },
            "Resource": [
                "arn:aws:ec2:*:*:network-interface/*",
                "arn:aws:ec2:*:*:security-group/*",
                "arn:aws:ec2:*:*:instance/*"
            ]
        },
        {
            "Sid": "Glue1",
            "Effect": "Allow",
            "Action": [
                "glue:BatchCreatePartition",
                "glue:BatchDeletePartition",
                "glue:BatchGetPartition",
                "glue:BatchStopJobRun",
                "glue:BatchUpdatePartition",
                "glue:CreateDatabase",
                "glue:CreatePartition",
                "glue:CreatePartitionIndex",
                "glue:CreateTable",
                "glue:CreateUserDefinedFunction",
                "glue:DeletePartition",
                "glue:DeletePartitionIndex",
                "glue:GetColumnStatisticsForPartition",
                "glue:GetColumnStatisticsForTable",
                "glue:GetDatabase",
                "glue:GetDatabases",
                "glue:GetPartition",
                "glue:GetPartitionIndexes",
                "glue:GetPartitions",
                "glue:GetTable",
                "glue:GetTableVersion",
                "glue:GetTableVersions",
                "glue:GetTables",
                "glue:PutDataCatalogEncryptionSettings",
                "glue:SearchTables",
                "glue:StartCrawler",
                "glue:StartJobRun",
                "glue:StartTrigger",
                "glue:StartWorkflowRun",
                "glue:StopCrawler",
                "glue:StopSession",
                "glue:StopTrigger",
                "glue:StopWorkflowRun",
                "glue:TagResource",
                "glue:UntagResource",
                "glue:UpdateColumnStatisticsForPartition",
                "glue:UpdateColumnStatisticsForTable",
                "glue:UpdateConnection",
                "glue:UpdateCrawler",
                "glue:UpdateCrawlerSchedule",
                "glue:UpdateDatabase",
                "glue:UpdateDevEndpoint",
                "glue:UpdateJob",
                "glue:UpdatePartition",
                "glue:UpdateTable",
                "glue:ImportCatalogToGlue",
                "glue:UpdateUserDefinedFunction"
            ],
            "Resource": [
                "arn:aws:glue:*:*:*/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:glue:*:*:session/*",
                "arn:aws:glue:*:*:*/$${aws:PrincipalTag/ApplicationTag}*/*",
                "arn:aws:glue:*:*:database/services_datafabric*",
                "arn:aws:glue:*:*:database/us_dev_isc_src_db*",
                "arn:aws:glue:*:*:database/pge_rs_events*",
                "arn:aws:glue:*:*:table/services_datafabric*/*",
                "arn:aws:glue:*:*:catalog"
            ]
        },
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "glue:CancelMLTaskRun",
                "glue:CancelStatement",
                "glue:CreateBlueprint",
                "glue:CreateClassifier",
                "glue:CreateConnection",
                "glue:CreateCrawler",
                "glue:CreateCustomEntityType",
                "glue:CreateDevEndpoint",
                "glue:CreateJob",
                "glue:CreateMLTransform",
                "glue:CreateRegistry",
                "glue:CreateSchema",
                "glue:CreateScript",
                "glue:CreateSecurityConfiguration",
                "glue:CreateSession",
                "glue:CreateTrigger",
                "glue:CreateWorkflow",
                "glue:NotifyEvent",
                "glue:PutSchemaVersionMetadata",
                "glue:PutWorkflowRunProperties",
                "glue:RegisterSchemaVersion",
                "glue:RemoveSchemaVersionMetadata",
                "glue:ResetJobBookmark",
                "glue:ResumeWorkflowRun",
                "glue:RunStatement",
                "glue:StartBlueprintRun",
                "glue:StartCrawlerSchedule",
                "glue:StartExportLabelsTaskRun",
                "glue:StartImportLabelsTaskRun",
                "glue:StartMLEvaluationTaskRun",
                "glue:StartMLLabelingSetGenerationTaskRun",
                "glue:StartTrigger",
                "glue:StartWorkflowRun",
                "glue:StopSession",
                "glue:StopTrigger",
                "glue:StopWorkflowRun",
                "glue:UpdateBlueprint",
                "glue:UpdateClassifier",
                "glue:UpdateMLTransform",
                "glue:UpdateRegistry",
                "glue:UpdateSchema",
                "glue:UpdateTrigger",
                "glue:UpdateWorkflow",
                "glue:UseMLTransforms",
                "glue:StopCrawlerSchedule"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "events:PutTargets",
                "events:PutRule",
                "events:DescribeRule"
            ],
            "Resource": [
                "arn:aws:events:us-east-1:991497151145:rule/StepFunctionsGetEventsForStepFunctionsExecutionRule"
            ]
        }
    ]
}