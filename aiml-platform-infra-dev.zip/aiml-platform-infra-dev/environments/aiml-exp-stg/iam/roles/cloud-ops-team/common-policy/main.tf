provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
  # profile = "aiml-exp-stg-power-user"
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg/iam/roles/cloud-ops-team/common-policy/terraform.tfstate"
    region = "us-east-1"
  }
}

data "template_file" "common-deny" {
  template = file("${path.module}/odp-us-aiml-exp-stg-common-deny-policy.json.tpl")
}

data "template_file" "common-glue" {
  template = file("${path.module}/odp-us-aiml-exp-stg-common-glue-user-policy.json.tpl")
}

data "template_file" "common-read" {
  template = file("${path.module}/odp-us-aiml-exp-stg-common-read-policy.json.tpl")
}

data "template_file" "deny-other" {
  template = file("${path.module}/odp-us-aiml-exp-stg-deny-other-regions-policy.json.tpl")
}

data "template_file" "s3-dlp" {
  template = file("${path.module}/odp-us-aiml-exp-stg-s3-dlp-policy.json.tpl")
}

data "template_file" "common-glue-service" {
  template = file("${path.module}/odp-us-aiml-exp-stg-common-glue-service-policy.json.tpl")
}

data "template_file" "tag-editor" {
  template = file("${path.module}/odp-us-aiml-exp-stg-tag-editor-policy.json.tpl")
}

module "common-deny" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-common-deny-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-common-deny"

  policy = "${data.template_file.common-deny.rendered}"
}

module "common-glue" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-common-glue-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-common-glue-policy"

  policy = "${data.template_file.common-glue.rendered}"
}

module "common-read" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-common-read-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-common-read-policy"

  policy = "${data.template_file.common-read.rendered}"
}

module "tag-editor" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-tag-editor-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-tag-editor-policy"

  policy = "${data.template_file.tag-editor.rendered}"
}

module "deny-other" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-deny-other-regions-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-deny-other-regions-policy"

  policy = "${data.template_file.deny-other.rendered}"
}

module "s3-dlp" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-s3-dlp-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-s3-dlp-policy"

  policy = "${data.template_file.s3-dlp.rendered}"
}

module "common-glue-service" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-common-glue-service-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-common-glue-service-policy"

  policy = "${data.template_file.common-glue-service.rendered}"
}