variable "tags" {
  default     = {}
  description = "Additional tags (e.g. map(`BusinessUnit`,`XYZ`)"
}


variable "environment" {}

variable "region" {}

variable "role_name" {}