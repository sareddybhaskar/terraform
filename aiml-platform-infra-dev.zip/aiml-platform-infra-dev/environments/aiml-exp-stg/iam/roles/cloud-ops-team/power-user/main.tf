provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
  profile = "aiml-exp-stg"
}

# terraform {
#   required_version  = ">= 0.12.0"
#   backend "s3" {
#     bucket = "odp-us-aiml-exp-stg-terraform"
#     key    = "terraform-state/iam/roles/hc-power-user/terraform.tfstate"
#     region = "us-east-1"
#   }
# }

data "template_file" "ps-cloud-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-power-user-cloud-policy.json.tpl")
}

data "template_file" "ps-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-power-user-policy.json.tpl")
}

module "ps-cloud-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name = "odp-us-aiml-exp-stg-power-user-cloud-policy"
  path        = "/"
  description = "power user cloud policy"
  policy = data.template_file.ps-cloud-policy.rendered
}

module "ps-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name = "odp-us-aiml-exp-stg-power-user-policy"
  path        = "/"
  description = "power user policy"
  policy = data.template_file.ps-policy.rendered
} 

module "hc-power-user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = var.role_name
  environment           = var.environment
  role_description      = "Power User"
  region                = var.region
  role_assume_policy    = <<EOF
{
    "Effect": "Allow",
    "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-uaiml-exp-stg-power-usr_10c8a1cf301e53fb"
    },
    "Action": "sts:AssumeRole"
}
EOF
  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-power-user.role_name
  policy_arn = "arn:aws:iam::aws:policy/PowerUserAccess"
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-power-user.role_name
  policy_arn = "arn:aws:iam::aws:policy/IAMFullAccess"
}