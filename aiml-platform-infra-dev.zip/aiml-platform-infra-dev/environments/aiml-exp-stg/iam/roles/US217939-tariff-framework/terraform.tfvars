region      = "us-east-1"
environment = "aiml-exp-stg"

  tags = {
    Project       = "aiml-tariff"
    Program       = "ODP"
    Environment    = "Stage"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App = "aiml-tariff"
    Role = "dt-aiml-tariff"
    Name = "odp-us-aiml-exp-stg-tarrif"
    ApplicationTag = "aiml-tariff"
    project_number = "ID7057:PR17752"
    purpose = "inv_2025"
    UserStory = "US217939"
    Owner     = "Philippe.Peloquin@gehealthcare.com"
  }
