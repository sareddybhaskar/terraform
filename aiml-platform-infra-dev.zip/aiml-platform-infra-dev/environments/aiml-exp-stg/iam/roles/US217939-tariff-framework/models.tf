##############Bedrock Models ##############

data "template_file" "user-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-tariff-user-model-policy.json.tpl")

  vars = {
    titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model1.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model2.arn
    titan_image_generator_g1_v1_arn = aws_bedrock_inference_profile.model3.arn
    titan_image_generator_g1_v2_arn = aws_bedrock_inference_profile.model4.arn
    titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model5.arn
    nova_pro_arn = aws_bedrock_inference_profile.model6.arn
    claude_3_opus_arn = aws_bedrock_inference_profile.model7.arn
    claude_3_haiku_arn = aws_bedrock_inference_profile.model8.arn
    claude_3_5_sonnet_v2_arn = aws_bedrock_inference_profile.model9.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model10.arn
    claude_3_5_sonnet_arn = aws_bedrock_inference_profile.model11.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model12.arn
    claude_4_5_sonnet_arn = aws_bedrock_inference_profile.model13.arn
  }
}

# service model policy template
data "template_file" "service-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-tariff-service-model-policy.json.tpl")

  vars = {
    titan_embeddings_g1_text_arn = aws_bedrock_inference_profile.model1.arn
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model2.arn
    titan_image_generator_g1_v1_arn = aws_bedrock_inference_profile.model3.arn
    titan_image_generator_g1_v2_arn = aws_bedrock_inference_profile.model4.arn
    titan_multimodal_embeddings_g1_arn = aws_bedrock_inference_profile.model5.arn
    nova_pro_arn = aws_bedrock_inference_profile.model6.arn
    claude_3_opus_arn = aws_bedrock_inference_profile.model7.arn
    claude_3_haiku_arn = aws_bedrock_inference_profile.model8.arn
    claude_3_5_sonnet_v2_arn = aws_bedrock_inference_profile.model9.arn
    claude_3_5_haiku_arn = aws_bedrock_inference_profile.model10.arn
    claude_3_5_sonnet_arn = aws_bedrock_inference_profile.model11.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model12.arn
  }
}

module "user-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-tariff-user-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-tariff-user-model-policy"

  policy = data.template_file.user-model-policy.rendered
}

module "service-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-tariff-service-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-tariff-service-model-policy"

  policy = data.template_file.service-model-policy.rendered
}

###### Bedrock Instance Profile ######

resource "aws_bedrock_inference_profile" "model1" {
  name        = "tariff-titan-embeddings-g1-text"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-text-v1"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-titan-embeddings-g1-text"
    }
  )
}

resource "aws_bedrock_inference_profile" "model2" {
  name        = "tariff-titan-text-embeddings-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-text-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-titan-text-embeddings-v2"
    }
  )
}

resource "aws_bedrock_inference_profile" "model3" {
  name        = "tariff-titan-image-generator-g1-v1"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-image-generator-v1"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-titan-image-generator-g1-v1"
    }
  )
}

resource "aws_bedrock_inference_profile" "model4" {
  name        = "tariff-titan-image-generator-g1-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-image-generator-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-titan-image-generator-g1-v2"
    }
  )
}

resource "aws_bedrock_inference_profile" "model5" {
  name        = "tariff-titan-multimodal-embeddings-g1"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-image-v1"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-titan-multimodal-embeddings-g1"
    }
  )
}

resource "aws_bedrock_inference_profile" "model6" {
  name        = "tariff-nova-pro"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0"
    # copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.amazon.nova-pro-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-nova-pro"
    }
  )
}

resource "aws_bedrock_inference_profile" "model7" {
  name        = "tariff-claude-3-opus"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-opus-20240229-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-claude-3-opus"
    }
  )
}

resource "aws_bedrock_inference_profile" "model8" {
  name        = "tariff-claude-3-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/anthropic.claude-3-haiku-20240307-v1:0"
  }

   tags = merge(
    var.tags,
    {
      Model = "tariff-claude-3-haiku"
    }
  )
}

resource "aws_bedrock_inference_profile" "model9" {
  name        = "tariff-claude-3-5-sonnet-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-sonnet-20241022-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-claude-3-5-sonnet-v2"
    }
  )
}

resource "aws_bedrock_inference_profile" "model10" {
  name        = "tariff-claude-3-5-haiku"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-claude-3-5-haiku"
    }
  )
}

resource "aws_bedrock_inference_profile" "model11" {
  name        = "tariff-claude-3-5-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-claude-3-5-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model12" {
  name        = "tariff-claude-3-7-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "tariff-claude-3-7-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model13" {
  name        = "tariff-claude-4-5-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-5-20250929-v1:0"
  }

   tags = merge(
    var.tags,
    {
      Model = "tariff-claude-4-5-sonnet"
    }
  )
}