{
  "Statement": [
    {
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModel*"
      ],
      "Effect": "Allow",
      "Resource": [
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v1",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-image-generator-v1",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-image-generator-v2:0",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-image-v1",
        "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-haiku-20240307-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0",
        "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0",
        "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-5-sonnet-20241022-v2:0",
        "arn:aws:bedrock:us-east-1:*:inference-profile/us.amazon.nova-pro-v1:0",
        "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-opus-20240229-v1:0",
        "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-5-haiku-20241022-v1:0",
        "arn:aws:bedrock:us-east-1:*:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
      ],
      "Condition": {
        "StringEquals": {
          "bedrock:inferenceProfileName": [
                "tariff-titan-embeddings-g1-text",
                "tariff-titan-text-embeddings-v2",
                "tariff-titan-image-generator-g1-v1",
                "tariff-titan-image-generator-g1-v2",
                "tariff-titan-multimodal-embeddings-g1",
                "tariff-nova-pro",
                "tariff-claude-3-opus",
                "tariff-claude-3-haiku",
                "tariff-claude-3-5-sonnet-v2",
                "tariff-claude-3-5-haiku",
                "tariff-claude-3-5-sonnet",
                "tariff-claude-3-7-sonnet"
          ]
        }
      }
    },
        {
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModel*",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Effect": "Allow",
      "Resource": [
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/21mxch59psh5",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/67j2obgp59o2",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/9j38bk5nscq0",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/4tb9efx47ysb",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/ebtxwtku22ot",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/d86rl3errwp1",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/hdk23oir2eos",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/v0rb6t6hqny9",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/jvxj1tqx37wv",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/srg6xes940cl",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/lx5zmqdsmm94",
        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/5dbwqhduwj6o"
      ]
    }
  ],
  "Version": "2012-10-17"
}
