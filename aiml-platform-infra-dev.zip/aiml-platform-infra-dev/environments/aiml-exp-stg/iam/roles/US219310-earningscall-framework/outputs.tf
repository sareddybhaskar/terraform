output "login-role" {
  value = module.hc-aiml-earningscall-users.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}


output "all-model-arns" {
  value = {
    "titan-text-embeddings-v2" = aws_bedrock_inference_profile.model1.arn
    "claude-3-7-sonnet"        = aws_bedrock_inference_profile.model2.arn
    "claude-sonnet-4"          = aws_bedrock_inference_profile.model3.arn
   }
}

output "all-model-arns-list" {
  value = [
    aws_bedrock_inference_profile.model1.arn,
    aws_bedrock_inference_profile.model2.arn,
    aws_bedrock_inference_profile.model3.arn
  ]
}