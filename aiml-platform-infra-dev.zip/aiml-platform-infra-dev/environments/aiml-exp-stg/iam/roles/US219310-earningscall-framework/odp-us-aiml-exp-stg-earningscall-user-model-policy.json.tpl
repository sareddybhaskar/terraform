{
    "Statement": [
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/5bkjy8g49x82",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/9k7z20tloxxz",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/4bgqfh6tpnva",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8adiwoq3bwcp"
            ]
        },
        {
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModel*"
            ],
            "Condition": {
                "StringEquals": {
                    "bedrock:InferenceProfileArn": [
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/5bkjy8g49x82",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/9k7z20tloxxz",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/4bgqfh6tpnva",
                        "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8adiwoq3bwcp"
                    ]
                }
            },
            "Effect": "Allow",
            "Resource": [
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v2:0",
                "arn:aws:bedrock:us-east-1::foundation-model/amazon.titan-embed-text-v1",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:*::foundation-model/anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/5bkjy8g49x82",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/9k7z20tloxxz",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/4bgqfh6tpnva",
                "arn:aws:bedrock:us-east-1:991497151145:application-inference-profile/8adiwoq3bwcp"
            ]
        }
    ],
    "Version": "2012-10-17"
}