{
    "Statement": [        
        {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:PutMetricData",
            "cloudwatch:GetMetricData",
            "cloudwatch:PutAnomalyDetector",
            "cloudwatch:GetMetricStatistics",
            "cloudwatch:GetMetricWidgetImage",
            "cloudwatch:PutManagedInsightRules"
        ],
         "Resource": "*"
        },
       {
         "Effect": "Allow",
         "Action": [
            "cloudwatch:Put*",            
            "cloudwatch:TagResource",            
            "cloudwatch:GetDashboard",
            "cloudwatch:EnableAlarmActions",
            "cloudwatch:StopMetricStreams",
            "cloudwatch:GetInsightRuleReport",
            "cloudwatch:SetAlarmState",
            "cloudwatch:EnableInsightRules",
            "cloudwatch:StartMetricStreams"
        ],
         "Resource": [
            "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:insight-rule/*",
            "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
            "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*"
         ]
       },       
        {
            "Effect": "Allow",
            "Action": [
                "logs:Put*",
                "logs:Get*",
		        "logs:Describe*",
		        "logs:List*",
                "logs:Create*",
                "logs:StartQuery",
                "logs:StopQuery",
                "logs:TestMetricFilter",				
                "logs:UpdateLogDelivery",
                "logs:AssociateKmsKey",
                "logs:TagLogGroup",
                "logs:UntagLogGroup",
                "logs:FilterLogEvents"				
            ],
            "Resource": [
		        "*"
            ]
        },
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::*:role/odp-us-aiml-exp-stg-earningscall-service-role",
            "Sid": "Passrole"
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Get*",
                "s3:Put*",
                "s3:DeleteObject"                
            ],
            "Effect": "Allow",
            "Resource": [               
                "arn:aws:s3:::odp-us-aiml-exp-stg-earningscall",
                "arn:aws:s3:::odp-us-aiml-exp-stg-earningscall/*"
            ]
        },
        {
            "Action": [
                "s3:ListBucket",
                "s3:Put*",
                "s3:Get*"            
            ],
            "Effect": "Allow",
            "Resource": [               
                "arn:aws:s3:::odp-us-aiml-exp-stg-earningscall-sensitive",
                "arn:aws:s3:::odp-us-aiml-exp-stg-earningscall-sensitive/*"
            ]
        },
        {
            "Action": [
                "sqs:Get*",
                "sqs:List*",
                "sqs:ChangeMessageVisibility",
                "sqs:PurgeQueue",
                "sqs:ReceiveMessage",
                "sqs:SendMessage",
                "sqs:CreateQueue",
                "sqs:SetQueueAttributes"
            ],
            "Effect": "Allow",
            "Resource": "arn:aws:sqs:*:*:$${aws:PrincipalTag/ApplicationTag}*"
        },           
        {
            "Action": [
                "opensearch:Get*",
                "opensearch:ApplicationAccessAll",
                "opensearch:StartDirectQuery",
                "opensearch:CreateCollection",
                "opensearch:UpdateCollection",
                "opensearch:DeleteCollection",
                "opensearch:GetCollection",
                "opensearch:ListCollections"
             ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:opensearch:*:*:application/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:opensearch:*:*:datasource/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:opensearch:*:*:collection/$${aws:PrincipalTag/ApplicationTag}*"
            ]
        },
        {
            "Action": [
                "sagemaker:AssociateTrialComponent",
                "sagemaker:BatchPutMetrics",
                "sagemaker:Create*",
                "sagemaker:DisassociateTrialComponent",
                "sagemaker:Start*",
                "sagemaker:Stop*",
                "sagemaker:Update*",
                "sagemaker:InvokeEndpoint",
                "sagemaker:Describe*",
                "sagemaker:List*",
                "sagemaker:Search",
                "sagemaker:AddTags"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:sagemaker:*:*:app/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*/*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*/$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:*:$${aws:PrincipalTag/ApplicationTag}-*",
                "arn:aws:sagemaker:*:*:user-profile/$${aws:PrincipalTag/ApplicationTag}-*/$${aws:PrincipalTag/ApplicationTag}-*"
            ]
        },
        {
            "Action": [
                "athena:TagResource",
                "athena:CreateDataCatalog",
                "athena:UpdateDataCatalog",
                "athena:GetTableMetadata",
                "athena:StartQueryExecution",
                "athena:GetQueryResultsStream",
                "athena:GetQueryResults",
                "athena:GetDatabase",
                "athena:GetDataCatalog",
                "athena:GetNamedQuery",
                "athena:ListTagsForResource",
                "athena:ListQueryExecutions",
                "athena:ListNamedQueries",
                "athena:GetWorkGroup",
                "athena:CreateNamedQuery",
                "athena:ListDatabases",
                "athena:StopQueryExecution",
                "athena:GetQueryExecution",
                "athena:BatchGetNamedQuery",
                "athena:ListTableMetadata",
                "athena:BatchGetQueryExecution"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:athena:us-east-1:*:workgroup/us-dev-ds-earningscall-scientist",
                "arn:aws:athena:*:*:datacatalog/*"
            ]
        } 
       
    ],
    "Version": "2012-10-17"
}