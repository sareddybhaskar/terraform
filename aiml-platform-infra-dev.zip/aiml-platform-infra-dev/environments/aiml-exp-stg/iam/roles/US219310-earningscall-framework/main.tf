provider "aws" {
  #version = ">= 3.0, < 4.0"
  #version = "~> 5.0"
  version = "6.2.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

###### Terraform State File Backup ######


terraform {
  required_version = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/iam/roles/US219310-earningscall-framework/terraform.tfstate"
    region = "us-east-1"
  }
}



############Cloud Ploicy############

data "template_file" "user-reservered-cloud-template" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-aiml-earningscall-users-cloud-policy.json.tpl")
}

module "user-reservered-cloud-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-aiml-earningscall-users-cloud-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-aiml-earningscall-users-cloud-policy"

  policy = data.template_file.user-reservered-cloud-template.rendered
}


data "template_file" "user-reservered-template" {
  template = file("${path.module}/odp-us-aiml-exp-stg-hc-aiml-earningscall-users-policy.json.tpl")
}

module "user-reservered-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-hc-aiml-earningscall-users-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-hc-aiml-earningscall-users-policy"

  policy = data.template_file.user-reservered-template.rendered
}

###### Local Template Files ######

data "template_file" "service" {
  template = file("${path.module}/odp-us-aiml-exp-stg-earningscall-service-policy.json.tpl")
}

data "template_file" "user" {
  template = file("${path.module}/odp-us-aiml-exp-stg-earningscall-user-policy.json.tpl")
}

data "template_file" "user1" {
  template = file("${path.module}/odp-us-aiml-exp-stg-earningscall-user1-policy.json.tpl")
}

###### Creating IAM Policy ######

module "user" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-earningscall-user-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-earningscall-user-policy"

  policy = data.template_file.user.rendered
}

module "user1" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-earningscall-user1-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-earningscall-user1-policy"

  policy = data.template_file.user1.rendered
}


module "service" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-earningscall-service-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-earningscall-service-policy"

  policy = data.template_file.service.rendered
}



###### Login Role ######

module "hc-aiml-earningscall-users" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-aiml-earningscall-users"
  role_description      = "hc-aiml-earningscall-users"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::991497151145:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_odp-aiml-exp-stg-earningscall_4280458da4bd3db9"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
}


###### Service Role ######

resource "aws_iam_role" "servicerole" {
  name        = "odp-us-aiml-exp-stg-earningscall-service-role"
  description = "odp-us-aiml-exp-stg-earningscall-service-role"

  assume_role_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": [
          "dynamodb.amazonaws.com",
          "es.amazonaws.com",
          "glue.amazonaws.com",
          "sqs.amazonaws.com",
          "s3.amazonaws.com",
          "secretsmanager.amazonaws.com",
          "cloudwatch.amazonaws.com",
          "events.amazonaws.com",
          "states.amazonaws.com",
          "logs.amazonaws.com",
          "sagemaker.amazonaws.com",
          "bedrock.amazonaws.com"
        ]
      },
      "Action": "sts:AssumeRole"
    },
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "bedrock.amazonaws.com"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "aws:SourceAccount": "991497151145"
        }
      }
    }
  ]
}
EOF
  tags            = var.tags
}

###### Attaching Policies to user Role ######

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-aiml-earningscall-users.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-aiml-earningscall-users.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.hc-aiml-earningscall-users.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-glue-user-policy" 
  }

  resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.hc-aiml-earningscall-users.role_name
  policy_arn = module.user.arn
}

resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.hc-aiml-earningscall-users.role_name
  policy_arn = "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-s3-dlp-policy"
} 


resource "aws_iam_role_policy_attachment" "user6" {
  role       = module.hc-aiml-earningscall-users.role_name
  policy_arn = module.user-model.arn
}

resource "aws_iam_role_policy_attachment" "user7" {
  role       = module.hc-aiml-earningscall-users.role_name
  policy_arn = module.user1.arn
} 
 
###### Attaching Policies to Service Role ######

resource "aws_iam_role_policy_attachment" "service1" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-deny-policy"
}


resource "aws_iam_role_policy_attachment" "service3" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::991497151145:policy/odp-us-aiml-exp-stg-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service4" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service.arn
}

resource "aws_iam_role_policy_attachment" "service5" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service-model.arn
}


