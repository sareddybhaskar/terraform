##############Bedrock Models ##############

data "template_file" "user-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-earningscall-user-model-policy.json.tpl")

  vars = {
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model2.arn
    claude_sonnet_4_arn   = aws_bedrock_inference_profile.model3.arn
    titan_text_embeddings_v1_arn = aws_bedrock_inference_profile.model4.arn
  }
}

# service model policy template
data "template_file" "service-model-policy" {
  template = file("${path.module}/odp-us-aiml-exp-stg-earningscall-service-model-policy.json.tpl")

  vars = {
    titan_text_embeddings_v2_arn = aws_bedrock_inference_profile.model1.arn
    claude_3_7_sonnet_arn = aws_bedrock_inference_profile.model2.arn
    claude_sonnet_4_arn   = aws_bedrock_inference_profile.model3.arn
    titan_text_embeddings_v1_arn = aws_bedrock_inference_profile.model4.arn
  }
}

module "user-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-earningscall-user-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-earningscall-user-model-policy"

  policy = data.template_file.user-model-policy.rendered
}

module "service-model" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-aiml-exp-stg-earningscall-service-model-policy"
  path        = "/"
  description = "odp-us-aiml-exp-stg-earningscall-service-model-policy"

  policy = data.template_file.service-model-policy.rendered
}

###### Bedrock Instance Profile ######

resource "aws_bedrock_inference_profile" "model1" {
  name        = "earningscall-titan-text-embeddings-v2"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-text-v2:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "earningscall-titan-text-embeddings-v2"
    }
  )
}

resource "aws_bedrock_inference_profile" "model2" {
  name        = "earningscall-claude-3-7-sonnet"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "earningscall-claude-3-7-sonnet"
    }
  )
}

resource "aws_bedrock_inference_profile" "model3" {
  name        = "earningscall-claude-sonnet-4"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
  }

  tags = merge(
    var.tags,
    {
      Model = "earningscall-claude-sonnet-4"
    }
  )
}

resource "aws_bedrock_inference_profile" "model4" {
  name        = "earningscall-titan-text-embeddings-v1"

  model_source {
    copy_from = "arn:aws:bedrock:us-east-1:991497151145:foundation-model/amazon.titan-embed-text-v1"
  }

  tags = merge(
    var.tags,
    {
      Model = "earningscall-titan-text-embeddings-v1"
    }
  )
}
