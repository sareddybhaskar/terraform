variable "tags" {
    default = {}
    description = "Additional tags (e.g. map(`BusinessUnit`,`XYZ`))"
}

variable "environment" {}
variable "region" {}
variable "account-id" {}
variable "project-name" {}
variable "login-role-name" {}
variable "foldername" {}