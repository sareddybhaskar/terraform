{
    "Statement": [
        {
            "Action": [
                "compute-optimizer:GetRecommendationPreferences",
                "compute-optimizer:GetAutoScalingGroupRecommendations",
                "compute-optimizer:GetEnrollmentStatusesForOrganization",
                "compute-optimizer:ExportEC2InstanceRecommendations",
                "compute-optimizer:GetEffectiveRecommendationPreferences",
                "compute-optimizer:DescribeRecommendationExportJobs",
                "compute-optimizer:GetEC2InstanceRecommendations",
                "compute-optimizer:GetEnrollmentStatus",
                "compute-optimizer:GetEBSVolumeRecommendations",
                "compute-optimizer:GetLambdaFunctionRecommendations",
                "compute-optimizer:GetEC2RecommendationProjectedMetrics",
                "compute-optimizer:GetRecommendationSummaries"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor1"
        },
        {
            "Action": [
                "elasticmapreduce:Get*",
                "elasticmapreduce:Describe*",
                "elasticmapreduce:List*"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor0"
        },
        {
            "Action": [
                "pricing:DescribeServices",
                "pricing:GetProducts"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "VisualEditor2"
        },
        {
            "Action": [
                "cloudwatch:PutMetricData",
                "cloudwatch:GetMetricData",
                "cloudwatch:PutAnomalyDetector",
                "cloudwatch:GetMetricStatistics",
                "cloudwatch:GetMetricWidgetImage",
                "cloudwatch:PutManagedInsightRules",
                "cloudwatch:PutDashboard*",
                "cloudwatch:GetDashboard*"
            ],
            "Effect": "Allow",
            "Resource": "*"
        },
        {
            "Action": [
                "cloudwatch:PutInsightRule",
                "cloudwatch:PutMetricAlarm",
                "cloudwatch:TagResource",
                "cloudwatch:EnableAlarmActions",
                "cloudwatch:StopMetricStreams",
                "cloudwatch:GetInsightRuleReport",
                "cloudwatch:SetAlarmState",
                "cloudwatch:EnableInsightRules",
                "cloudwatch:StartMetricStreams",
                "cloudwatch:PutDashboard",
                "cloudwatch:GetDashboard"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:cloudwatch::*:dashboard/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:insight-rule/*",
                "arn:aws:cloudwatch:*:*:metric-stream/$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch:*:*:alarm:$${aws:PrincipalTag/ApplicationTag}*",
                "arn:aws:cloudwatch::*:dashboard/*"
            ]
        },
        {
            "Action": [
                "redshift-data:BatchExecuteStatement",
                "redshift-data:ExecuteStatement",
                "redshift-data:CancelStatement",
                "redshift-data:ListStatements",
                "redshift-data:GetStatementResult",
                "redshift-data:DescribeStatement",
                "redshift-data:ListDatabases",
                "redshift-data:ListSchemas",
                "redshift-data:ListTables",
                "redshift-data:DescribeTable"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "DataAPIPermissions"
        },
        {
            "Action": [
                "redshift-data:GetStatementResult",
                "redshift-data:CancelStatement",
                "redshift-data:DescribeStatement",
                "redshift-data:ListStatements"
            ],
            "Effect": "Allow",
            "Resource": "*",
            "Sid": "DataAPIPermissions1"
        }
    ],
    "Version": "2012-10-17"
}