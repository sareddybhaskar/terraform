
provider "aws" {
  #version = ">= 3.0, < 4.0"
  #version = "6.2.0"
  region  = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  # required_providers {
  #   aws = {
  #     source = "hashicorp/aws"
  #     version = ">=6.0.0"
  #   }
  # }
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/us-aiml-exp-stg/iam-roles/US220705-odp/terraform.tfstate"
    region = "us-east-1"
  }
}

data "template_file" "ps-cloud-policy" {
  template = file("${path.module}/${var.environment}-${var.login-role-name}-cloud-policy.json.tpl")
}

data "template_file" "ps-policy" {
  template = file("${path.module}/${var.environment}-${var.login-role-name}-policy.json.tpl")
}

data "template_file" "user-policy" {
  template = file("${path.module}/${var.environment}-${var.project-name}-user-policy.json.tpl")
}

module "user-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "${var.environment}-${var.project-name}-user-policy"
  path        = "/"
  description = "${var.project-name} user policy"
  policy = data.template_file.user-policy.rendered
}

module "ps-cloud-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name = "${var.environment}-${var.login-role-name}-cloud-policy"
  path        = "/"
  description = "${var.login-role-name} cloud policy"
  policy = data.template_file.ps-cloud-policy.rendered
}

module "ps-policy" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name = "${var.environment}-${var.login-role-name}-policy"
  path        = "/"
  description = "${var.login-role-name} policy"
  policy = data.template_file.ps-policy.rendered
}

module "loginrole" {
  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = var.login-role-name
  role_description      = "${var.project-name} role"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = file("login-role-assume-policy.json")
}

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.loginrole.role_name
  policy_arn = "arn:aws:iam::${var.account-id}:policy/${var.environment}-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.loginrole.role_name
  policy_arn = "arn:aws:iam::${var.account-id}:policy/${var.environment}-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.loginrole.role_name
  policy_arn = "arn:aws:iam::${var.account-id}:policy/${var.environment}-s3-dlp-policy"
}

resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.loginrole.role_name
  policy_arn = module.user-policy.arn
}
resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.loginrole.role_name
  policy_arn = "arn:aws:iam::${var.account-id}:policy/${var.environment}-common-glue-user-policy" 
}

resource "aws_iam_role_policy_attachment" "user6" {
  role       = module.loginrole.role_name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess" 
}