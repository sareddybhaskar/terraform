
# variable "mlops_tags" {
#   default     = {}
# }

variable "aiml_tags" {
  default     = {}
}


#### User Profiles variables ####

variable "sagemaker_domain_id" {}

variable "environment" {}

variable "region" {}

variable "name" {}

variable "aiml_user_profile_name" {}

variable "aiml_execution_role" {}

