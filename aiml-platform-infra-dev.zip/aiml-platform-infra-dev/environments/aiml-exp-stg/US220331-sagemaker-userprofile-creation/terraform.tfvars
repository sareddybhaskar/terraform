  name = "odp-us-aiml-exp-stg"
  region = "us-east-1"
  environment = "aiml-exp-stg"

   aiml_tags = {
    Project       = "aiml-isc-demand"
    Program       = "ODP"
    Environment    = "Stg"
    ManagedBy      = "Terraform"
    Automation     = "Jenkins"
    uai            = "UAI3032643"
    App = "aiml-ofp-isc-demand"
    Role = "dt-aiml-isc-demand-ds"    
    ApplicationTag = "isc-demand"
    UserStory = "US220331"
    purpose = "inv_2025"
    project_number = "ID5990:PR17717"
    Owner = "Philippe.Peloquin@gehealthcare.com:Mukul.Musale@gehealthcare.com"
    Contact = "cdao_mlops_support@gehealthcare.com"
  }

 
#### sagemaker domain id ####

sagemaker_domain_id = "d-xrm3mgguzmmi"

#### User Profiles ####
#mlops_user_profile_name = "hc-aiml-mlops-admin"
#mlops_execution_role = "arn:aws:iam::991497151145:role/odp-us-aiml-exp-stg-aiml-mlops-admin-service-role"


aiml_user_profile_name = "hc-ai-isc-demand-user"
aiml_execution_role = "arn:aws:iam::991497151145:role/odp-us-aiml-exp-stg-isc-demand-service-role"
