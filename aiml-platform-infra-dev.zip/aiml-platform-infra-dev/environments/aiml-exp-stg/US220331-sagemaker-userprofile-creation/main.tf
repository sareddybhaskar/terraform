provider "aws" {
  version = "6.2.0"
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/US220331-sagemaker-userprofile-creation/terraform.tfstate"
    region = "us-east-1"
  }
}

### User Profiles ####

module "aiml-profile" {

  source = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-modules.git//modules/sagemaker/sagemaker_userprofile?ref=dev"

  enable_sagemaker_user_profile = true
  sagemaker_user_profile_name = var.aiml_user_profile_name
  sagemaker_user_profile_domain_id = var.sagemaker_domain_id

  sagemaker_user_profile_user_settings = {
    execution_role = var.aiml_execution_role
  }

  tags            = var.aiml_tags

}

