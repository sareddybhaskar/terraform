locals {
    privileged_namespaces = join(",",
                              [ 
                                "default",
                                "dev-ibstudio-developers",
                                "dev-helloworld-nodejs",
                                "dev-helloworld-spring",
                                "dev-python-flask"
                              ])



    excluded_namespaces = join(",", 
                            [   "kube-system",
                                "gatekeeper-system",
                                "amazon-cloudwatch",
                                "ingress-nginx",
                                "kube-node-lease",
                                "kube-public",
                                "kubernetes-dashboard",
                                "dev-ibstudio-tls-ingress-nginx",
                                "monitoring"
                            ])
}