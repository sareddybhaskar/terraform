variable "region" {
  type        = string
  description = "AWS Region"
}

variable "efs_name" {
  type        = string
}

variable "availability_zones" {
  type        = list(string)
  description = "List of availability zones"
}

variable "tags" {
  type        = map(string)
  default     = {}
}

variable "subnet_ids" {
  type        = list(string)
}

variable "allowed_cidr_blocks" {
  type        = list(string)
}


variable "vpc_id" {
  type   = string
}