region = "us-east-1"

# Use lower case letters
project = "dev-helloworld-spring"

tags = {
    ManagedBy = "Terraform"
    Project = "Admin"
    App = "Factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}
