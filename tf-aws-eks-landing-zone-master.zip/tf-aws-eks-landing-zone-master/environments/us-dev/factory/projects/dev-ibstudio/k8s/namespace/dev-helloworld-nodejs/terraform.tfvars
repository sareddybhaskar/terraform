# Namespace and team 

namespace = "dev-helloworld-nodejs"
project = "dev-helloworld-nodejs"

# User SSO
k8s_user = "dev-helloworld" ## Ex:- FSSO 50312512
