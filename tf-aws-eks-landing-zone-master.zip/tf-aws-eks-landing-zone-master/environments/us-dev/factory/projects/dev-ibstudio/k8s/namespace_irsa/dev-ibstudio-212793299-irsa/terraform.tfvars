region = "us-east-1"

# Use lower case letters
project = "dev-ibstudio-212793299"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory-IBStudio"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}



