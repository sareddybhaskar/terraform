# Namespace and team 

namespace = "dev-ibstudio-212744470"
project = "dev-ibstudio-212744470"

# User SSO

k8s_user = "212744470"
