# Namespace and team 

namespace = "dev-ibstudio-developers"
project = "dev-ibstudio-developers"

# User SSO
k8s_user = "dev-ibstudio-developers"
