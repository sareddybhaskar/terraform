# Namespace and team 

namespace = "dev-helloworld-spring"
project = "dev-helloworld-spring"

# User SSO
k8s_user = "dev-helloworld"
