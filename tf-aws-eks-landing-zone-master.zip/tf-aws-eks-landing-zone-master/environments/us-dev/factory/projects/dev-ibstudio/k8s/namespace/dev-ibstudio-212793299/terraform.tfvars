# Namespace and team 

namespace = "dev-ibstudio-212793299"
project = "dev-ibstudio-212793299"

# User SSO
k8s_user = "212793299"
