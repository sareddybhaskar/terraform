

resource "kubernetes_persistent_volume" "efs-developers-pv" {
  metadata {
    name = "${local.dev_ibstudio_developers_namespace}-efs-pv"
  }

  spec {
    capacity = {
      storage = "5Gi"
    }
    access_modes = ["ReadWriteMany"]
    persistent_volume_reclaim_policy = "Retain"
    storage_class_name = "efs-sc"
    persistent_volume_source {
      csi {
        volume_handle = "${data.terraform_remote_state.efs.outputs.efs_id}::${element(values(data.terraform_remote_state.efs.outputs.access_point_ids), 3)}"
        driver         = "efs.csi.aws.com"
        volume_attributes = {
          "encryptInTransit" = "true"
        }
      }
    }
  }
}

resource "kubernetes_persistent_volume_claim" "efs-developers-pvc" {
  metadata {
    name = "${local.dev_ibstudio_developers_namespace}-efs-pvc"
    namespace = local.dev_ibstudio_developers_namespace
    labels = var.labels
  }
  spec {
    access_modes = ["ReadWriteMany"]
    resources {
      requests = {
        storage = "5Gi"
      }
    }
    volume_name        = kubernetes_persistent_volume.efs-developers-pv.metadata[0].name
    storage_class_name = "efs-sc"
  }
}