region = "us-east-1"

# k8s namespace
project = "dev-ibstudio-212776271"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory-IBStudio"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}



