resource "kubernetes_pod_security_policy" "psp-restricted" {
  metadata {
    name = "${var.namespace}-psp-restricted"
    labels = {
      project = var.project
    }

    annotations = {
      "apparmor.security.beta.kubernetes.io/allowedProfileNames" = "runtime/default"

      "apparmor.security.beta.kubernetes.io/defaultProfileName" = "runtime/default"

      "seccomp.security.alpha.kubernetes.io/allowedProfileNames" = "docker/default,runtime/default"

      "seccomp.security.alpha.kubernetes.io/defaultProfileName" = "runtime/default"
    }
  }

  spec {
    allow_privilege_escalation = false
    required_drop_capabilities = ["ALL"]
    volumes                    = ["configMap", "emptyDir", "projected", "secret", "downwardAPI", "persistentVolumeClaim"]

    host_ipc                   = false
    host_network               = false
    host_pid                   = false
    privileged                 = false
    read_only_root_filesystem  = false

    se_linux {
      rule = "RunAsAny"
    }

    run_as_user {
      rule = "MustRunAsNonRoot"
    }

    fs_group {
      rule = "MustRunAs"

      range {
        min = 1
        max = 65535
      }
    }

    supplemental_groups {
      rule = "MustRunAs"

      range {
        min = 1
        max = 65535
      }
    }
  } 
}