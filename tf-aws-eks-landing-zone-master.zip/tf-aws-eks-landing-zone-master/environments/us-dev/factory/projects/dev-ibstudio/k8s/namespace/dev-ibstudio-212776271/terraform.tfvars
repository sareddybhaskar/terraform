# Namespace and team 

namespace = "dev-ibstudio-212776271"
project = "dev-ibstudio-212776271"

# User SSO
k8s_user ="212776271"
