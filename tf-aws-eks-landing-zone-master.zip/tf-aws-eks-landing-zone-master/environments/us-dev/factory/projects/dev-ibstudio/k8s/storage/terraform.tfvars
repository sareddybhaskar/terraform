# Namespace and team 

labels = {
    project = "dev-ibstudio"
    team    = "ibstudio"
    program  = "odp"
}
