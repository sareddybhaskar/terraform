locals {

    dev_212744470_namespace = "dev-ibstudio-212744470"
    dev_212776271_namespace = "dev-ibstudio-212776271"
    dev_212793299_namespace = "dev-ibstudio-212793299"
    dev_ibstudio_developers_namespace = "dev-ibstudio-developers"

}