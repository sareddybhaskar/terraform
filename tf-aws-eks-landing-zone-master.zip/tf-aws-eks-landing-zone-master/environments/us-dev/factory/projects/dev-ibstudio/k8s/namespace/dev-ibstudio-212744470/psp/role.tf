resource "kubernetes_service_account" "psp-restricted" {
  metadata {
    name = "${var.namespace}-psp-restricted-sa"
    namespace = var.namespace
  }
}

resource "kubernetes_cluster_role" "psp-restricted" {
  metadata {
    name      = "${var.namespace}-psp-restricted-role"
  }

  rule {
    verbs          = ["use"]
    api_groups     = ["policy"]
    resources      = ["podsecuritypolicies"]
    resource_names = ["${var.namespace}-psp-restricted"]
  }
}

resource "kubernetes_role_binding" "psp-restricted" {
  metadata {
    name      = "${var.namespace}-psp-restricted-role-binding"
    namespace = var.namespace
  }

  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = kubernetes_cluster_role.psp-restricted.metadata.0.name
  }

  # subject {
  #   kind      = "ServiceAccount"
  #   name      = kubernetes_service_account.psp-restricted.metadata.0.name
  #   namespace = var.namespace
  # } 

  subject {
    kind      = "User"
    # api_group = "rbac.authorization.k8s.io" 
    name =   var.k8s_user
    namespace = var.namespace
  }

  # subject {
  #   kind      = "Group"
  #   api_group = "rbac.authorization.k8s.io" 
  #   name =   "system:authenticated"
  #   namespace = var.namespace
  # }
}

