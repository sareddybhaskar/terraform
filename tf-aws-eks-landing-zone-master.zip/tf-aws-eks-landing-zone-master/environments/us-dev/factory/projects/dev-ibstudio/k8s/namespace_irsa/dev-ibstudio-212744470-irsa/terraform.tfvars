region = "us-east-1"

# this is the value of namespace
project = "dev-ibstudio-212744470"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory-IBStudio"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}



