provider "aws" {
  region = var.region
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-innovation-terraform"
    key    = "terraform-state/innovation-us/eks/factory/projects/dev-ibstudio/k8s/namespace/irsa/dev-ibstudio-212793299/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-innovation-terraform"
    key    = "terraform-state/innovation-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_caller_identity" "current" {}

################################################################################################

locals {
  cluster_name  = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

module "iam_assumable_role_admin" {
  source                        = "git::https://github.build.ge.com/gehc-odp/tf-aws-eks.git//modules/eks/iam-role?ref=tags/v1.0"
  create_role                   = true
  role_name                     = "${local.cluster_name}-eks-${var.project}-irsa"
  provider_url                  = replace(data.terraform_remote_state.eks.outputs.eks_cluster_identity_oidc_issuer, "https://", "")
  role_policy_arns              = [aws_iam_policy.odp.arn]
  oidc_fully_qualified_subjects = ["system:serviceaccount:${var.project}:${var.project}-sa"]
  tags                          = var.tags
}

 resource "aws_iam_policy" "odp" {
   name_prefix = "${local.cluster_name}-eks-${var.project}-irsa-"
   tags        = var.tags
   description = "EKS cluster-autoscaler policy for cluster ${local.cluster_name}"
   policy = <<POLICY
{
  "Version": "2012-10-17",  
	"Statement": [
    {
      "Sid": "nodejs",
      "Action": [
        "s3:List*",
        "s3:Get*"
      ],
      "Effect": "Allow",
      "Resource": [
        "arn:aws:s3:::odp-us-innovation-cicd",
        "arn:aws:s3:::odp-us-innovation-cicd/*"
      ]
    }
  ]  
}
POLICY
}