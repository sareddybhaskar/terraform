variable "region" {
  default = "us-east-1"
}

variable "enabled" {
  type = bool
  default = true
}

variable "tags" {
  type        = map
}

variable "project" {
  type        = string
}