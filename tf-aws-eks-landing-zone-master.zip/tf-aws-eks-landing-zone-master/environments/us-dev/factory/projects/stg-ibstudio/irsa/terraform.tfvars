region = "us-east-1"

# Use lower case letters
project = "ibstudio"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory-IBStudio"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}


# role_name_prefix          = "role"
# policy_name_prefix        = "policy"
# service_account_name      = "cloud-sa"
# service_account_namespace = "cloud"


