# Deploy sequence

1. node-groups
2. efs
3. irsa
4. k8s/namespace
5. k8s/storage-class