
variable "namespace" {
  description = "The name of the namespace where the roles should be created."
  type        = string
}

variable "project" {
    type = string
}

variable "labels" {
  type        = map(string)
  default     = {}
}
