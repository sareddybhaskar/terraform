# Namespace and team 

namespace = "ibstudio"
project = "ibstudio"


labels = {
    project = "ibstudio"
    team    = "ibstudio"
    program  = "odp"
}
