# Namespace and team 

namespace = "ibstudio"
project = "ibstudio"

# FSSO AWS IAM User
fsso_user = "502827197"