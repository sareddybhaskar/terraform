


resource "kubernetes_role" "user_role_503125591_role" {
  count      = 1

  metadata {
    name        = "${var.namespace}-${var.user_role_503125591}-role"
    namespace   = var.namespace
    labels      = var.labels
    # annotations = var.annotations
  }

  rule {
    api_groups = [
      "",
      "batch",
      "extensions",
      "apps",   
    ]

    resources = [
      "configmaps",
      "cronjobs",
      "deployments",
      "events",
      "ingresses",
      "jobs",
      "pods",
      "pods/attach",
      "pods/exec",
      "pods/log",
      "pods/portforward",
      "pods/eviction",
      "secrets",
      "services",
      "endpoints",
      "replicasets",
      "daemonsets",
      "statefulsets",
      "replicationcontrollers"
    ]
    verbs = [
      "create",
      "delete",
      "describe",
      "get",
      "list",
      "patch",
      "update",
      "watch",      
    ]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = [""]
    resources  = ["persistentvolumeclaims"]
  }

  rule {
    verbs      = ["get", "list", "watch"]
    api_groups = ["storage.k8s.io"]
    resources  = ["csidrivers"]
  }
}


resource "kubernetes_role_binding" "user_role_503125591_rb" {

  metadata {
    name      = "${var.namespace}-${var.user_role_503125591}-role-binding"
    namespace = var.namespace
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = kubernetes_role.user_role_503125591_role[0].metadata[0].name
  }

  subject {
    kind      = "User"
    name      = var.user_role_503125591
    namespace = var.namespace
  }
}
