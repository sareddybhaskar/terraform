# Namespace and team 

namespace = "mdp-mr"
project = "mdp-mr"

# FSSO AWS IAM User
fsso_user = "502827198"

user_role_503125591 = "503125591"
