# Namespace and team 

namespace = "mdp-mr"
project = "mdp-mr"


labels = {
    project = "mdp-mr"
    team    = "mdp"
    program  = "odp"
}
