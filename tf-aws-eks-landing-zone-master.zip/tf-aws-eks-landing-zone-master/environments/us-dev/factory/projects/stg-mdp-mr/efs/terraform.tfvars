region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0aec610839cde56fb", "subnet-06a70a7954962e097"]
vpc_id = "vpc-07765370682ef3b06"
allowed_cidr_blocks = ["100.64.0.0/16"]

efs_name = "odp-us-innovation-eks-factory-mdp-mr"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory-MDP-MR"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}
