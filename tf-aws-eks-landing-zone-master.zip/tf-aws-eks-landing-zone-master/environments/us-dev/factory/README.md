1. Add the namespace to opa/locals.tf (terraform apply)
2. EFS Share (/projects/projectname/efs/main.tf) (terraform apply)
3. Modify namespace_irsa/foldername/terraform.tfvars and main.tf ( terraform apply) 
4. Modify namespace/foldername/terraform.tfvars and provide the namespace details  and main.tf (terraform apply)
5. Modify aws-auth cm to authenticate users to this namespace


### Example 

```    
kubectl get configmap aws-auth -n kube-system -o yaml >> aws-auth-today.yaml
aws-auth upsert --maproles --rolearn arn:aws:iam::541574621075:role/hc-dev-sample-ns --username dev-helloworld --groups dev-helloworld-spring --groups dev-helloworld-nodejs --groups dev-python-flask
aws-auth upsert --maproles --rolearn arn:aws:iam::541574621075:role/hc-stg-sample-ns --username stg-hw --groups stg-helloworld-spring --groups stg-helloworld-nodejs --groups stg-python-flask
# Same as k8s_user value used in namespace creation.

aws-auth upsert --mapusers --userarn arn:aws:iam::541574621075:user/503125125 --username 503125125 --groups 503125591

kubectl auth can-i create pods --namespace dev-helloworld-spring --as dev-helloworld

```