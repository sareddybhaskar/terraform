region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0d3a77c56f0b4a809", "subnet-08218951d2463ab92"]
vpc_id = "vpc-09bade12fd82d9f5d"

kubernetes_version = "1.19"
instance_types = ["t3a.large" ]
desired_size = 2
max_size = 3
min_size = 2
disk_size = 100
ec2_ssh_key = "odp-us-prod-tools_kp"

project = "ibstudio"

project_slug = "ibs"
kubernetes_labels = {
    project = "ibstudio"
    team    = "ibstudio"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  amazon-linux-extras install epel -y
  yum update -y
  yum install ansible git nano -y
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  cd /tmp/
  git clone https://503125606:bec617b980800966197687913098f42416faedf8@github.build.ge.com/gehc-odp/2faldap-ranger-nifi-splunk-crowdstrike-qualys.git
  ansible-playbook 2faldap-ranger-nifi-splunk-crowdstrike-qualys/playbook-eks-prod.yml
  rm -rf 2faldap-ranger-nifi-splunk-crowdstrike-qualys 
  EOT


tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory"
    App    ="ibstudio"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"    
}