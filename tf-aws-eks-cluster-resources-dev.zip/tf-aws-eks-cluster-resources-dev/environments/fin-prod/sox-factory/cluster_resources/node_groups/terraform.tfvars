region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-01641e51939c32f50", "subnet-059bd284b806aa397"]
vpc_id = "vpc-0305a7a8599bf52ed"

kubernetes_version = "1.33"

instance_types = ["t3a.2xlarge" ]
desired_size = 4
max_size = 4
min_size = 4
disk_size = 100
ec2_ssh_key = "odp-fin-prod-tools_kp"
# capacity_type = "SPOT"


#####################
## Project tfvars ###
#####################

project = "odp"

# Maximum 4 characters (fin-prod-factory-<project_slug>-eks-wng-) [for roles]
project_slug = "odp"

kubernetes_labels = {
    project = "odp"
    team    = "odp"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  dnf install -y ansible git nano
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  rm -rf /tmp/security-agents ; mkdir -p /tmp/security-agents  ; git clone https://NP700001567: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@github.gehealthcare.com/gehc-odp/security-agents.git /tmp/security-agents && cd /tmp/security-agents && ansible-playbook --connection=local --inventory 127.0.0.1, main.yaml ; cd ~/ ; rm -rf /tmp/security-agents
  EOT


tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3053026"
    Automation = "Jenkins"
    Environment  = "fin-prod"
    Role = "dt-dna-aa-factory"
    Appliance = "EKS"
}
