provider "aws" {
  region = "us-east-1"
  # allowed_account_ids = [
  #   "634123561912",
  # ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-fin-prod-terraform"
    key    = "terraform-state/fin-prod/eks/sox-factory/cluster/addons/grafana/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-fin-prod-terraform"
    key    = "terraform-state/fin-prod/eks/sox-factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.cluster.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
    token                  = data.aws_eks_cluster_auth.cluster.token
  }
}

resource "helm_release" "grafana" {

    name       = "grafana"
    namespace  = "monitoring"
    repository = "https://grafana.github.io/helm-charts"
    chart      = "grafana"
    version    = "6.6.1"


  values = [
    file("${path.module}/helm/values.yaml")
  ]
}