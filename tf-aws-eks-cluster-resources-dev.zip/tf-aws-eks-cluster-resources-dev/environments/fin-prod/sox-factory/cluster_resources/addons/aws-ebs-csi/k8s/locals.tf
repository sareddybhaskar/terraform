locals {
  
  irsa_sa_role_arn  = data.terraform_remote_state.irsa.outputs.this_iam_role_arn
  namespace        = "kube-system"
  tags          = "Project=ODP-Factory,Environment=fin-prod,Program=ODP,uai=UAI3053026"

}