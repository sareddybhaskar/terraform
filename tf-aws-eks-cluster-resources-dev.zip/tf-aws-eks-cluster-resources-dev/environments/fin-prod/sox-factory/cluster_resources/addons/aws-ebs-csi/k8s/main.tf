provider "aws" {
  region = "us-east-1"
  # allowed_account_ids = [
  #   "634123561912",
  # ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-fin-prod-terraform"
    key    = "terraform-state/fin-prod/eks/sox-factory/cluster/addons/aws-ebs-csi/k8s/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-fin-prod-terraform"
    key    = "terraform-state/fin-prod/eks/sox-factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "irsa" {
  backend = "s3"
  config = {
    bucket = "odp-fin-prod-terraform"
    key    = "terraform-state/fin-prod/eks/sox-factory/cluster/addons/aws-ebs-csi/irsa/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

##############################################
data "kubectl_path_documents" "overlays" {
  pattern = "${path.module}/manifests/overlays/*.yaml" 
}

resource "kubectl_manifest" "overlays" {
  count     = length(data.kubectl_path_documents.overlays.documents)
  yaml_body = element(data.kubectl_path_documents.overlays.documents, count.index)
}

data "kubectl_path_documents" "manifests" {
  pattern = "${path.module}/manifests/base/*.yaml"
    vars = {
        irsa_role_arn       = local.irsa_sa_role_arn
        tags                = local.tags
    }  
}

resource "kubectl_manifest" "manifests" {
  count     = length(data.kubectl_path_documents.manifests.documents)
  yaml_body = element(data.kubectl_path_documents.manifests.documents, count.index)
}

