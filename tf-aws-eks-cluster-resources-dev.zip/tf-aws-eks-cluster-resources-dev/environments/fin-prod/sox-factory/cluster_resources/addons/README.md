## Deploy sequence
---------------

1. nginx-ingress-tls
2. kubernetes dashboard
3. efs-csi
4. metrics-server
5. newrelic
6. gatekeeper