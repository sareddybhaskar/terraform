
# Use lower case letters
project = "odp"

region = "us-east-1"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "fin-nprod"    
}

service_account_name      = "ebs-csi-controller-sa"
service_account_namespace = "kube-system"


# role_name_prefix          = "role"
# policy_name_prefix        = "policy"