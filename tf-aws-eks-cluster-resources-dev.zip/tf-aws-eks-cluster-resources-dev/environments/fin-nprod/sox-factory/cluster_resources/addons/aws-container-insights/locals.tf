locals {
  cloudwatch_agent_docker_image  = "083760424738.dkr.ecr.us-east-1.amazonaws.com/amazon/cloudwatch-agent:1.247346.0b249609"
  region_name = "us-east-1"
  cluster_name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}