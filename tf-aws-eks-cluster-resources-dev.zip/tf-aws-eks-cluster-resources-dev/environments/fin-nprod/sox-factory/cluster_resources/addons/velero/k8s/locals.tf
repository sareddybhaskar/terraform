locals {
  k8s_namespace               = "kube-system"
  backup_s3_bucket_name       = "odp-fin-nprod-factory-eks-cluster-backup"
  region                      = "us-east-1"
  provider                    = "aws"
  velero_iam_role_arn         = data.terraform_remote_state.irsa.outputs.this_iam_role_arn
  velero_docker_image         = "083760424738.dkr.ecr.us-east-1.amazonaws.com/velero/velero:v1.5.2"
}