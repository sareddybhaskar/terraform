provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "083760424738",
  ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-fin-nprod-terraform"
    key    = "terraform-state/fin-nprod/eks/sox-factory/cluster/addons/nginx-ingress-elb/k8s/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-fin-nprod-terraform"
    key    = "terraform-state/fin-nprod/eks/sox-factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

##################################################################

