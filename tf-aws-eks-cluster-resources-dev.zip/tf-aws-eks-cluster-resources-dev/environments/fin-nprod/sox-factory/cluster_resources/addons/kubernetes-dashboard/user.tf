resource "kubernetes_cluster_role" "readonly" {
  metadata {
    name = "kubernetes-dashboard-viewonly"
  }

  rule {
    api_groups = [""]
    resources  = ["configmaps","endpoints","persistentvolumeclaims","pods","replicationcontrollers","replicationcontrollers/scale","serviceaccounts","services","nodes","persistentvolumeclaims","persistentvolumes"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = [""]
    resources  = ["bindings","events","limitranges","namespaces/status","pods/log","pods/status","replicationcontrollers/status","resourcequotas","resourcequotas/status"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = [""]
    resources  = ["namespaces"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["apps"]
    resources  = ["daemonsets","deployments","deployments/scale","replicasets","replicasets/scale","statefulsets"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["autoscaling"]
    resources  = ["horizontalpodautoscalers"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["batch"]
    resources  = ["cronjobs","jobs"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["extensions"]
    resources  = ["daemonsets","deployments","deployments/scale","ingresses","networkpolicies","replicasets","replicasets/scale","replicationcontrollers/scale"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["policy"]
    resources  = ["poddisruptionbudgets"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["networking.k8s.io"]
    resources  = ["networkpolicies"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["storage.k8s.io"]
    resources  = ["storageclasses", "volumeattachments"]
    verbs      = ["get", "list", "watch"]
  }

  rule {
    api_groups = ["rbac.authorization.k8s.io"]
    resources  = ["clusterrolebindings", "clusterroles","roles","rolebindings"]
    verbs      = ["get", "list", "watch"]
  }
}

resource "kubernetes_cluster_role_binding" "readonly" {
  metadata {
    name = "kubernetes-dashboard-readonly"
  }

  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = "kubernetes-dashboard-viewonly"
  }
  subject {
    kind      = "ServiceAccount"
    name      = "kubernetes-dashboard-readonly"
    namespace = "kubernetes-dashboard"
  }
} 

resource "kubernetes_service_account" "kubernetes_dashboard_readonly" {
  metadata {
    name = "kubernetes-dashboard-readonly"
    namespace = "kubernetes-dashboard"
  }
}

resource "kubernetes_secret" "kubernetes_dashboard_readonly" {
  metadata {
    name = "kubernetes-dashboard-readonly"
    namespace = "kubernetes-dashboard"

    annotations = {
      "kubernetes.io/service-account.name" = kubernetes_service_account.kubernetes_dashboard_readonly.metadata.0.name
    }
  }
  type = "kubernetes.io/service-account-token"
}