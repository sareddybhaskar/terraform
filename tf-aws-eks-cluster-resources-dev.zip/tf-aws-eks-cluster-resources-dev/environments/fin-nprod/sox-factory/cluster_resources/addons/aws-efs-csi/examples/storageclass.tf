provider "aws" {
  region = "ap-southeast-1"
  # allowed_account_ids = [
  #   "083760424738",
  # ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "uday-tf-iac"
    key    = "tfstate/fin-nprod/lens/eks/cluster/addons/aws-ebs-csi/terraform.tfstate"
    region = "ap-southeast-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "uday-tf-iac"
    key    = "tfstate/fin-nprod/lens/eks/cluster/terraform.tfstate"
    region = "ap-southeast-1"
  }
}

# data "terraform_remote_state" "irsa" {
#   backend = "s3"
#   config = {
#     bucket = "uday-tf-iac"
#     key    = "tfstate/fin-nprod/lens/eks/cluster/addons/aws-efs-csi/examples/terraform.tfstate"
#     region = "ap-southeast-1"
#   }
# }

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

###################################################################################################
resource "kubernetes_storage_class" "efs_sc" {
  metadata {
    name = "efs-sc"
  }
  storage_provisioner    = "efs.csi.aws.com"
  mount_options          = ["tls"]
}

resource "kubernetes_persistent_volume" "efs-pv" {
  metadata {
    name = "efs-pvol"
  }

  spec {
    capacity = {
      storage = "5Gi"
    }
    access_modes = ["ReadWriteMany"]
    persistent_volume_reclaim_policy = "Retain"
    storage_class_name = "efs-sc"
    persistent_volume_source {
      csi {
        volume_handle = "fs-25e40565"
        driver         = "efs.csi.aws.com"
        volume_attributes = {
          "encryptInTransit" = "true"
        }
      }
    }
  }
}

# resource "kubernetes_persistent_volume_claim" "efs" {
#   metadata {
#     name = "efs-pvol-claim"
#     namespace = "test"
#     labels = {
#       app = "nginx"
#     }
#   }
#   spec {
#     access_modes = ["ReadWriteMany"]
#     resources {
#       requests = {
#         storage = "5Gi"
#       }
#     }
#     volume_name        = kubernetes_persistent_volume.efs-pv.metadata[0].name
#     storage_class_name = "efs-sc"
#   }
# }

