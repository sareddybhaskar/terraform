locals {
  license_key = "8f76bfe9bafa2f54dde63b48e49c9a4fFFFFNRAL"
  cluster_name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}