region = "eu-west-1"
availability_zones = ["eu-west-1a", "eu-west-1c"]
vpc_id = "vpc-00e00d06e6a616dc6"
subnet_ids = ["subnet-01e79d905e86887ef", "subnet-02f06dfbd7df580fb"]

kubernetes_version = "1.33"

instance_types = ["t3a.2xlarge" ]
desired_size = 3
max_size = 4
min_size = 3
disk_size = 100
ec2_ssh_key = "odp-eu-prod-tools_kp"
# capacity_type = "SPOT"


#####################
## Project tfvars ###
#####################

project = "odp"

# Maximum 4 characters (us-dev-factory-<project_slug>-eks-wng-) [for roles]
project_slug = "odp"

kubernetes_labels = {
    project = "odp"
    team    = "odp"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  dnf install -y ansible git nano
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  rm -rf /tmp/security-agents ; mkdir -p /tmp/security-agents  ; git clone https://NP700001567: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@github.gehealthcare.com/gehc-odp/security-agents.git /tmp/security-agents && cd /tmp/security-agents && ansible-playbook --connection=local --inventory 127.0.0.1, main.yaml ; cd ~/ ; rm -rf /tmp/security-agents
  EOT


tags = {
    ManagedBy = "Terraform"
    Project = "odp-factory"
    App = "odp-factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Prod"
    Role = "dt-dna-shared"
    Appliance = "EKS"
}
