resource "kubernetes_pod" "app_1" {
  metadata {
    name = "app1"
    namespace = "test"
    labels = {
        "app" = "storage-test"
    }    
  }

  spec {
    volume {
      name = "persistent-storage"

      persistent_volume_claim {
        claim_name = "efs-pvol-claim"
      }
    }

    container {
      name    = "app1"
      image   = "busybox"
      command = ["/bin/sh"]
      args    = ["-c", "while true; do echo $(date -u) >> /data/out1.txt; sleep 5; done"]

      volume_mount {
        name       = "persistent-storage"
        mount_path = "/data"
      }
    }
  }
}
