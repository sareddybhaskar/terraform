provider "aws" {
  region = "eu-west-1"
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/addons/aws-efs-csi/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/node-groups/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

###############################################################################################

########################
# AWS EFS CSI          #
########################

###############################################################################################

# resource "kubernetes_csi_driver" "efs" {
#   metadata {
#     name = "efs.csi.aws.com"
#   }

#   spec {
#     attach_required = true
#   }
# }

locals {
  name = "efs-csi-node"
  labels = {
    app                      = local.name
    "app.kubernetes.io/name" = "aws-efs-csi-driver"
  }
}

resource "kubernetes_daemonset" "efs" {
  metadata {
    name      = local.name
    namespace = var.namespace
    labels = {
      app                      = local.name
      "app.kubernetes.io/name" = "aws-efs-csi-driver"
    }
  }

  spec {
    selector {
      match_labels = local.labels
    }

    template {
      metadata {
        labels      = local.labels
        annotations = var.annotations
      }

      spec {
        node_selector = {
          "beta.kubernetes.io/os" = "linux"
        }

        toleration {
          operator = "Exists"
        }

        container {
          name              = "efs-plugin"
          image             = "amazon/aws-efs-csi-driver:v1.0.0"
          image_pull_policy = "IfNotPresent"

          args = ["--endpoint=$(CSI_ENDPOINT)", "--logtostderr", "--v=5"]

          env {
            name  = "CSI_ENDPOINT"
            value = "unix:/csi/csi.sock"
          }

          volume_mount {
            mount_path        = "/var/lib/kubelet"
            name              = "kubelet-dir"
            mount_propagation = "Bidirectional"
          }

          volume_mount {
            mount_path = "/csi"
            name       = "plugin-dir"
          }

          volume_mount {
            mount_path = "/var/run/efs"
            name       = "efs-state-dir"
          }

          volume_mount {
            mount_path = "/etc/amazon/efs"
            name       = "efs-utils-config"
          }

          port {
            name           = "healthz"
            container_port = 9809
            host_port      = 9809
            protocol       = "TCP"
          }

          liveness_probe {
            http_get {
              path = "/healthz"
              port = "healthz"
            }

            initial_delay_seconds = 10
            timeout_seconds       = 3
            period_seconds        = 2
            failure_threshold     = 5
          }

          security_context {
            privileged = true
          }
        }

        container {
          name  = "csi-driver-registrar"
          image = "quay.io/k8scsi/csi-node-driver-registrar:v1.3.0"
          args  = ["--csi-address=$(ADDRESS)", "--kubelet-registration-path=$(DRIVER_REG_SOCK_PATH)", "--v=5"]

          env {
            name  = "ADDRESS"
            value = "/csi/csi.sock"
          }

          env {
            name  = "DRIVER_REG_SOCK_PATH"
            value = "/var/lib/kubelet/plugins/efs.csi.aws.com/csi.sock"
          }

          env {
            name = "KUBE_NODE_NAME"
            value_from {
              field_ref {
                field_path = "spec.nodeName"
              }
            }
          }

          volume_mount {
            mount_path = "/csi"
            name       = "plugin-dir"
          }

          volume_mount {
            mount_path = "/registration"
            name       = "registration-dir"
          }
        }

        container {
          name  = "liveness-probe"
          image = "quay.io/k8scsi/livenessprobe:v2.0.0"
          args  = ["--csi-address=/csi/csi.sock", "--health-port=9809"]

          volume_mount {
            mount_path = "/csi"
            name       = "plugin-dir"
          }
        }

        volume {
          name = "kubelet-dir"

          host_path {
            path = "/var/lib/kubelet"
            type = "Directory"
          }
        }

        volume {
          name = "plugin-dir"

          host_path {
            path = "/var/lib/kubelet/plugins/efs.csi.aws.com/"
            type = "DirectoryOrCreate"
          }
        }

        volume {
          name = "registration-dir"

          host_path {
            path = "/var/lib/kubelet/plugins_registry/"
            type = "Directory"
          }
        }

        volume {
          name = "efs-state-dir"

          host_path {
            path = "/var/run/efs"
            type = "DirectoryOrCreate"
          }
        }

        volume {
          name = "efs-utils-config"

          host_path {
            path = "/etc/amazon/efs"
            type = "DirectoryOrCreate"
          }
        }

        host_network        = true
        priority_class_name = "system-node-critical"
      }
    }
  }
  # lifecycle {
  #   ignore_changes = [
  #     port,
  #   ]
  # }  
}