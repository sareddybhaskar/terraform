# resource "kubernetes_pod" "app_2" {
#   metadata {
#     name = "app2"
#   }

#   spec {
#     volume {
#       name = "persistent-storage"

#       persistent_volume_claim {
#         claim_name = "efs-pvol-claim"
#       }
#     }

#     container {
#       name    = "app2"
#       image   = "busybox"
#       command = ["/bin/sh"]
#       args    = ["-c", "while true; do echo $(date -u) >> /data/out3.txt; sleep 5; done"]

#       volume_mount {
#         name       = "persistent-storage"
#         mount_path = "/data"
#       }
#     }
#   }
# }
