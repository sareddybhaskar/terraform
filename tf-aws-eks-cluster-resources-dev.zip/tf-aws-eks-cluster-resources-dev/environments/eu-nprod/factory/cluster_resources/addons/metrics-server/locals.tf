locals {
  k8s_namespace               = "kube-system"
  k8s_pod_annotations         = var.k8s_pod_annotations
  metrics_server_docker_image = "k8s.gcr.io/metrics-server/metrics-server:v${var.metrics_server_version}"
  metrics_server_version      = var.metrics_server_version
}
