
variable "metrics_server_version" {
  description = "The metrics-server version to use."
  type        = string
  default     = "0.4.1"
}

variable "k8s_pod_annotations" {
  description = "Additional annotations to be added to the Pods."
  type        = map(string)
  default     = {}
}

