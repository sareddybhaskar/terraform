output "kubernetes_deployment" {
  value = "${kubernetes_deployment.cluster_autoscaler.metadata.0.namespace}/${kubernetes_deployment.cluster_autoscaler.metadata.0.name}"
}