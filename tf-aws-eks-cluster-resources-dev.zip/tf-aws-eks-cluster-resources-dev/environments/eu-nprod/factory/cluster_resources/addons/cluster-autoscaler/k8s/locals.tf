locals {
  kubernetes_resources_labels = merge({
    "k8s-app" = "cluster-autoscaler",
    "k8s-addon" = "cluster-autoscaler.addons.k8s.io",
    "app.kubernetes.io/managed-by" = "terraform",
  }, var.kubernetes_resources_labels)

  kubernetes_deployment_labels_selector = {
    "app" = "cluster-autoscaler",
  }

  kubernetes_deployment_labels = merge(local.kubernetes_deployment_labels_selector, local.kubernetes_resources_labels)
  # kubernetes_deployment_labels = local.kubernetes_resources_labels

  kubernetes_deployment_image = "${var.kubernetes_deployment_image_registry}:${var.kubernetes_deployment_image_tag}"

  asg_tags = [
    "k8s.io/cluster-autoscaler/enabled",
    "k8s.io/cluster-autoscaler/${data.aws_eks_cluster.cluster.name}",
  ]
  
  irsa_sa_role_arn  = data.terraform_remote_state.irsa.outputs.this_iam_role_arn

  kubernetes_deployment_container_command = concat([
    "./cluster-autoscaler",
    "--v=4",
    "--stderrthreshold=info",
    "--cloud-provider=aws",
    "--skip-nodes-with-local-storage=${var.skip_nodes_with_local_storage ? "false" : "true"}",
    "--expander=${var.expander}",
    "--node-group-auto-discovery=asg:tag=${join(",", local.asg_tags)}",
    "--balance-similar-node-groups",
    "--skip-nodes-with-system-pods=false",
  ], var.additional_autoscaler_options)
}