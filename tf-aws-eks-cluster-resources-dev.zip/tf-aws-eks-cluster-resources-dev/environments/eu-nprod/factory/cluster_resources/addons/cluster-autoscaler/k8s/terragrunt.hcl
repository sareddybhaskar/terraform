dependencies {
  paths = ["../../../node_groups", "../irsa" ]
}
