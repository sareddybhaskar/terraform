provider "aws" {
  region = "eu-west-1"
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/addons/cluster-autoscaler/irsa/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

data "aws_caller_identity" "current" {}

################################################################################################

locals {
  cluster_name  = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

module "iam_assumable_role_admin" {
  source                        = "git::https://github.build.ge.com/gehc-odp/tf-aws-eks.git//modules/eks/iam-role?ref=tags/v1.0"
  create_role                   = true
  role_name                     = "${local.cluster_name}-eks-${var.project}-${var.service_account_name}-irsa"
  provider_url                  = replace(data.terraform_remote_state.eks.outputs.eks_cluster_identity_oidc_issuer, "https://", "")
  role_policy_arns              = [aws_iam_policy.cluster_autoscaler.arn]
  oidc_fully_qualified_subjects = ["system:serviceaccount:${var.service_account_namespace}:${var.service_account_name}"]
}

resource "aws_iam_policy" "cluster_autoscaler" {
  name_prefix = "${local.cluster_name}-eks-${var.project}-irsa-"
  description = "EKS cluster-autoscaler policy for cluster ${local.cluster_name}"
  policy      = data.aws_iam_policy_document.cluster_autoscaler.json
}

data "aws_iam_policy_document" "cluster_autoscaler" {
  statement {
    sid    = "clusterAutoscalerAll"
    effect = "Allow"

    actions = [
      "autoscaling:DescribeAutoScalingGroups",
      "autoscaling:DescribeAutoScalingInstances",
      "autoscaling:DescribeLaunchConfigurations",
      "autoscaling:DescribeTags",
      "ec2:DescribeLaunchTemplateVersions",
    ]

    resources = ["*"]
  }

  statement {
    sid    = "clusterAutoscalerOwn"
    effect = "Allow"

    actions = [
      "autoscaling:SetDesiredCapacity",
      "autoscaling:TerminateInstanceInAutoScalingGroup",
      "autoscaling:UpdateAutoScalingGroup",
    ]

    resources = ["*"]

    condition {
      test     = "StringEquals"
      variable = "autoscaling:ResourceTag/kubernetes.io/cluster/${local.cluster_name}"
      values   = ["owned"]
    }

    condition {
      test     = "StringEquals"
      variable = "autoscaling:ResourceTag/k8s.io/cluster-autoscaler/enabled"
      values   = ["true"]
    }
  }
}


################################################################################################