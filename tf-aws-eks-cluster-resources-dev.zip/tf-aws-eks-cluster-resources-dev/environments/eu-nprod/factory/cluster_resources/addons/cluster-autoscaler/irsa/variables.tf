variable "region" {
  default = "eu-west-1"
}

variable "enabled" {
  type = bool
  default = true
}

variable "tags" {
  type        = map
}

variable "project" {
  type        = string
}

variable "service_account_name" {
  type        = string
}

variable "service_account_namespace" {
  type        = string
}