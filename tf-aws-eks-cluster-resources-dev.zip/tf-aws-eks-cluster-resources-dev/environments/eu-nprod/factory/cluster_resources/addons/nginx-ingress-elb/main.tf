provider "aws" {
  region = "eu-west-1"
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/addons/nginx-ingress-elb/k8s/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

##################################################################

