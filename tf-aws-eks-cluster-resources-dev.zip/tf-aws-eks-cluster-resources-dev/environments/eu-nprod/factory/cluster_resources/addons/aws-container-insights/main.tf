
provider "aws" {
  region = "eu-west-1"
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/addons/aws-container-insights/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-eu-nprod-terraform"
    key    = "terraform-state/nprod/eks/factory/cluster/node-groups/terraform.tfstate"
    region = "eu-west-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

provider "kubectl" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
}

###############################################################################################

##########################
# AWS Container insights #
##########################

###############################################################################################


data "kubectl_path_documents" "cwagent-deploy" {
  pattern = "${path.module}/manifests/cwagent.yaml"
    vars = {
        cloudwatch_agent_docker_image  = local.cloudwatch_agent_docker_image
        cluster_name = local.cluster_name
        region_name = local.region_name   
    }  
}

resource "kubectl_manifest" "cwagent-deploy" {
  count     = length(data.kubectl_path_documents.cwagent-deploy.documents)
  yaml_body = element(data.kubectl_path_documents.cwagent-deploy.documents, count.index)
}
