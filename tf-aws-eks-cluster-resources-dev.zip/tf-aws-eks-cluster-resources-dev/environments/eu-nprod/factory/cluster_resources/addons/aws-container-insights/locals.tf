locals {
  cloudwatch_agent_docker_image  = "400123706343.dkr.ecr.eu-west-1.amazonaws.com/amazon/cloudwatch-agent:1.247346.0b249609"
  region_name = "eu-west-1"
  cluster_name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}