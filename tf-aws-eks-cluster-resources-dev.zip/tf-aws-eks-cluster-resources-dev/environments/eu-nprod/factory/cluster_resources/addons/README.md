## Deploy sequence
---------------

1. metrics-server
2. kubernetes-dashboard
3. cluster-autoscaler/irsa
4. cluster-autoscaler
5. aws-efs-csi/irsa
6. aws-efs-csi
7. velero/irsa
8. velero
9. container-insights (CW metrics)