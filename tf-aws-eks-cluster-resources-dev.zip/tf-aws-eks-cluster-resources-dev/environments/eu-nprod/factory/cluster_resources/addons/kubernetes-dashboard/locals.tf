locals {
  kubernetes_resources_labels = merge({
    "k8s-app" = "kubernetes-dashboard",
  }, var.kubernetes_resources_labels)

  kubernetes_deployment_labels_selector = {
    "k8s-app" = "kubernetes-dashboard",
  }

  kubernetes_deployment_labels_selector_metrics = {
    "k8s-app" = "dashboard-metrics-scraper",
  }

  kubernetes_deployment_labels = local.kubernetes_deployment_labels_selector
  kubernetes_deployment_labels_metrics = local.kubernetes_deployment_labels_selector_metrics

  kubernetes_deployment_image = "${var.kubernetes_deployment_image_registry}:${var.kubernetes_deployment_image_tag}"
  kubernetes_deployment_metrics_scraper_image = "${var.kubernetes_deployment_metrics_scraper_image_registry}:${var.kubernetes_deployment_metrics_scraper_image_tag}"
}
