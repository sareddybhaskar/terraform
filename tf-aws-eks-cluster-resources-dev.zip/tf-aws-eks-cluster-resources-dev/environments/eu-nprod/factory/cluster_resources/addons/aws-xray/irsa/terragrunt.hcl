dependencies {
  paths = ["../../../node_groups" ]
}
