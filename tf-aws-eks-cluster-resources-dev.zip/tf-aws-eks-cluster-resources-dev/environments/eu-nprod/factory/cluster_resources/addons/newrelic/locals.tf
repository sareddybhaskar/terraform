locals {
  license_key = "57cac8f7f01d70542137ccc85d624e91FFFFNRAL"
  cluster_name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}