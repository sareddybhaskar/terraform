locals {
  namespace               = "ingress-nginx"
}