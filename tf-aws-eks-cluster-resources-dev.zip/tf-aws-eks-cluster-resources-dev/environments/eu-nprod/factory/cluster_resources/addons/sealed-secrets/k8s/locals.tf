# locals {
#   xray_role_irsa = data.terraform_remote_state.irsa.outputs.this_iam_role_arn
# }