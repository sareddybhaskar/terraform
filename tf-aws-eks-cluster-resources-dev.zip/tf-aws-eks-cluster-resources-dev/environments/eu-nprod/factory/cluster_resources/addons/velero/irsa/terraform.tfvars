region = "us-east-1"

# Use lower case letters
project = "odp"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}

service_account_name      = "velero-server"
service_account_namespace = "kube-system"

# velero backup location
s3_backup_bucket_name = "odp-us-innovation-factory-eks-cluster-backup"

# role_name_prefix          = "role"
# policy_name_prefix        = "policy"