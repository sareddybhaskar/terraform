variable "region" {
  default = "us-east-1"
}

variable "enabled" {
  type = bool
  default = true
}

variable "tags" {
  type        = map
}

variable "project" {
  type        = string
}

variable "service_account_name" {
  type        = string
}

variable "service_account_namespace" {
  type        = string
}

variable "s3_backup_bucket_name" {
  type = string
}