#resource "kubernetes_namespace" "gatekeeper_system" {
#  metadata {
#    name = "gatekeeper-system"
#
#    labels = {
#      "admission.gatekeeper.sh/ignore" = "no-self-managing"
#
#      control-plane = "controller-manager"
#
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  depends_on = [kubectl_manifest.crds]
#
#}
#
#resource "kubernetes_service_account" "gatekeeper_admin" {
#  metadata {
#    name      = "gatekeeper-admin"
#    namespace = "gatekeeper-system"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system  ]
#}
#
#resource "kubernetes_pod_security_policy" "gatekeeper_admin" {
#  metadata {
#    name = "gatekeeper-admin"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#
#    annotations = {
#      "seccomp.security.alpha.kubernetes.io/allowedProfileNames" = "*"
#    }
#  }
#
#  spec {
#    required_drop_capabilities = ["ALL"]
#    volumes                    = ["configMap", "projected", "secret", "downwardAPI"]
#
#    se_linux {
#      rule = "RunAsAny"
#    }
#
#    supplemental_groups {
#      rule = "MustRunAs"
#
#      range {
#        min = 1
#        max = 65535
#      }
#    }
#
#    run_as_user {
#      rule = "MustRunAsNonRoot"
#    }
#
#    fs_group {
#      rule = "MustRunAs"
#
#      range {
#        min = 1
#        max = 65535
#      }
#    }
#  }
#}
#
#resource "kubernetes_role" "gatekeeper_manager_role" {
#  metadata {
#    name      = "gatekeeper-manager-role"
#    namespace = "gatekeeper-system"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  rule {
#    verbs      = ["create", "patch"]
#    api_groups = [""]
#    resources  = ["events"]
#  }
#
#  rule {
#    verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups = [""]
#    resources  = ["secrets"]
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system  ]
#}
#
#resource "kubernetes_cluster_role" "gatekeeper_manager_role" {
#  metadata {
#    name = "gatekeeper-manager-role"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  rule {
#    verbs      = ["get", "list", "watch"]
#    api_groups = ["*"]
#    resources  = ["*"]
#  }
#
#  rule {
#    verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups = ["apiextensions.k8s.io"]
#    resources  = ["customresourcedefinitions"]
#  }
#
#  rule {
#    verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups = ["config.gatekeeper.sh"]
#    resources  = ["configs"]
#  }
#
#  rule {
#    verbs      = ["get", "patch", "update"]
#    api_groups = ["config.gatekeeper.sh"]
#    resources  = ["configs/status"]
#  }
#
#  rule {
#    verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups = ["constraints.gatekeeper.sh"]
#    resources  = ["*"]
#  }
#
#  rule {
#    verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups = ["mutations.gatekeeper.sh"]
#    resources  = ["*"]
#  }
#
#  rule {
#    verbs          = ["use"]
#    api_groups     = ["policy"]
#    resources      = ["podsecuritypolicies"]
#    resource_names = ["gatekeeper-admin"]
#  }
#
#  rule {
#    verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups = ["status.gatekeeper.sh"]
#    resources  = ["*"]
#  }
#
#  rule {
#    verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups = ["templates.gatekeeper.sh"]
#    resources  = ["constrainttemplates"]
#  }
#
#  rule {
#    verbs      = ["delete", "get", "patch", "update"]
#    api_groups = ["templates.gatekeeper.sh"]
#    resources  = ["constrainttemplates/finalizers"]
#  }
#
#  rule {
#    verbs      = ["get", "patch", "update"]
#    api_groups = ["templates.gatekeeper.sh"]
#    resources  = ["constrainttemplates/status"]
#  }
#
#  rule {
#    verbs          = ["create", "delete", "get", "list", "patch", "update", "watch"]
#    api_groups     = ["admissionregistration.k8s.io"]
#    resources      = ["validatingwebhookconfigurations"]
#    resource_names = ["gatekeeper-validating-webhook-configuration"]
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system  ]
#}
#
#resource "kubernetes_role_binding" "gatekeeper_manager_rolebinding" {
#  metadata {
#    name      = "gatekeeper-manager-rolebinding"
#    namespace = "gatekeeper-system"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  subject {
#    kind      = "ServiceAccount"
#    name      = "gatekeeper-admin"
#    namespace = "gatekeeper-system"
#  }
#
#  role_ref {
#    api_group = "rbac.authorization.k8s.io"
#    kind      = "Role"
#    name      = "gatekeeper-manager-role"
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system  ]
#}
#
#resource "kubernetes_cluster_role_binding" "gatekeeper_manager_rolebinding" {
#  metadata {
#    name = "gatekeeper-manager-rolebinding"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  subject {
#    kind      = "ServiceAccount"
#    name      = "gatekeeper-admin"
#    namespace = "gatekeeper-system"
#  }
#
#  role_ref {
#    api_group = "rbac.authorization.k8s.io"
#    kind      = "ClusterRole"
#    name      = "gatekeeper-manager-role"
#  }
#}
#
#resource "kubernetes_secret" "gatekeeper_webhook_server_cert" {
#  metadata {
#    name      = "gatekeeper-webhook-server-cert"
#    namespace = "gatekeeper-system"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  lifecycle {
#    ignore_changes = [
#      data,
#    ]
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system  ]
#}
#
#resource "kubernetes_service" "gatekeeper_webhook_service" {
#  metadata {
#    name      = "gatekeeper-webhook-service"
#    namespace = "gatekeeper-system"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  spec {
#    port {
#      port        = 443
#      target_port = "8443"
#    }
#
#    selector = {
#      control-plane = "controller-manager"
#
#      "gatekeeper.sh/operation" = "webhook"
#
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system, ]
#}
#
#resource "kubernetes_deployment" "gatekeeper_audit" {
#  metadata {
#    name      = "gatekeeper-audit"
#    namespace = "gatekeeper-system"
#
#    labels = {
#      control-plane = "audit-controller"
#
#      "gatekeeper.sh/operation" = "audit"
#
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  spec {
#    replicas = 1
#
#    selector {
#      match_labels = {
#        control-plane = "audit-controller"
#
#        "gatekeeper.sh/operation" = "audit"
#
#        "gatekeeper.sh/system" = "yes"
#      }
#    }
#
#    template {
#      metadata {
#        labels = {
#          control-plane = "audit-controller"
#
#          "gatekeeper.sh/operation" = "audit"
#
#          "gatekeeper.sh/system" = "yes"
#        }
#
#        annotations = {
#          "container.seccomp.security.alpha.kubernetes.io/manager" = "runtime/default"
#        }
#      }
#
#      spec {
#        container {
#          name    = "manager"
#          image   = "openpolicyagent/gatekeeper:v3.3.0"
#          command = ["/manager"]
#          args    = ["--operation=audit", "--operation=status", "--logtostderr"]
#
#          port {
#            name           = "metrics"
#            container_port = 8888
#            protocol       = "TCP"
#          }
#
#          port {
#            name           = "healthz"
#            container_port = 9090
#            protocol       = "TCP"
#          }
#
#          env {
#            name = "POD_NAMESPACE"
#
#            value_from {
#              field_ref {
#                api_version = "v1"
#                field_path  = "metadata.namespace"
#              }
#            }
#          }
#
#          env {
#            name = "POD_NAME"
#
#            value_from {
#              field_ref {
#                field_path = "metadata.name"
#              }
#            }
#          }
#
#          resources {
#            limits = {
#              cpu    = "1"
#              memory = "512Mi"
#            }
#
#            requests = {
#              cpu    = "100m"
#              memory = "256Mi"
#            }
#          }
#
#          liveness_probe {
#            http_get {
#              path = "/healthz"
#              port = "9090"
#            }
#          }
#
#          readiness_probe {
#            http_get {
#              path = "/readyz"
#              port = "9090"
#            }
#          }
#
#          image_pull_policy = "Always"
#
#          security_context {
#            capabilities {
#              drop = ["all"]
#            }
#
#            run_as_user               = 1000
#            run_as_group              = 999
#            run_as_non_root           = true
#            read_only_root_filesystem = true
#          }
#        }
#
#        termination_grace_period_seconds = 60
#
#        node_selector = {
#          "kubernetes.io/os" = "linux"
#          "project"         = "odp"
#        }
#
#        service_account_name            = "gatekeeper-admin"
#        automount_service_account_token = true
#      }
#    }
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system, kubernetes_service.gatekeeper_webhook_service]
#}
#
#resource "kubernetes_deployment" "gatekeeper_controller_manager" {
#  metadata {
#    name      = "gatekeeper-controller-manager"
#    namespace = "gatekeeper-system"
#
#    labels = {
#      control-plane = "controller-manager"
#
#      "gatekeeper.sh/operation" = "webhook"
#
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  spec {
#    replicas = 3
#
#    selector {
#      match_labels = {
#        control-plane = "controller-manager"
#
#        "gatekeeper.sh/operation" = "webhook"
#
#        "gatekeeper.sh/system" = "yes"
#      }
#    }
#
#    template {
#      metadata {
#        labels = {
#          control-plane = "controller-manager"
#
#          "gatekeeper.sh/operation" = "webhook"
#
#          "gatekeeper.sh/system" = "yes"
#        }
#
#        annotations = {
#          "container.seccomp.security.alpha.kubernetes.io/manager" = "runtime/default"
#        }
#      }
#
#      spec {
#        volume {
#          name = "cert"
#
#          secret {
#            secret_name  = "gatekeeper-webhook-server-cert"
#            default_mode = "0644"
#          }
#        }
#
#        container {
#          name    = "manager"
#          image   = "openpolicyagent/gatekeeper:v3.3.0"
#          command = ["/manager"]
#          args    = ["--port=8443", "--logtostderr", "--exempt-namespace=gatekeeper-system", "--operation=webhook"]
#
#          port {
#            name           = "webhook-server"
#            container_port = 8443
#            protocol       = "TCP"
#          }
#
#          port {
#            name           = "metrics"
#            container_port = 8888
#            protocol       = "TCP"
#          }
#
#          port {
#            name           = "healthz"
#            container_port = 9090
#            protocol       = "TCP"
#          }
#
#          env {
#            name = "POD_NAMESPACE"
#
#            value_from {
#              field_ref {
#                api_version = "v1"
#                field_path  = "metadata.namespace"
#              }
#            }
#          }
#
#          env {
#            name = "POD_NAME"
#
#            value_from {
#              field_ref {
#                field_path = "metadata.name"
#              }
#            }
#          }
#
#          resources {
#            limits  = {
#              cpu    = "1"
#              memory = "512Mi"
#            }
#
#            requests = {
#              cpu    = "100m"
#              memory = "256Mi"
#            }
#          }
#
#          volume_mount {
#            name       = "cert"
#            read_only  = true
#            mount_path = "/certs"
#          }
#
#          liveness_probe {
#            http_get {
#              path = "/healthz"
#              port = "9090"
#            }
#          }
#
#          readiness_probe {
#            http_get {
#              path = "/readyz"
#              port = "9090"
#            }
#          }
#
#          image_pull_policy = "Always"
#
#          security_context {
#            capabilities {
#              drop = ["all"]
#            }
#
#            run_as_user               = 1000
#            run_as_group              = 999
#            run_as_non_root           = true
#            read_only_root_filesystem = true
#          }
#        }
#
#        termination_grace_period_seconds = 60
#
#        node_selector = {
#          "kubernetes.io/os" = "linux"
#          "project"         = "odp"
#        }
#
#        service_account_name            = "gatekeeper-admin"
#        automount_service_account_token = true
#
#        affinity {
#          pod_anti_affinity {
#            preferred_during_scheduling_ignored_during_execution {
#              weight = 100
#
#              pod_affinity_term {
#                label_selector {
#                  match_expressions {
#                    key      = "gatekeeper.sh/operation"
#                    operator = "In"
#                    values   = ["webhook"]
#                  }
#                }
#                topology_key = "kubernetes.io/hostname"
#              }
#            }
#          }
#        }
#      }
#    }
#  }
#  depends_on = [kubernetes_namespace.gatekeeper_system, kubernetes_service.gatekeeper_webhook_service  ]
#}
#
#resource "kubernetes_validating_webhook_configuration" "gatekeeper_validating_webhook_configuration" {
#  metadata {
#    name = "gatekeeper-validating-webhook-configuration"
#
#    labels = {
#      "gatekeeper.sh/system" = "yes"
#    }
#  }
#
#  webhook {
#    name = "validation.gatekeeper.sh"
#    admission_review_versions = ["v1beta1"]
#
#    client_config {
#      service {
#        namespace = "gatekeeper-system"
#        name      = "gatekeeper-webhook-service"
#        path      = "/v1/admit"
#      }
#
#      ca_bundle = "Cg=="
#    }
#
#    namespace_selector {
#
#      match_expressions  {
#        key      = "admission.gatekeeper.sh/ignore"
#        operator = "DoesNotExist"
#      }
#    }
#
#    rule {
#      api_groups = ["*"]
#      api_versions = ["*"]
#      resources  = ["*"]
#      operations = ["CREATE", "UPDATE"]
#    }
#
#    failure_policy     = "Ignore"
#
#    side_effects    = "None"
#    timeout_seconds = 3
#  }
#  webhook {
#    name = "check-ignore-label.gatekeeper.sh"
#    admission_review_versions = ["v1beta1"]
#
#    client_config {
#      service {
#        namespace = "gatekeeper-system"
#        name      = "gatekeeper-webhook-service"
#        path      = "/v1/admitlabel"
#      }
#
#      ca_bundle = "Cg=="
#    }
#
#    rule {
#      api_groups = ["*"]
#      api_versions = ["*"]
#      resources  = ["namespaces"]
#      operations = ["CREATE", "UPDATE"]
#    }
#
#    failure_policy  = "Fail"
#    side_effects    = "None"
#    timeout_seconds = 3
#  }
#
#  lifecycle {
#    ignore_changes = [
#      webhook[0].client_config,
#      webhook[1].client_config,
#    ]
#  }
#
#  depends_on = [kubernetes_namespace.gatekeeper_system, kubernetes_service.gatekeeper_webhook_service, kubernetes_deployment.gatekeeper_controller_manager, kubernetes_deployment.gatekeeper_audit]
#}
#
