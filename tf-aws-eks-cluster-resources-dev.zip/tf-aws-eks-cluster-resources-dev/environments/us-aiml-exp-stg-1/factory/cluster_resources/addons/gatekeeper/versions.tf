Apply complete! Resources: 27 added, 0 changed, 15 destroyed.
[root@ip-10-55-246-128 gatekeeper]# cat versions.tf
terraform {
  required_providers {
    kubernetes = {
      source  = "hashicorp/kubernetes"
    version = "~> 2.25"
    }
    kubectl = {
      source  = "gavinbunney/kubectl"
      version = ">= 1.14.0"
    }
        external = {
      source  = "hashicorp/external"
      version = "< 2.1.0"
    }
  }
}