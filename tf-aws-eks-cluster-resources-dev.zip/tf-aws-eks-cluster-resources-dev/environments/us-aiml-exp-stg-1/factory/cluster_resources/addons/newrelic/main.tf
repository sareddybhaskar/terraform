provider "aws" {
  region = "us-east-1"
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg-1/eks/factory/cluster/addons/newrelic-infra/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg-1/eks/factory/cluster/node-groups/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

provider "kubectl" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
}

###############################################################################################

##########################
# Newrelic #
##########################

###############################################################################################


# data "kubectl_path_documents" "newrelic-deploy" {
#   pattern = "${path.module}/manifest/newrelic.yaml"
#     # vars = {
#     #     cluster_name = local.cluster_name
#     #     license_key = local.license_key   
#     # }  
# }

# resource "kubectl_manifest" "newrelic-deploy" {
#   count     = length(data.kubectl_path_documents.newrelic-deploy.documents)
#   yaml_body = element(data.kubectl_path_documents.newrelic-deploy.documents, count.index)
# }


data "kubectl_file_documents" "newrelic-deploy" {
    content = file("manifest/newrelic.yaml")
}

resource "kubectl_manifest" "newrelic-deploy" {
    count     = length(data.kubectl_file_documents.newrelic-deploy.documents)
    yaml_body = element(data.kubectl_file_documents.newrelic-deploy.documents, count.index)
}