provider "aws" {
  region = "us-east-1"
  allowed_account_ids = [
    "991497151145",
  ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg-1/eks/factory/cluster/addons/nginx-ingress-nlb/k8s/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg-1/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

##################################################################


# data "kubectl_path_documents" "velero-crds" {
#   pattern = "${path.module}/manifests/*.yaml"
# }

# data "kubectl_path_documents" "velero-deploy" {
#   pattern = "${path.module}/manifests/deployment/velero.yaml"
#     vars = {
#         namespace = local.k8s_namespace
#         backup_s3_bucket_name       = local.backup_s3_bucket_name
#         region                      = local.region
#         provider                    = local.provider
#         velero_iam_role_arn         = local.velero_iam_role_arn
#         velero_docker_image         = local.velero_docker_image  
#     }  
# }

# resource "kubectl_manifest" "velero-deploy" {
#   count     = length(data.kubectl_path_documents.velero-deploy.documents)
#   yaml_body = element(data.kubectl_path_documents.velero-deploy.documents, count.index)
# }