region = "us-east-1"
# availability_zones = ["ap-southeast-1a", "ap-southeast-1c"]

# Use lower case letters
project = "odp"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory"
    Program   = "ODP"
    uai  = "UAI3053026"
    Automation = "Jenkins"
    Environment  = "us-aiml-exp-stg"    
}


service_account_name      = "cluster-autoscaler"
service_account_namespace = "kube-system"


# role_name_prefix          = "role"
# policy_name_prefix        = "policy"