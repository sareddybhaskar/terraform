locals {
  k8s_namespace               = "kube-system"
  backup_s3_bucket_name       = "odp-us-aiml-exp-stg-1-factory-eks-cluster-backup"
  region                      = "us-east-1"
  provider                    = "aws"
  velero_iam_role_arn         = data.terraform_remote_state.irsa.outputs.this_iam_role_arn
  velero_docker_image         = "991497151145.dkr.ecr.us-east-1.amazonaws.com/velero/velero:v1.5.2"
}