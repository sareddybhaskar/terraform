provider "aws" {
  region = "us-east-1"
  # allowed_account_ids = [
  #   "991497151145",
  # ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg-1/eks/factory/cluster/addons/velero/irsa/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-aiml-exp-stg-terraform"
    key    = "terraform-state/aiml-exp-stg-1/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

data "aws_caller_identity" "current" {}

################################################################################################

locals {
  cluster_name  = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

module "iam_assumable_role_admin" {
  source                        = "git::https://github.gehealthcare.com/gehc-odp/tf-aws-eks.git//modules/eks/iam-role?ref=tags/v1.0"
  create_role                   = true
  role_name                     = "${local.cluster_name}-eks-${var.project}-${var.service_account_name}-irsa"
  provider_url                  = replace(data.terraform_remote_state.eks.outputs.eks_cluster_identity_oidc_issuer, "https://", "")
  role_policy_arns              = [aws_iam_policy.velero.arn]
  oidc_fully_qualified_subjects = ["system:serviceaccount:${var.service_account_namespace}:${var.service_account_name}"]
}

resource "aws_iam_policy" "velero" {
  name_prefix = "${local.cluster_name}-eks-${var.project}-irsa-"
  description = "EKS cluster-autoscaler policy for cluster ${local.cluster_name}"
  policy      = data.aws_iam_policy_document.velero.json
}

data "aws_iam_policy_document" "velero" {

  statement {
    sid = "ec2"

    actions = [
      "ec2:DescribeVolumes",
      "ec2:DescribeSnapshots",
      "ec2:CreateTags",
      "ec2:CreateVolume",
      "ec2:CreateSnapshot",
      "ec2:DeleteSnapshot",
    ]

    resources = ["*", ]
  }
  statement {
    sid = "s3list"

    actions = [
      "s3:ListBucket",
    ]

    resources = ["arn:aws:s3:::${var.s3_backup_bucket_name}", ]
  }

  statement {
    sid = "s3backup"

    actions = [
      "s3:GetObject",
      "s3:DeleteObject",
      "s3:PutObject",
      "s3:AbortMultipartUpload",
      "s3:ListMultipartUploadParts"
    ]
    resources = ["arn:aws:s3:::${var.s3_backup_bucket_name}/*", ]
  }
}


################################################################################################