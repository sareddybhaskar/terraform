  name = "odp-us-prod"
  region = "us-east-1"
  environment = "Prod"

  tags = {
    Program       = "ODP"
    Environment = "Prod"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3032643"
    App           = "daasbe"
    Project       = ""
    Role          = ""
    ApplicationTag = ""
    UserStory = ""
    Owner = ""
    Contact = "dtdnadaas2team@ge.com"
  }
