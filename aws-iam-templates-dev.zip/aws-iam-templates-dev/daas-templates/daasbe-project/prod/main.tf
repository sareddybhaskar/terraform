provider "aws" {
  version = ">= 3.0, < 4.0"
  region = "us-east-1"
  allowed_account_ids = [
    "245792935030",
  ]
}

###### Terraform State File Backup ######

terraform {
  required_version  = ">= 0.12.0"
  backend "s3" {
    bucket = "odp-us-prod-terraform"
    key    = "terraform-state/prod-us/iam-frameworks/daasbe/TRACK/terraform.tfstate"
    region = "us-east-1"
  }
}

###### Local Template Files ######

data "template_file" "user" {
  template = file("${path.module}/odp-us-prod-daasbe-TRACK-user-policy.json.tpl")
}

data "template_file" "service" {
  template = file("${path.module}/odp-us-prod-daasbe-TRACK-service-policy.json.tpl")
}

###### Creating IAM Policy ######

module "user" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-prod-daasbe-TRACK-user-policy"
  path        = "/"
  description = "odp-us-prod-daasbe-TRACK-user-policy"

  policy = data.template_file.user.rendered
}

module "service" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-modules.git//modules/iam/modules/policy?ref=dev"
  name        = "odp-us-prod-daasbe-TRACK-service-policy"
  path        = "/"
  description = "odp-us-prod-daasbe-TRACK-service-policy"

  policy = data.template_file.service.rendered
}


###### Login Role ######

module "hc-daasbe-TRACK-user" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-modules.git//modules/iam?ref=dev"
  role_name             = "hc-daasbe-TRACK-user"
  role_description      = "daasbe TRACK role"
  region                = var.region
  environment           = var.environment
  tags                  = var.tags
  role_assume_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::245792935030:saml-provider/ge-saml-for-aws-mfa"
      },
      "Action": "sts:AssumeRoleWithSAML",
      "Condition": {
        "StringEquals": {
          "SAML:aud": "https://signin.aws.amazon.com/saml"
        }
      }
    }
  ]
}
EOF
}

####### Service role ########

resource "aws_iam_role" "servicerole" {
  name        = "odp-us-prod-daasbe-TRACK-service-role"
  description = "odp-us-prod-daasbe-TRACK-service-role"

  assume_role_policy    = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": [
          "cloudwatch.amazonaws.com",
          "logs.amazonaws.com",
          "events.amazonaws.com",          
          "lambda.amazonaws.com",          
          "s3.amazonaws.com",          
          "dynamodb.amazonaws.com",
          "redshift.amazonaws.com",
          "glue.amazonaws.com",
          "sns.amazonaws.com",
          "states.amazonaws.com"           
          ]
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
  tags            = var.tags
}


###### Attaching Policies to ops Role ######

resource "aws_iam_role_policy_attachment" "user1" {
  role       = module.hc-daasbe-TRACK-user.role_name
  policy_arn = "arn:aws:iam::245792935030:policy/odp-us-prod-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "user2" {
  role       = module.hc-daasbe-TRACK-user.role_name
  policy_arn = "arn:aws:iam::245792935030:policy/odp-us-prod-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "user3" {
  role       = module.hc-daasbe-TRACK-user.role_name
  policy_arn = "arn:aws:iam::245792935030:policy/odp-us-prod-common-glue-user-policy" 
  }

  resource "aws_iam_role_policy_attachment" "user4" {
  role       = module.hc-daasbe-TRACK-user.role_name
  policy_arn = module.user.arn
}

resource "aws_iam_role_policy_attachment" "user5" {
  role       = module.hc-daasbe-TRACK-user.role_name
  policy_arn = "arn:aws:iam::245792935030:policy/odp-us-prod-s3-dlp-policy"
} 
 
###### Attaching Policies to Service Role ######

resource "aws_iam_role_policy_attachment" "service1" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::245792935030:policy/odp-us-prod-common-deny-policy"
}

resource "aws_iam_role_policy_attachment" "service2" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::245792935030:policy/odp-us-prod-common-glue-service-policy"
}

resource "aws_iam_role_policy_attachment" "service3" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  "arn:aws:iam::245792935030:policy/odp-us-prod-common-read-policy"
}

resource "aws_iam_role_policy_attachment" "service4" {
  role       = aws_iam_role.servicerole.name
  policy_arn =  module.service.arn
}

###### S3 Bucket ######

module "s3" {
  source = "git::https://github.build.ge.com/gehc-odp/tf-aws-modules.git//modules/s3_new?ref=dev"
  bucket_name     = "odp-us-prod-daasbe-TRACK"
  versioning = {
  enabled = false
  }
  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm     = "AES256"
      }
    }
  }
  tags = var.tags
}




