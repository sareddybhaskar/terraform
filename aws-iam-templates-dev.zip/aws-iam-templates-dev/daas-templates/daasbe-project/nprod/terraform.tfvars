  name = "odp-us-innovation"
  region = "us-east-1"
  environment = "Innovation"

  tags = {
    Program       = "ODP"
    Environment = "Innovation"
    ManagedBy  = "Terraform"
    Automation = "Jenkins"
    uai       = "UAI3032643"
    App           = "daasbe"
    Project       = ""
    Role          = ""
    ApplicationTag = ""
    UserStory = ""
    Owner = ""
    Contact = "dtdnadaas2team@ge.com"
  }
