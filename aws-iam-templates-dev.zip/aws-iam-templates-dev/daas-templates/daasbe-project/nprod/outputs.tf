
output "login-user" {
  value = module.hc-daasbe-TRACK-user.role_name
}

output "service-role" {
  value = aws_iam_role.servicerole.name
}
