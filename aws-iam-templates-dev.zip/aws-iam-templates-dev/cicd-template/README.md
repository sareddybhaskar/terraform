## Steps to create IAM roles

1. Once you have all the details, create folder with US# following with project details in IAM-Frameworkf folder in respective environment.

**Example** - US134593-cdx-ca-daas-CICD-framework



2. Main.tf file should have below common policies attached to it.

odp-us-prod-common-deny-policy

odp-us-prod-common-glue-service-policy

odp-us-prod-common-read-policy

odp-us-prod-cicd-common-api-deny-policy

odp-us-prod-cicd-common-role-policy



3. For IAM Passrole, Athena, API Gateway or any other service access, create JSON template in the folder and attach to the CICD role. Refer cicd-addon-policy.json files as sample template.



4. Update Trusted Relationship and FSSO User based on the services requested in the UserStory. Refer cicd-trust-relationship.json for list of principle service list.



5. Once CICD role setup is completed, Create FSSO User with policy template which should assume CICD role. 

{
    "Statement": [
        {
            "Action": "iam:PassRole",
            "Effect": "Allow",
            "Resource": "arn:aws:iam::245792935030:role/CICD-SERVICE-ROLE"
        }
    ],
    "Version": "2012-10-17"
}




6. After creating FSSO ID, we need to create credentials in CICD Jenkins console.

**Credentials example** : us-prod-cicd-cdx-ca-daas





