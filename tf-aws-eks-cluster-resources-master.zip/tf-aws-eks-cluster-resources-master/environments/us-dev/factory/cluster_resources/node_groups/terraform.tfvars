region = "us-east-1"
availability_zones = ["us-east-1a", "us-east-1c"]
subnet_ids = ["subnet-0aec610839cde56fb", "subnet-06a70a7954962e097"]
vpc_id = "vpc-07765370682ef3b06"

kubernetes_version = "1.19"

instance_types = ["t3a.xlarge" ]
desired_size = 3
max_size = 4
min_size = 3
disk_size = 100
ec2_ssh_key = "odp-us-innovation-tools_kp"
# capacity_type = "SPOT"


#####################
## Project tfvars ###
#####################

project = "odp"

# Maximum 4 characters (us-dev-factory-<project_slug>-eks-wng-) [for roles]
project_slug = "odp" 

kubernetes_labels = {
    project = "odp"
    team    = "odp"
    program  = "odp"
}


after_cluster_joining_userdata = <<-EOT
  printf "\n\n###\nafter_cluster_joining_userdata\n###\n\n"
  amazon-linux-extras install epel -y
  yum update -y
  yum install ansible git nano -y
  echo "localhost ansible_connection=local" | sudo tee /etc/ansible/hosts
  cd /tmp/
  git clone https://503125606:bec617b980800966197687913098f42416faedf8@github.build.ge.com/gehc-odp/2faldap-ranger-nifi-splunk-crowdstrike-qualys.git
  ansible-playbook 2faldap-ranger-nifi-splunk-crowdstrike-qualys/playbook-eks-usin.yml
  rm -rf 2faldap-ranger-nifi-splunk-crowdstrike-qualys
  EOT


tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}

