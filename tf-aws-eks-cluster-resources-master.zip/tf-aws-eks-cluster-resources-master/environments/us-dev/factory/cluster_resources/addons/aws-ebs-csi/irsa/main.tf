provider "aws" {
  region = "us-east-1"
  # allowed_account_ids = [
  #   "541574621075",
  # ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-innovation-terraform"
    key    = "terraform-state/innovation-us/eks/factory/cluster/addons/aws-ebs-csi/irsa/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-innovation-terraform"
    key    = "terraform-state/innovation-us/eks/factory/cluster/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}

data "aws_caller_identity" "current" {}

################################################################################################

locals {
  cluster_name  = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

module "iam_assumable_role_admin" {
  source                        = "git::https://github.build.ge.com/gehc-odp/tf-aws-eks.git//modules/eks/iam-role?ref=tags/v1.0"
  create_role                   = true
  role_name                     = "${local.cluster_name}-eks-${var.project}-${var.service_account_name}-irsa"
  provider_url                  = replace(data.terraform_remote_state.eks.outputs.eks_cluster_identity_oidc_issuer, "https://", "")
  role_policy_arns              = [aws_iam_policy.aws_ebs_csi.arn]
  oidc_fully_qualified_subjects = ["system:serviceaccount:${var.service_account_namespace}:${var.service_account_name}"]
}

resource "aws_iam_policy" "aws_ebs_csi" {
  name_prefix = "${local.cluster_name}-eks-${var.project}-irsa-"
  description = "EKS cluster-autoscaler policy for cluster ${local.cluster_name}"
  policy      = data.aws_iam_policy_document.aws_ebs_csi.json
}

data "aws_iam_policy_document" "aws_ebs_csi" {
  statement {
    sid    = "AWSEBSCSI"
    effect = "Allow"

    actions = [
        "ec2:AttachVolume",
        "ec2:CreateSnapshot",
        "ec2:CreateTags",
        "ec2:CreateVolume",
        "ec2:DeleteSnapshot",
        "ec2:DeleteTags",
        "ec2:DeleteVolume",
        "ec2:DescribeAvailabilityZones",
        "ec2:DescribeInstances",
        "ec2:DescribeSnapshots",
        "ec2:DescribeTags",
        "ec2:DescribeVolumes",
        "ec2:DescribeVolumesModifications",
        "ec2:DetachVolume",
        "ec2:ModifyVolume"
    ]

    resources = ["*"]
  }

  # statement {
  #   sid    = "clusterAutoscalerOwn"
  #   effect = "Allow"

  #   actions = [
  #     "autoscaling:SetDesiredCapacity",
  #     "autoscaling:TerminateInstanceInAutoScalingGroup",
  #     "autoscaling:UpdateAutoScalingGroup",
  #   ]

  #   resources = ["*"]

  #   condition {
  #     test     = "StringEquals"
  #     variable = "autoscaling:ResourceTag/kubernetes.io/cluster/${local.cluster_name}"
  #     values   = ["owned"]
  #   }

  #   condition {
  #     test     = "StringEquals"
  #     variable = "autoscaling:ResourceTag/k8s.io/cluster-autoscaler/enabled"
  #     values   = ["true"]
  #   }
  # }
}


################################################################################################