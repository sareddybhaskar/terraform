region = "us-east-1"
# availability_zones = ["ap-southeast-1a", "ap-southeast-1c"]

# Use lower case letters
project = "odp"

tags = {
    ManagedBy = "Terraform"
    Project = "ODP-Factory"
    Program   = "ODP"
    uai  = "UAI3032643"
    Automation = "Jenkins"
    Environment  = "Innovation"    
}


service_account_name      = "xray-daemon"
service_account_namespace = "aws-xray"


# role_name_prefix          = "role"
# policy_name_prefix        = "policy"