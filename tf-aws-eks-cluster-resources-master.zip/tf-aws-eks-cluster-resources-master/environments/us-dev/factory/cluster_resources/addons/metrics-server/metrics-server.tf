provider "aws" {
  region = "us-east-1"
  # allowed_account_ids = [
  #   "541574621075",
  # ]
}

terraform {
  required_version = ">= 0.12.9"
  backend "s3" {
    bucket = "odp-us-innovation-terraform"
    key    = "terraform-state/innovation-us/eks/factory/cluster/addons/metrics-server/terraform.tfstate"
    region = "us-east-1"
  }
}

data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "odp-us-innovation-terraform"
    key    = "terraform-state/innovation-us/eks/factory/cluster/node-groups/terraform.tfstate"
    region = "us-east-1"
  }
}

data "aws_eks_cluster" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = data.terraform_remote_state.eks.outputs.eks_cluster_id
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
  load_config_file       = false
  version                = "~> 1.13.3"
}


##########################################################################

##################
# METRICS SERVER #
##################

resource "kubernetes_service_account" "this" {
  automount_service_account_token = true
  metadata {
    labels = {
      "app.kubernetes.io/name"       = "metrics-server"
      "app.kubernetes.io/managed-by" = "terraform"
      "k8s-app" = "metrics-server"
    }
    name      = "metrics-server"
    namespace = local.k8s_namespace
  }
}


resource "kubernetes_cluster_role" "aggregated_metrics_reader" {
  metadata {
    labels = {
      "app.kubernetes.io/name"                       = "metrics-server"
      "app.kubernetes.io/managed-by"                 = "terraform"
      "rbac.authorization.k8s.io/aggregate-to-view"  = "true"
      "rbac.authorization.k8s.io/aggregate-to-edit"  = "true"
      "rbac.authorization.k8s.io/aggregate-to-admin" = "true"
      "k8s-app" = "metrics-server"
    }
    name = "system:aggregated-metrics-reader"
  }
  rule {
    api_groups = ["metrics.k8s.io"]
    resources  = ["pods", "nodes"]
    verbs      = ["get", "list", "watch"]
  }
}

resource "kubernetes_cluster_role" "this" {
  metadata {
    name = "system:metrics-server"

    labels = {
      "app.kubernetes.io/name"       = "metrics-server"
      "app.kubernetes.io/managed-by" = "terraform"
      "k8s-app"                      = "metrics-server"     
    }
  }
  rule {
    api_groups = [""]
    resources = [
      "pods",
      "nodes",
      "nodes/stats",
      "namespaces",
      "configmaps"
    ]
    verbs = [
      "get",
      "list",
      "watch"
    ]
  }
}

resource "kubernetes_role_binding" "metrics_server_auth_reader" {
  metadata {
    labels = {
      "app.kubernetes.io/name"       = "metrics-server"
      "app.kubernetes.io/managed-by" = "terraform"
      "k8s-app"                      = "metrics-server" 
    }
    # name      = "metrics-server:system:auth-delegator"
    name =  "metrics-server-auth-reader"

    namespace = local.k8s_namespace
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = "extension-apiserver-authentication-reader"
  }
  subject {
    api_group = ""
    kind      = "ServiceAccount"
    name      = kubernetes_service_account.this.metadata[0].name
    namespace = kubernetes_service_account.this.metadata[0].namespace
  }
}

resource "kubernetes_cluster_role_binding" "auth_delegator" {
  metadata {
    labels = {
      "app.kubernetes.io/name"       = "metrics-server"
      "app.kubernetes.io/managed-by" = "terraform"
      "k8s-app"                      = "metrics-server" 
    }
    name = "metrics-server:system:auth-delegator"
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = "system:auth-delegator"
  }
  subject {
    api_group = ""
    kind      = "ServiceAccount"
    name      = kubernetes_service_account.this.metadata[0].name
    namespace = kubernetes_service_account.this.metadata[0].namespace
  }
}

resource "kubernetes_cluster_role_binding" "this" {
  metadata {
    name = "system:metrics-server"

    labels = {
      "app.kubernetes.io/name"       = "metrics-server"
      "app.kubernetes.io/managed-by" = "terraform"
    }
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = kubernetes_cluster_role.this.metadata[0].name
  }
  subject {
    api_group = ""
    kind      = "ServiceAccount"
    name      = kubernetes_service_account.this.metadata[0].name
    namespace = kubernetes_service_account.this.metadata[0].namespace
  }
}

resource "kubernetes_service" "this" {
  metadata {
    name      = "metrics-server"
    namespace = local.k8s_namespace

    labels = {
      "app.kubernetes.io/name"        = "metrics-server"
      "app.kubernetes.io/managed-by"  = "terraform"
      "k8s-app"                       = "metrics-server"
      "kubernetes.io/name"            = "Metrics-server"
      "kubernetes.io/cluster-service" = "true"
    }
  }

  spec {
    selector = {
      "k8s-app" = "metrics-server"
    }
    port {
      name        = "https"
      port        = 443
      protocol    = "TCP"
      target_port = "https"
    }    
  }
}

resource "kubernetes_deployment" "this" {
  depends_on = [
    kubernetes_cluster_role_binding.auth_delegator,
    kubernetes_role_binding.metrics_server_auth_reader,
    kubernetes_cluster_role_binding.this
  ]

  metadata {
    name      = "metrics-server"
    namespace = local.k8s_namespace

    labels = {
      "app.kubernetes.io/name"       = "metrics-server"
      "app.kubernetes.io/version"    = "v${local.metrics_server_version}"
      "app.kubernetes.io/managed-by" = "terraform"
      "k8s-app"                      = "metrics-server"
    }
  }

  spec {

    replicas = 1

    selector {
      match_labels = {
        "k8s-app" = "metrics-server"
      }
    }

    strategy {
      type = "RollingUpdate"
      rolling_update {
        max_unavailable = 0
      }
      # type = "Recreate"
    }

    template {
      metadata {
        annotations = local.k8s_pod_annotations
        labels = {
          "app.kubernetes.io/name"    = "metrics-server"
          "app.kubernetes.io/version" = local.metrics_server_version
          "k8s-app"                   = "metrics-server"
        }
      }
      spec {
        priority_class_name = "system-node-critical"
        service_account_name = kubernetes_service_account.this.metadata[0].name
        automount_service_account_token = true
        restart_policy = "Always"


        container {
          args = [
            "--logtostderr",
            "--cert-dir=/tmp",
            "--secure-port=4443",
            "--kubelet-use-node-status-port",
            "--kubelet-preferred-address-types=InternalIP,Hostname,InternalDNS,ExternalDNS,ExternalIP"
          ]
          image             = local.metrics_server_docker_image
          image_pull_policy = "IfNotPresent"
          name              = "metrics-server"

          liveness_probe {
            failure_threshold = 5
            http_get {
              path = "/livez"
              port = "https"
              scheme = "HTTPS"
            }
            period_seconds = 20
          }
          port {
            name           = "https"
            container_port = 4443
            protocol       = "TCP"
          }   
          readiness_probe {
            failure_threshold = 3

            http_get {
              path = "/readyz"
              port = "https"
              scheme = "HTTPS"
            }
            period_seconds = 10
          }               
          security_context {
            read_only_root_filesystem = true
            run_as_non_root           = true
            run_as_user               = 1000
          }
          volume_mount {
            name       = "tmp-dir"
            mount_path = "/tmp"
          }          
          # command = [
          #   "/metrics-server"
          # ]
          # termination_message_path = "/dev/termination-log"
        }
        node_selector = {
          "kubernetes.io/os" = "linux"
          "project"          = "odp"
        }
        volume {
          name = "tmp-dir"
          empty_dir {}
        }  
      }  
    }
  }
  timeouts {
    create = "5m"
    update = "5m"
  }   
}

resource "kubernetes_api_service" "this" {
  metadata {
    labels = {
      "app.kubernetes.io/name"       = "metrics-server"
      "app.kubernetes.io/managed-by" = "terraform"
      "k8s-app"                      = "metrics-server"
    }
    name = "v1beta1.metrics.k8s.io"
  }
  spec {
    service {
      name      = kubernetes_service.this.metadata[0].name
      namespace = kubernetes_service.this.metadata[0].namespace
    }
    group                    = "metrics.k8s.io"
    version                  = "v1beta1"
    insecure_skip_tls_verify = true
    group_priority_minimum   = 100
    version_priority         = 100
  }
}

################################################################################